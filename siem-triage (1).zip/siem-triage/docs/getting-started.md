# Getting Started

End-to-end walkthrough: from zero to your first triaged incident. Plan
about **45 minutes** for the initial setup, mostly waiting for Entra ID
admin consent to propagate.

## Before you start

You'll need:

| Item | Where to get it |
|---|---|
| **VS Code 1.99+** with GitHub Copilot extension | [code.visualstudio.com](https://code.visualstudio.com/) |
| **GitHub Copilot subscription** (Pro+, Business, or Enterprise) | [github.com/features/copilot](https://github.com/features/copilot) |
| **Python 3.10+** | [python.org](https://www.python.org/downloads/) |
| **Microsoft Sentinel workspace** with data | Your Azure tenant |
| **Entra ID admin** who can grant Graph application permissions | Someone in your org |
| **Azure RBAC permissions** on the Sentinel workspace's resource group | Probably you, or your cloud team |

Optional but recommended:

| Item | Free tier | Purpose |
|---|---|---|
| **VirusTotal API key** | 4 lookups/min, 500/day | IP/hash/domain reputation |
| **AbuseIPDB API key** | 1,000/day | IP abuse scoring |
| **GreyNoise API key** | Works without one (community tier) | Internet noise classification |

## Stage 1 — Service Principal (15 min, mostly waiting)

Follow [`service-principal-setup.md`](service-principal-setup.md) end-to-end.
By the end you will have:

- Tenant ID (a GUID)
- Application/client ID (a GUID)
- Client secret (a string, shown once)
- 6 Graph application permissions, all admin-consented ✅
- 2 Azure RBAC roles on the workspace: `Log Analytics Reader`, `Microsoft Sentinel Reader`

Don't proceed until the verification step at the end of that doc passes.
If the SP can't authenticate, nothing else will work.

## Stage 2 — Install the code (5 min)

```bash
# 1. Clone (or unzip the bundle)
git clone <your-repo-url> siem-triage
cd siem-triage

# 2. Python environment
python -m venv .venv
source .venv/bin/activate              # Linux/macOS
# .venv\Scripts\Activate.ps1            # Windows PowerShell

# 3. Dependencies
pip install -r requirements.txt
pip install -e mcp-apps/siem-tools-mcp
```

The `pip install -e` (editable install) makes the MCP server importable as
the Python module `siem_tools`. This is what lets VS Code spawn it with
`python -m siem_tools.server`.

## Stage 3 — Configure (5 min)

Copy the three template files:

```bash
cp .env.template .env
cp config.json.template config.json
cp .vscode/mcp.json.template .vscode/mcp.json
```

Edit **`.env`** with the Service Principal values from Stage 1:

```bash
AZURE_TENANT_ID=your-tenant-guid-here
AZURE_CLIENT_ID=your-client-guid-here
AZURE_CLIENT_SECRET=the-secret-string

AZURE_LOG_ANALYTICS_WORKSPACE_ID=workspace-guid-here
AZURE_SUBSCRIPTION_ID=subscription-guid-here
AZURE_RESOURCE_GROUP=your-rg-name
AZURE_WORKSPACE_NAME=your-workspace-name

# Leave blank if you don't have them
VIRUSTOTAL_API_KEY=
ABUSEIPDB_API_KEY=
GREYNOISE_API_KEY=
```

Edit **`config.json`** with the same workspace details. The `.vscode/mcp.json`
template uses `${input:...}` placeholders that VS Code prompts for on first
launch — you don't need to edit it directly.

## Stage 4 — Smoke tests (5 min)

Three checks in order. Stop at the first failure and fix it before moving on.

### 4a. Tool dispatch (no network)

```bash
cd mcp-apps/siem-tools-mcp
pytest -q
cd ../..
```

Expected: `3 passed`. If pytest is missing, `pip install pytest`.

### 4b. Service Principal authentication

```bash
python -c "
import sys; sys.path.insert(0, 'mcp-apps/siem-tools-mcp/src')
from dotenv import load_dotenv; load_dotenv()
from siem_tools.auth import graph_token, la_token
print('Graph token length:', len(graph_token()))
print('Log Analytics token length:', len(la_token()))
"
```

Expected: two integers around 1500–2500. If you see `ClientAuthenticationError`,
your `.env` SP values are wrong or the secret has expired.

### 4c. Live Azure call

```bash
python -c "
import asyncio, sys
sys.path.insert(0, 'mcp-apps/siem-tools-mcp/src')
from dotenv import load_dotenv; load_dotenv()
from siem_tools.loganalytics import run_kql
result = asyncio.run(run_kql('SigninLogs | take 1', timespan='PT1H'))
print('Rows returned:', result['tables'][0]['rowCount'])
"
```

Expected: `Rows returned: 1` (or `0` if your workspace has no recent
sign-ins, which is unusual but possible).

Common failures here:

| Error | What it means | Fix |
|---|---|---|
| `401` | SP token rejected | Secret wrong or expired |
| `403` | SP authenticated but lacks permission | Grant `Log Analytics Reader` on workspace |
| `404` | Workspace not found | Wrong `AZURE_LOG_ANALYTICS_WORKSPACE_ID` |

## Stage 5 — Wire up VS Code (5 min)

1. Open the repo in VS Code:
   ```bash
   code .
   ```

2. Open Copilot Chat: `Ctrl+Shift+I` (Windows/Linux) or `Cmd+Shift+I` (macOS)

3. Switch the chat dropdown from **Ask** to **Agent**. The dropdown is just
   above the chat input box.

4. Click the wrench/tools icon in the chat — you should see `siem-tools`
   listed with all 10 tools (`list_recent_incidents`, `get_incident`,
   `run_kql`, etc.).

5. If the server is missing or red:
   - Click the `{}` icon in the bottom status bar to open the **MCP Servers**
     panel
   - Find `siem-tools` and check the stderr output for the actual error
   - Most common: the `pip install -e` step in Stage 2 wasn't run, so
     `python -m siem_tools.server` can't find the package

6. On the **first tool call**, VS Code will prompt you for each input
   defined in `.vscode/mcp.json` (tenant ID, client ID, secret, etc.).
   These get cached in your OS keychain — you don't re-enter them.

## Stage 6 — Your first triage (10 min)

In Copilot Chat (Agent Mode):

### Step 1. See what's there

```
List my 5 most recent active incidents.
```

Copilot will:
1. Show you it's about to call `list_recent_incidents`
2. Ask for permission (first time only — you can choose "Always allow")
3. Display the response

You should see a short list with incident IDs, titles, severities, and
created timestamps. **Copy one of the incident IDs for the next step.**

If this returns nothing, try removing `active`:

```
List my 10 most recent incidents regardless of status.
```

### Step 2. Triage it

```
Triage incident <paste-incident-id-here>. Produce a verdict with evidence.
```

The agent will work through the incident-triage skill workflow:

1. Calls `get_incident` to pull the envelope
2. Tells you what kind of incident this is and how many entities it
   contains
3. Calls enrichment tools on each entity:
   - `enrich_ip` for any IP addresses
   - `get_risky_user` + `get_user_auth_methods` for any users
   - `enrich_hash` for any file hashes
4. Runs KQL hunts via `run_kql`, picking from `queries/` first
5. Produces a verdict JSON in the chat
6. Writes a markdown report to `reports/incident-triage/<id>.md`

The whole thing usually takes 1–3 minutes depending on incident
complexity and how many tools the agent decides to call.

### Step 3. Read the verdict

Open `reports/incident-triage/<id>.md` in VS Code. You'll see:

- **Classification** (TruePositive / FalsePositive / Benign / Inconclusive)
- **Confidence** (0.00–1.00; anything < 0.85 will be Inconclusive)
- **Summary** (one-sentence verdict)
- **Evidence** (each claim with its source tool call)
- **Entities Investigated**
- **KQL Queries Run** (with row counts)
- **Deep-Dive Plan** (next steps for you)
- **Recommended Actions** (advisory — *not* executed)

The verdict ends with: *"Handoff state: awaiting_decision. The agent did
not take any response action."* That's your cue.

### Step 4. Decide what to do

The agent's job is done. Yours starts. Three typical outcomes:

- **FalsePositive / Benign with high confidence** → close the incident
  in Sentinel/Defender, paste the verdict summary into the resolution
  comment for audit purposes.
- **TruePositive** → escalate or proceed with response actions yourself
  (isolate host, disable user, etc.) using the agent's
  `recommendedActions` as a starting point.
- **Inconclusive** → follow the `deepDivePlan` to gather what's missing.
  You can chain prompts in the same chat: *"Now investigate the user
  alice@contoso.com from that incident"* will pivot using the
  `user-investigation` skill.

## You're done

You've successfully triaged an incident. The next time, this whole flow
is two steps: open chat, type `triage incident <id>`.

For more advanced workflows — chaining investigations, IoC lookups, KQL
authoring, custom skills — see [`daily-use.md`](daily-use.md).

If anything broke, [`troubleshooting.md`](troubleshooting.md) covers the
common cases.
