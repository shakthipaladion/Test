# Overview — What This Tool Does

## In one sentence

The SIEM Triage Agent is a GitHub Copilot–powered assistant that does the
first 30 minutes of work on every Sentinel or Defender XDR incident — pulling
the data, enriching the entities, running the obvious hunts, and producing
a structured verdict — so a human analyst can spend their time on the
decision rather than the data gathering.

## What problem it solves

A typical Tier-1 SOC analyst spends most of their shift on repetitive
mechanics:

1. Open the incident in the portal
2. Click through each entity to see what it is
3. Copy the user's UPN, paste into Identity Protection
4. Copy the IP, paste into VirusTotal, then AbuseIPDB
5. Write a KQL query to see if anything else touched this IP
6. Write another KQL query to see if the user had failures before success
7. Read the results, compare to the alert, form a verdict
8. Type up the verdict in the incident comments
9. Hand off or close

Steps 1–8 are nearly identical across most incidents. They're slow and
error-prone, not because they're hard, but because there are many of them
and they all happen in different windows. This is where junior analyst
fatigue and "alert fatigue close" mistakes come from.

This tool collapses steps 1–8 into a single chat prompt:

> "Triage incident 12345"

The agent does all the data gathering, enrichment, hunting, and verdict
formatting. The analyst reads the result, decides on step 9, and moves on.

## What it is

- **A GitHub Copilot agent** running in VS Code's Agent Mode. The model is
  whichever you've selected in Copilot (typically Claude Sonnet or
  GPT-class). No separate AI subscription needed.
- **A local Python MCP server** that gives Copilot the ability to call
  Microsoft Graph and Log Analytics on your behalf, using a Service
  Principal you control.
- **A set of skill files** (`.github/skills/*/SKILL.md`) that teach the
  agent how a Tier-1 analyst should triage different things: incidents,
  users, IoCs, KQL authoring, verdict writing.
- **A library of verified KQL queries** the agent picks from before
  authoring new hunts — so your tribal knowledge becomes reusable.
- **Markdown reports** written to `reports/` for every investigation, so
  there's a git-committed audit trail of every triage decision.

## What it is *not*

These aren't oversights — they're deliberate design choices.

- **Not an autonomous responder.** The agent has no tools to close
  incidents, disable accounts, isolate hosts, or block IPs. It produces
  recommendations as text; humans execute.
- **Not a replacement for Tier-2/Tier-3 analysts.** It's a Tier-1
  workload reducer. Deep investigations, threat hunting, and incident
  response remain human work.
- **Not a SOAR platform.** No playbooks, no automation rules, no
  workflows triggered by events. It runs only when an analyst opens
  Copilot Chat and asks for a triage.
- **Not a SIEM.** It reads from your existing Sentinel / Defender XDR
  deployment. It doesn't ingest logs, build detections, or store data.
- **Not a black box.** Every tool call is visible in the chat. Every
  KQL query is recorded in the verdict. Every claim cites its source.
  You can always see why it concluded what it concluded.

## Who it's for

- **Tier-1 SOC analysts** who want to spend less time on data gathering
  and more time on decision-making.
- **SOC managers** who want to standardize how junior analysts triage and
  capture institutional KQL knowledge in version control.
- **Detection engineers** who want a fast feedback loop when tuning new
  rules — replay incidents and see if the verdict matches expectations.
- **Security engineers** in small-to-medium SOCs (1–10 analysts) who
  don't want to operate a queue/database/web-app stack for this use case.

## Who it's *not* for (yet)

- **High-volume SOCs** processing hundreds of incidents per hour
  unattended. Add ingestion automation and a queue first.
- **Air-gapped environments** without internet access. The Graph and Log
  Analytics APIs are reached over HTTPS.
- **Tenants that block service principals from Graph Security APIs.** If
  your security team mandates user-context auth only, you'd need to
  rework the auth layer to use `DefaultAzureCredential` with delegated
  permissions.

## How it relates to Microsoft Security Copilot

Microsoft Security Copilot is a separate, paid product from Microsoft. It
solves a similar problem at a much larger scale, with deep platform
integration. This tool is a **lightweight, self-hosted, free alternative**
for teams who:

- Don't have Security Copilot licenses
- Want full visibility into prompts, tool calls, and queries
- Prefer to manage their own skill library in git
- Want to start small and grow

If you have Security Copilot, you may still find this useful for
custom triage workflows that don't fit Security Copilot's agents. If you
don't have it, this fills the obvious gap.

## What you should read next

- New here, want to set it up → [`getting-started.md`](getting-started.md)
- Already running it, want to use it well → [`daily-use.md`](daily-use.md)
- Got a verdict, not sure how to read it → [`understanding-verdicts.md`](understanding-verdicts.md)
- Something's broken → [`troubleshooting.md`](troubleshooting.md)
- Just want the quick version → [`../QUICK_REFERENCE.md`](../QUICK_REFERENCE.md)
- Curious how it works under the hood → [`architecture.md`](architecture.md)
