# Daily Use

Common workflows with example prompts you can paste into Copilot Chat
(Agent Mode). All workflows assume the setup in
[`getting-started.md`](getting-started.md) is complete.

## The four core workflows

### 1. Triage an incident

**When:** A specific Sentinel/Defender XDR incident has fired and you need
to decide what to do with it.

**Prompt:**
```
Triage incident <incident-id>. Produce a verdict with evidence.
```

**What the agent does:** Loads the `incident-triage` skill, pulls the
incident, enriches each entity, runs targeted hunts, writes a verdict to
`reports/incident-triage/<id>.md`.

**What you get:** A markdown report you can act on or paste into the
incident's resolution comments.

---

### 2. Investigate a user

**When:** You have a suspicious user (UPN or email) — either as a pivot
from a triage, or standalone (e.g., HR called about a leaving employee).

**Prompt:**
```
Investigate user alice@contoso.com for the last 7 days.
```

Variations:
```
Investigate user alice@contoso.com for the last 24 hours.
Check user activity for bob@contoso.com — focus on MFA changes.
Is the user charlie@contoso.com at risk?
```

**What the agent does:** Loads the `user-investigation` skill, fetches
risky-user state, MFA methods, recent sign-ins, audit log activity, and
any open incidents touching the user.

**What you get:** A report at `reports/user-investigation/<upn>-<timestamp>.md`.

---

### 3. Investigate an IoC

**When:** You have an IP, hash, or domain and need to know (a) is it
malicious externally, and (b) have you seen it internally.

**Prompts:**
```
Investigate IP 203.0.113.42.
Is this hash malicious? abc123def456...
Look up the domain evil.example.com — have we seen it in the tenant?
```

**What the agent does:** Loads the `ioc-investigation` skill, runs the
matching enrichment tool (`enrich_ip` / `enrich_hash` / `enrich_domain`),
then runs a tenant-wide KQL hunt to find any internal exposure.

**What you get:** A report at `reports/ioc-investigation/<type>-<value>-<timestamp>.md`.

---

### 4. Author a KQL query

**When:** You need a hunt that isn't in the `queries/` library yet.

**Prompt:**
```
Write a KQL query to find all users who registered a new MFA method
within 1 hour of a risky sign-in in the last 7 days.
```

**What the agent does:** Loads the `kql-query-authoring` skill, greps
the `queries/` library first for existing matches, then authors new KQL
if nothing fits, validates against the schema, and offers to save it to
`queries/<domain>/` with the proper metadata header.

**What you get:** A query in chat. Say "yes, save it" and it goes into
the library for next time.

---

## Chaining workflows

The big productivity win is chaining. Each prompt builds on prior chat
context, so you can pivot without restating everything.

### Example: incident → user → IoC

```
You: Triage incident inc-9876.

[agent triages, produces verdict mentioning user alice@contoso.com
 and suspicious IP 203.0.113.42]

You: Now investigate the user from that incident.

[agent uses user-investigation skill on alice@contoso.com]

You: Is the IP from the incident a known VPN?

[agent uses ioc-investigation skill on 203.0.113.42, looks at the
 abuseipdb usageType and greynoise classification]

You: Generate a combined summary I can paste into the incident comments.
```

The agent has the full conversation context — it knows which incident,
which user, which IP — and can produce a synthesized comment without
you re-supplying any of it.

---

## Useful one-off prompts

### Discovery

```
What incidents are active right now?
Show me the 10 most recent high-severity incidents from the last 24 hours.
List incidents assigned to nobody.
```

### KQL prototyping

```
What columns does the SigninLogs table have?
Run this query for me: SigninLogs | where TimeGenerated > ago(1h) | take 5
Write a query to find PowerShell executions with base64-encoded commands in the last 24 hours.
```

The agent will run the query via `run_kql` and summarize results.

### Reasoning out loud

```
Given the failed sign-ins from earlier — could this be password spray?
What would make this Inconclusive verdict more decisive?
What additional KQL queries would help resolve this?
```

The agent will reason against the chat context, suggest investigative
steps, and offer to run them.

### Library hygiene

```
What KQL queries are in our library?
Find queries related to lateral movement.
Suggest queries we should add based on the last 5 incidents I triaged.
```

The agent greps `queries/` and the recent `reports/` files.

---

## Anti-patterns — don't do these

### Don't ask the agent to take action

The agent has read-only tools. It will not, and cannot:

- Close an incident
- Disable a user account
- Isolate a host
- Block an IP at the firewall
- Reset a password
- Revoke sign-in sessions

If you ask, it will explain the constraint and put the action in
`recommendedActions` for you to execute. This is by design — see
[`overview.md`](overview.md).

### Don't paste raw incident data

You don't need to paste alert payloads, KQL results, or screenshots.
Just give the agent the incident ID — it pulls everything itself. Pasting
data muddies the chat context and the agent may quote your paste back
when it should be citing tool results.

### Don't ask the agent to "just look at" the portal

The agent has no browser. It works through the MCP tools only. If you
need something the tools don't cover, the answer is to add a new MCP
tool (see [`extending.md`](extending.md) — coming if you need it) or use
the portal directly.

### Don't ignore Inconclusive verdicts

A confidence < 0.85 means the agent genuinely couldn't decide. The
`deepDivePlan` will list what's missing. Following it usually takes
2–3 more prompts and produces a decisive verdict. **Closing an
Inconclusive verdict as a "low risk" without follow-up is exactly the
kind of alert fatigue this tool was built to prevent.**

---

## Productivity patterns

### Pattern: morning queue burn-down

```
1. List my 20 oldest active incidents.
2. Triage each one in order:
   - "Triage <id1>" → review report → close or escalate in portal
   - "Triage <id2>" → ...
3. At the end, write a summary of what was closed vs escalated.
```

Realistic throughput: 5–10 incidents per hour with this loop, vs 2–3 doing
it manually.

### Pattern: end-of-shift hand-off

```
Summarize what I triaged today.
What's still Inconclusive that the next shift should pick up?
Generate a hand-off note I can post in our SOC channel.
```

The agent reads `reports/incident-triage/` (sorted by mtime) and
synthesizes.

### Pattern: detection tuning loop

When you ship a new analytic rule and want to know if it'd alert-spam:

```
Triage the 10 most recent incidents fired by rule "<rule-name>".
What fraction were FalsePositive? Group the FP causes.
```

The agent does the triages, then groups results — fast feedback on
whether your new rule needs tuning before it goes wide.

### Pattern: KQL knowledge capture

After any non-trivial investigation:

```
Save the KQL queries we wrote in this chat to the queries/ library
with the proper metadata headers. Pick the right subfolder for each.
```

Your tribal knowledge becomes a versioned, grep-searchable library that
the next triage benefits from automatically.

---

## When the agent gets stuck

Sometimes the agent will:

- Keep retrying a failed tool call
- Loop on the same hunt without finding anything
- Produce an Inconclusive verdict with a thin deep-dive plan

When this happens:

1. **Read what it's actually doing.** The chat shows every tool call. The
   problem is usually visible: wrong workspace, permission denied, or a
   KQL field that doesn't exist in your schema.

2. **Steer it directly.** Don't restart the chat — just tell it what to do:
   ```
   That query is failing. Try AuditLogs instead of SigninLogs for the
   password reset event.
   ```

3. **Give it the missing piece.** If it doesn't know your environment's
   naming conventions:
   ```
   Our admin accounts use the pattern admin-*@contoso.com.
   Re-run with that filter.
   ```

4. **If truly stuck, stop and escalate.** A genuinely Inconclusive
   verdict with no path forward is a signal to stop using the agent for
   this incident and go investigate manually. The agent is a tool, not
   a substitute for analyst judgment.

---

## What's next

- Reading the verdicts the agent produces → [`understanding-verdicts.md`](understanding-verdicts.md)
- Errors and fixes → [`troubleshooting.md`](troubleshooting.md)
- Cheat-sheet for everything → [`../QUICK_REFERENCE.md`](../QUICK_REFERENCE.md)
