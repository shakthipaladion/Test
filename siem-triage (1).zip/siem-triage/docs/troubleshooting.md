# Troubleshooting

Symptom → cause → fix. Errors are organized by where you'll see them.

## Setup-time errors

### `pip install -e mcp-apps/siem-tools-mcp` fails

**Symptom:** Some variant of "ModuleNotFoundError" or "error: invalid command 'bdist_wheel'".

**Cause:** Python < 3.10, or missing `setuptools`/`wheel`.

**Fix:**
```bash
python --version          # must be 3.10+
pip install --upgrade pip setuptools wheel
pip install -e mcp-apps/siem-tools-mcp
```

### `pytest -q` fails with import errors

**Symptom:** `ModuleNotFoundError: No module named 'siem_tools'`

**Cause:** The editable install didn't take, or you're running pytest from
the wrong directory.

**Fix:**
```bash
cd mcp-apps/siem-tools-mcp
PYTHONPATH=src pytest -q
```

If that works, `pip install -e .` from inside `mcp-apps/siem-tools-mcp` to
make `PYTHONPATH` unnecessary.

## Auth errors

### `ClientAuthenticationError` on any tool call

**Symptom:** Server starts, but every tool returns an auth error in chat.

**Cause:** Service Principal credentials are wrong, or the secret expired.

**Fix:**
1. Check `.env` values match the App Registration in Entra exactly. Common
   mistake: pasting the *object ID* of the SP instead of the *application
   (client) ID*. These are different GUIDs.
2. Check the secret hasn't expired. Entra → App registrations → your app
   → Certificates & secrets → look at the "Expires" column.
3. Rotate the secret if expired (see `service-principal-setup.md` step 2).

### HTTP 401 from Microsoft Graph

**Symptom:** Tool returns `Graph 401: ...InvalidAuthenticationToken...`

**Cause:** Token rejected — usually wrong audience or expired secret.

**Fix:** Same as `ClientAuthenticationError` above. If your env values look
correct, dump the token's claims to see which app it's for:

```bash
python -c "
import sys; sys.path.insert(0, 'mcp-apps/siem-tools-mcp/src')
from dotenv import load_dotenv; load_dotenv()
from siem_tools.auth import graph_token
import base64, json
parts = graph_token().split('.')
payload = json.loads(base64.urlsafe_b64decode(parts[1] + '=='))
print('aud:', payload.get('aud'))
print('appid:', payload.get('appid'))
print('tid:', payload.get('tid'))
"
```

- `aud` should be `https://graph.microsoft.com` or `00000003-0000-0000-c000-000000000000`
- `appid` should match your `AZURE_CLIENT_ID`
- `tid` should match your `AZURE_TENANT_ID`

### HTTP 403 from Microsoft Graph

**Symptom:** Tool returns `Graph 403: ...Insufficient privileges...`

**Cause:** The SP has the right tenant and identity but is missing the
specific Graph application permission, **or admin consent wasn't granted**.

**Fix:**
1. Entra → App registrations → your app → API permissions
2. Look at the `Status` column for each permission
3. Every needed permission must show `Granted for <tenant>` ✅
4. If not, click "Grant admin consent for `<tenant>`" — this requires
   Global Admin or Privileged Role Admin
5. Required permissions (all Application, not Delegated):
   - `SecurityIncident.Read.All`
   - `SecurityAlert.Read.All`
   - `User.Read.All`
   - `IdentityRiskyUser.Read.All`
   - `UserAuthenticationMethod.Read.All`
   - `AuditLog.Read.All`

### HTTP 403 from Log Analytics

**Symptom:** `run_kql` returns `Log Analytics error 403`

**Cause:** SP lacks `Log Analytics Reader` on the workspace.

**Fix:**
1. Azure portal → your Log Analytics workspace → Access control (IAM)
2. Add role assignment → `Log Analytics Reader` → select your SP by app name
3. Wait 1–2 minutes for the assignment to propagate

If you already added it, check the *scope* — assignments at the workspace
work, at the resource group work, at the subscription work. But the role
must be `Log Analytics Reader` (or higher), not `Reader` (which doesn't
grant query access).

### HTTP 404 from Log Analytics

**Symptom:** `run_kql` returns `Log Analytics error 404` or "Workspace not found"

**Cause:** Wrong `AZURE_LOG_ANALYTICS_WORKSPACE_ID` in `.env`.

**Fix:** It's the **workspace ID** (a GUID), not the workspace *resource ID*.
Find it: Azure portal → workspace → Overview → "Workspace ID" near the top.

## MCP / Copilot errors

### `siem-tools` not appearing in Copilot's tool list

**Symptom:** You open Copilot Chat, switch to Agent Mode, click the tools
icon — and `siem-tools` isn't there.

**Cause:** The MCP server process isn't starting.

**Fix:**
1. Open the MCP Servers panel in VS Code (click the `{}` icon in the bottom
   status bar, or run command palette → `MCP: List Servers`)
2. Find `siem-tools` and check its status
3. Click on it to see stderr output

Common causes:
- `pip install -e mcp-apps/siem-tools-mcp` not run → `ModuleNotFoundError`
- Wrong `cwd` in `.vscode/mcp.json` → `python -m siem_tools.server` can't find the module
- Missing required env vars → server exits with "Missing required env vars: ..."

### Server starts but every tool fails immediately

**Symptom:** Tool appears in the list, but calling any of them produces an
error in chat.

**Cause:** Network reachability, certificate issues, or proxy interference.

**Fix:**
1. Check `https://graph.microsoft.com` and `https://api.loganalytics.io` are
   reachable from the machine running VS Code:
   ```bash
   curl -I https://graph.microsoft.com/v1.0/$metadata
   curl -I https://api.loganalytics.io/v1
   ```
2. If you're behind a corporate proxy, set `HTTPS_PROXY` in the `env`
   block of `.vscode/mcp.json`:
   ```json
   "env": {
     "HTTPS_PROXY": "http://proxy.corp.example.com:8080",
     ...
   }
   ```
3. If you're using a self-signed cert on the proxy, you may need
   `REQUESTS_CA_BUNDLE` or `SSL_CERT_FILE` pointed at your corp CA bundle.

### Copilot says "I don't have access to those tools"

**Symptom:** You ask the agent to triage and it replies that it can't.

**Cause:** Chat is in Ask mode, not Agent mode.

**Fix:** Switch the dropdown above the chat input from **Ask** to **Agent**.
Tools only appear in Agent mode.

### "Tool permission denied" every call

**Symptom:** Copilot keeps asking permission for each tool call, even after
you said "always allow."

**Cause:** VS Code's per-server allow-list isn't persisting.

**Fix:** In VS Code settings, search for `mcp` and look at
`mcp.tools.autoApprove` — you can set it to auto-approve specific tools.
Be deliberate about which: `run_kql` is fine to auto-approve in a dev
tenant, less fine in production where a malformed query can cost money.

## KQL errors

### "SemanticError: 'X' is not defined"

**Symptom:** `run_kql` returns an error mentioning an undefined column.

**Cause:** The schema in your workspace doesn't match what the query
expects. Sentinel + Defender tables vary by what's licensed and connected.

**Fix:**
1. Ask the agent: "Check what columns are actually in SigninLogs in this
   workspace and rewrite the query."
2. The agent will run `SigninLogs | take 0 | getschema` and adapt.
3. If a query in `queries/` doesn't work in your tenant, update the file —
   that's the point of having it version-controlled.

### Query returns zero rows when you know there should be data

**Symptom:** A hunt that should match returns `rowCount: 0`.

**Causes:**
- Wrong time window (default is P7D — too short for slow-burn investigations)
- Wrong table (e.g., `SigninLogs` vs `AADNonInteractiveUserSignInLogs`)
- Filter typo (case-sensitivity, smart-quotes, trailing spaces)

**Fix:**
1. Ask the agent to widen the window: "Re-run with timespan P30D."
2. Ask the agent to drop filters one at a time until you see data, then
   identify which filter excluded it.
3. Run the query manually in the portal to confirm the filter logic
   matches what you intend.

### "QueryThrottledException" from Log Analytics

**Symptom:** Multiple queries failing with throttling errors.

**Cause:** Log Analytics rate limits — you ran too many queries too fast.

**Fix:** Wait 60 seconds and retry. If this is happening often, you're
either:
- Running batch eval over too many incidents at once (space them out)
- Multiple analysts hitting the same workspace (consider a dedicated
  triage workspace or upgraded SKU)

## Enrichment errors

### `enrich_ip` returns `{"skipped": "no VirusTotal key"}` for every IP

**Symptom:** All three TI sources skipped.

**Cause:** API keys not set in `.env`, or set but empty.

**Fix:** Add keys to `.env`. Free tiers are fine for low volume:
- VirusTotal: [virustotal.com/gui/my-apikey](https://www.virustotal.com/gui/my-apikey) (free: 500/day)
- AbuseIPDB: [abuseipdb.com/account/api](https://www.abuseipdb.com/account/api) (free: 1000/day)
- GreyNoise: works without a key (community endpoint)

If keys are set and still skipped, check there's no trailing whitespace in
`.env`. The empty-key check is `key.strip() != ""`.

### VirusTotal returns 429

**Symptom:** `{"error": "VT 429"}` on enrichment calls.

**Cause:** VT rate limit (4/min on free tier).

**Fix:** Slow down. Free tier is fine for interactive triage but breaks on
batch runs. Upgrade or batch with delays.

### AbuseIPDB returns 422

**Symptom:** `{"error": "AbuseIPDB 422", "detail": "..."}`

**Cause:** Invalid IP format. AbuseIPDB is strict about IPv4 vs IPv6.

**Fix:** Check the IP value being passed. Sometimes Sentinel entities
include IPv6 with embedded IPv4 (`::ffff:1.2.3.4`) — strip the prefix.

## Verdict-quality issues

### Verdict has thin evidence

**Symptom:** The verdict has 1–2 vague evidence claims and a high confidence.

**Cause:** Agent stopped early — common when the incident has few entities
or when a tool failed silently.

**Fix:**
```
The evidence chain is thin. What other tools should you call before
finalizing a verdict at this confidence level?
```

Or more directly:
```
Re-do the triage, this time also calling get_user_signins and
running a tenant-wide hunt on every IP in the incident.
```

### Verdict contradicts the chat transcript

**Symptom:** The agent ran 5 tools showing benign signals, but the verdict
says TruePositive (or vice versa).

**Cause:** Rare LLM drift between gathering and summarizing.

**Fix:**
```
The verdict doesn't match the evidence you gathered. Tool calls 1, 3,
and 4 showed benign indicators. Re-classify based on what you actually found.
```

If this happens twice in a row, close the chat and re-start — fresh context
helps.

### Confidence is high but the evidence is weak

**Symptom:** "Confidence: 0.97" with three thin evidence items.

**Cause:** The agent is being overconfident.

**Fix:**
```
Your confidence (0.97) doesn't match the evidence depth. What would
move this to 0.99? If you can't fill those gaps, drop confidence to
0.85–0.90.
```

The agent will usually re-calibrate. If not, you should — trust your
read of the evidence over the agent's confidence number.

## Performance / cost issues

### Triages take 5+ minutes

**Symptom:** A single incident triage runs for many minutes.

**Causes:**
- Network latency to Graph or Log Analytics (especially from a different
  region)
- Workspace ingesting heavy data — KQL queries are slow
- Agent making many redundant tool calls

**Fix:**
1. Time the individual tool calls (chat shows duration per call). The
   slowest will be `run_kql` on a big workspace.
2. Narrow time windows: tell the agent to default to `PT24H` not `P7D`
   when the incident is recent.
3. Tell the agent to batch: "Run the user enrichment and IP enrichment
   in parallel, then run the KQL queries."

### Copilot is asking permission on every tool call

**Symptom:** Productivity-killing prompt-fatigue.

**Fix:** In Copilot Chat, the permission prompt has a "Always allow" option.
Use it deliberately — fine for `list_recent_incidents` and `get_incident`,
think twice for `run_kql` (in case the agent ever writes an expensive query).

## When all else fails

1. **Read the chat transcript top to bottom.** The error is almost always
   visible there — a 403 here, an unexpected tool result there.

2. **Look at the MCP server stderr** in the MCP Servers panel. Server-side
   errors don't always surface clearly in chat.

3. **Try a smaller scope.** If `Triage incident <id>` fails, try just
   `Get incident <id>`. If that fails too, the problem is auth or basic
   connectivity, not the agent.

4. **Reset the chat.** Long chats accumulate context and occasionally
   confuse the agent. A fresh chat with the same prompt often works.

5. **Manual fallback.** This tool is a productivity aid, not a critical
   dependency. If it's broken and you have an incident to triage, do it
   manually in the portal and file an issue.
