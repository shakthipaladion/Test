# Understanding Verdicts

How to read the markdown report the agent produces, what each section
means, and how to know whether to trust it.

## The verdict shape

Every triage produces a verdict with these fields. The same fields appear
in the JSON saved to `temp/triage-<id>.json` and the markdown saved to
`reports/<skill>/<id>.md`.

```
Classification: TruePositive | FalsePositive | Benign | Inconclusive
Confidence:     0.00 – 1.00
Summary:        one sentence
Evidence:       [{claim, source, data}, ...]
Entities Investigated: users, ips, hosts, hashes, domains
KQL Queries Run: [{query, source, rowCount}, ...]
Deep-Dive Plan: [step1, step2, ...]
Recommended Actions: [action1, action2, ...]
Handoff State:  awaiting_decision
```

## What each classification means

### TruePositive

The alert is correct — there is malicious or unauthorized activity.

**Examples:**
- A successful sign-in from a confirmed-malicious IP, no MFA on the
  account, followed by data access
- A file hash with a 60/70 detection rate on VirusTotal executing on a
  user device
- A password spray pattern where multiple users were hit from one source

**What to do:** Escalate or proceed with response actions. The agent's
`recommendedActions` is a starting point but use your judgment — the
agent doesn't know your environment-specific runbooks.

### FalsePositive

The alert triggered on a real event, but the event was caused by something
benign and the agent has proof.

**Examples:**
- Failed sign-ins followed by success — but `AuditLogs` shows a
  self-service password reset between them
- A "suspicious PowerShell" alert that's a sanctioned admin script running
  on schedule
- "Impossible travel" between two cities, but both legs trace to the
  same corporate VPN egress

**What to do:** Close the incident with the verdict summary as the
resolution comment. The agent's evidence chain is the audit trail —
paste it directly so anyone reviewing later sees the reasoning.

### Benign

A real event with a non-malicious cause that wasn't a misfire — the rule
just isn't precise enough.

**Examples:**
- An admin running a known-good remote management tool that fires a
  "lateral movement" detection
- A vulnerability scanner causing brute-force-pattern logon failures
- A legitimate OAuth grant to a sanctioned third-party app

**What to do:** Close, but also consider whether the rule needs tuning.
If you see the same Benign pattern three times in a week, it's a tuning
candidate, not just an FP.

### Inconclusive

The agent could not reach a confident decision. Confidence is always
< 0.85 for Inconclusive verdicts.

**Examples:**
- An IP that VirusTotal flags as malicious, but no internal log showed
  any connection to it (maybe blocked at perimeter, maybe data missing)
- A user with anomalous sign-in patterns but Identity Protection
  shows clean — could be legitimate travel, could be token theft
- A file hash that's unknown to VirusTotal and only seen on one device

**What to do:** Follow the `deepDivePlan`. Each step is something specific
to check. Usually 2–3 follow-up prompts in the same chat resolve it:

```
Step 1 says check if the user has a registered travel pattern.
Pull the last 90 days of sign-in locations for this user.
```

**Don't** treat Inconclusive as "probably nothing." That's exactly the
alert fatigue this tool exists to fight.

## Reading confidence

Confidence is the agent's honest read on the evidence, not a probability.

| Range | Meaning |
|---|---|
| **0.95–0.99** | Multiple independent signals all pointing the same way |
| **0.85–0.94** | One strong signal, no contradicting evidence |
| **< 0.85** | Must be `Inconclusive` (this is a hard rule the agent follows) |

When confidence is **0.99**, that doesn't mean "definitely correct." It
means "based on every tool result I gathered, every signal agrees and
there's no contradiction." You should still glance at the evidence — the
agent could have missed something it didn't know to look for.

When confidence is **0.85**, treat it as "probably correct but I'd like
another set of eyes." Fine for FP closure on a low-severity alert; worth
a second look on a high-severity one.

When confidence is **< 0.85** and the classification is *not*
Inconclusive — that's a bug. Tell the agent: "your confidence is below
0.85, the classification should be Inconclusive."

## Reading the evidence chain

This is the most important section. The verdict is only as good as the
evidence.

```markdown
## Evidence

| # | Claim | Source |
|---|-------|--------|
| 1 | 8 failed sign-ins for alice@contoso.com between 14:28:11 and 14:30:02 UTC from IP 203.0.113.42 | queries/identity/signin-failures-then-success.kql |
| 2 | Self-service password reset completed at 14:29:45 UTC, initiated by alice@contoso.com from the same IP | queries/identity/signin-failures-then-success.kql |
| 3 | Successful interactive sign-in at 14:30:08 UTC, same user, same IP, MFA satisfied via Authenticator | queries/identity/signin-failures-then-success.kql |
| 4 | IP 203.0.113.42 classified by GreyNoise as benign (known corporate VPN egress) | enrich_ip |
```

**What to check:**

1. **Every claim has specific numbers, timestamps, or named entities.**
   "Many failures" is not evidence. "8 failures between 14:28:11 and
   14:30:02 UTC" is.

2. **Every claim has a source that's a real tool or query.** If you see
   `source: "general knowledge"` or `source: "context"`, that's the
   agent guessing. Be skeptical.

3. **Sources are reproducible.** Open `queries/identity/signin-failures-then-success.kql`
   — that file exists, you can run it in the portal, and you'll get the
   same data.

4. **No contradictions.** If claim 1 says "no MFA on the account" and
   claim 4 says "MFA satisfied via Authenticator," something's wrong.
   The agent should have caught that and dropped to Inconclusive. If it
   didn't, you should.

## Reading the KQL list

```markdown
## KQL Queries Run

| # | Source | Rows |
|---|--------|------|
| 1 | queries/identity/signin-failures-then-success.kql | 12 |
| 2 | queries/network/ip-tenant-wide-activity.kql | 0 |
| 3 | ad-hoc | 3 |
```

**Library queries** (`queries/...kql`) are the trustworthy ones — they're
verified KQL someone has used before. You can open the file to see exactly
what ran.

**Ad-hoc queries** are KQL the agent wrote on the spot for this
investigation. They're not necessarily wrong, but they haven't been
peer-reviewed. If the verdict hinges on an ad-hoc query, consider asking
the agent to save it to the library so it gets a second look next time.

**`rowCount: 0` matters.** An empty result is evidence too — "we searched
for X and found nothing" can be exactly what supports a Benign verdict.
But it can also mean "the query didn't match anything because the field
name was wrong." Spot-check the queries that returned 0 rows; sometimes
they're false zeros.

## Reading the deep-dive plan

For TruePositive verdicts, this is "here's how to investigate further."

For Inconclusive verdicts, this is "here's what would resolve the
ambiguity."

For FalsePositive / Benign verdicts, this is usually short or empty —
the case is closed.

Each item should be actionable, not vague:

✅ "Pull the last 30 days of sign-ins from IP 203.0.113.42 across all
   users to confirm this is the corporate VPN egress."

❌ "Investigate the user further."

If you see a vague plan, ask the agent:
```
Make the deep-dive plan more specific. Each step should be a concrete
KQL query or tool call I can execute.
```

## Reading recommended actions

These are **advisory only**. The agent has no tools to execute response
actions. The wording should make this clear:

✅ "Recommend isolating host `WS-042` via Defender for Endpoint while
   forensic acquisition is in progress."

✅ "Suggest disabling the user account `alice@contoso.com` pending review."

❌ "Isolate WS-042." (imperative — the agent should not phrase it this way)

If actions are phrased as imperatives, the agent has slipped. Tell it:
```
Re-phrase recommended actions as advisory recommendations for human
execution, not commands.
```

## Spotting hallucinations

The agent is heavily prompted to cite sources and use only tool data,
but LLMs can still drift. Watch for:

| Smell | What it might mean |
|---|---|
| A claim with no entity, timestamp, or number | The agent invented a generalization |
| A `source` like "context" or "knowledge" | Not backed by an actual tool call |
| Evidence about a tool that wasn't called | Pure hallucination |
| Numbers that don't match the KQL `rowCount` | The agent miscounted or made up data |
| A verdict that doesn't match the evidence | The summary drifted from the chain |

When you spot one, say:
```
That claim isn't supported by any tool call in this chat. Either remove
it or run the tool that would back it.
```

The agent will usually correct itself. If it doesn't, the verdict is
unreliable — close the chat and start fresh, or fall back to manual
triage for that incident.

## Trust calibration

After your first 20 triages, you'll have a feel for when the agent is
reliable and when it isn't. Rough heuristics from teams who have run
this kind of tool:

- **High trust:** Sign-in based alerts (lots of signal, mature tooling),
  IoC verdicts (external TI is well-defined), FP detection on common
  patterns (password resets, VPN egress).

- **Medium trust:** Multi-entity incidents, anything involving custom
  detections you've written, scope-drift / behavioral alerts.

- **Lower trust:** Anything with sparse logs (a host that just came
  online), incidents that span products in unusual ways, anything that
  hinges on a single ad-hoc KQL query.

Calibrate by spot-checking: pick 1 in 10 verdicts and reproduce them
manually in the portal. If your spot-checks agree with the agent 95%+
of the time, you can rely on it. If they disagree often, look at where
— that's where you need a new skill, a new query in the library, or a
tuning conversation with the rule that fired the incident.
