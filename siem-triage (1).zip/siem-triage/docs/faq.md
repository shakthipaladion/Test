# FAQ

Quick answers to common questions.

## What it does

**Q: What does this tool actually do?**
A: Automates the first 30 minutes of incident triage in Microsoft Sentinel
and Defender XDR. Pulls the incident, enriches the entities, runs hunts,
produces a structured verdict — so a human can focus on the decision
rather than the data gathering.

**Q: Is this a replacement for Microsoft Security Copilot?**
A: No, it's a lightweight alternative for teams without Security Copilot
licenses. Security Copilot is more powerful, more integrated, and paid.
This tool is free (beyond your existing GitHub Copilot subscription),
self-hosted, and gives you full visibility into prompts, tool calls, and
queries.

**Q: Will the agent close incidents automatically?**
A: No. The agent has no tools to close incidents, disable accounts, or
isolate hosts. Every recommendation is advisory and requires a human to
execute it.

**Q: Can I trust the verdicts?**
A: Trust them the way you'd trust a junior analyst's first pass — read the
evidence, sanity-check the conclusion, decide for yourself. The agent
cites every claim and shows every tool call, so verification is fast.
See [`understanding-verdicts.md`](understanding-verdicts.md) for trust
calibration.

## Setup

**Q: Do I need to enable Sentinel data lake?**
A: No. This is the main difference from Microsoft's hosted Sentinel MCP
server. Your existing Log Analytics workspace works as-is.

**Q: Can I use a managed identity instead of a Service Principal?**
A: Yes, with code changes. Replace `ClientSecretCredential` in `auth.py`
with `ManagedIdentityCredential` or `DefaultAzureCredential`. The rest of
the tool works unchanged.

**Q: Can I use my own user account instead of a Service Principal?**
A: Yes, with code changes — use `InteractiveBrowserCredential` or
`AzureCliCredential` and delegated Graph permissions. Trade-off: each
tool call runs as you, so it appears in audit logs under your account,
not a service identity. Some SOCs prefer this for traceability.

**Q: How do I add a new tool?**
A: Three steps:
1. Add the implementation in a new or existing file under
   `mcp-apps/siem-tools-mcp/src/siem_tools/`
2. Add the tool definition (name, description, input schema) to the
   `TOOLS` list in `tools.py`
3. Add a handler entry to the `HANDLERS` dict in `tools.py`

Then optionally update `.github/copilot-instructions.md` to teach the
agent when to call it.

**Q: How do I add a new skill?**
A: Create a new folder under `.github/skills/<skill-name>/` with a
`SKILL.md` file. Use the existing skills as a template — frontmatter with
`description` and `triggers`, then a workflow narrative. Add it to the
skill-routing table in `.github/copilot-instructions.md`.

## Operation

**Q: How many incidents can I triage per hour?**
A: Realistically 5–10 incidents per hour for an analyst working through a
queue, vs 2–3 doing it manually. Speed depends on incident complexity and
Log Analytics query time.

**Q: Does it work for multiple analysts at once?**
A: Yes, but each analyst runs their own local MCP server on their own
machine. There's no shared state. If you want shared dashboards or
cross-analyst queues, you'd need to add infrastructure (see the
"Outgrowing this" question below).

**Q: Can I run it unattended on a schedule?**
A: Not as designed. The agent runs only when you have a chat open. If you
want automation, the right pattern is:
1. Logic App or Function App fires on incident creation
2. Calls a webhook that runs the MCP server's tools directly (skipping
   Copilot)
3. Writes the verdict to a database or comments on the incident

You'd be rebuilding part of Rod Trent's SIEMTriage stack. Consider just
using that if you need this.

**Q: Where do the verdict reports go?**
A: `reports/<skill>/<incident-id>.md` — markdown files in your repo. Commit
them for an audit trail, or add `reports/` to `.gitignore` if your team
considers them sensitive. The raw JSON also goes to `temp/`, which gets
cleaned up after 3 days by `scripts/cleanup_temp.py`.

**Q: What does "Inconclusive" mean?**
A: The agent has confidence below 0.85 — it genuinely couldn't decide
between malicious and benign. The verdict's `deepDivePlan` will list what
additional data would resolve it. Follow the plan in 2–3 more prompts;
don't close Inconclusive verdicts without investigating.

## Cost

**Q: What does this cost to run?**
A: Beyond what you're already paying for:
- GitHub Copilot subscription (your existing one)
- Microsoft Sentinel / Defender XDR (your existing licensing)
- Optional TI APIs:
  - VirusTotal free tier: 500 lookups/day, $0
  - AbuseIPDB free tier: 1000 lookups/day, $0
  - GreyNoise community tier: $0

**Q: Does it consume Copilot tokens?**
A: Yes — each chat message counts against your Copilot subscription.
Triage chats are typically short (10–30 messages including tool calls),
so a busy analyst running 20 triages per day fits comfortably in standard
limits.

**Q: Are there Azure costs?**
A: Each KQL query against Log Analytics incurs query-time CPU charges,
but they're typically fractions of a cent. A single triage might run 5–10
queries; if you're triaging 100 incidents/day, expect a few dollars/month
in incremental query costs.

## Privacy and security

**Q: Does my incident data leave my tenant?**
A: Microsoft tenant data (incidents, alerts, KQL results) flows to:
- The MCP server on your local machine
- GitHub Copilot's inference endpoint (so the model can reason about it)
- VirusTotal / AbuseIPDB / GreyNoise (only the IoCs you choose to enrich)

If sending incident details to Copilot's inference is a concern, talk to
GitHub about your enterprise data handling agreement — Copilot Business
and Enterprise have different policies than Pro.

**Q: Where are the SP secrets stored?**
A: `.env` is gitignored. VS Code's `${input:clientSecret}` prompt caches
in your OS keychain (Keychain on macOS, Credential Manager on Windows,
libsecret on Linux). Treat the local machine like any other privileged
endpoint.

**Q: Can I rotate the SP secret without breaking the tool?**
A: Yes. Create a new secret in Entra, update `AZURE_CLIENT_SECRET` in
`.env` and the keychain entry in VS Code, restart the MCP server. Delete
the old secret in the portal once the new one works.

**Q: What audit trail does this leave?**
A: Several:
- **In Entra:** Every Graph API call appears in the sign-in logs and
  audit logs under the SP's identity, with the IP of the machine running
  the MCP server.
- **In Sentinel:** Every KQL query appears in `LAQueryLogs` if you have
  that enabled.
- **Locally:** Every chat transcript in VS Code, every report in
  `reports/`, every working JSON in `temp/`.
- **In git:** Commit `reports/` to keep verdict history alongside code
  changes to skills and queries.

## Limits

**Q: What's the biggest workspace this works against?**
A: No hard limit — it's just calling the same APIs you'd use in the
portal. KQL query time grows with workspace size, so a 10TB/day workspace
will give slower hunts than a 100GB/day one. Use `take` ceilings to keep
queries bounded.

**Q: Can it triage incidents from multiple tenants?**
A: One tenant per `.env`. To triage multiple tenants, open separate VS Code
windows with separate workspaces and separate `.env` files. The MCP
server config is per-workspace.

**Q: Does it work with classic Sentinel (no Defender XDR unification)?**
A: Mostly. The Graph Security API works in both cases. Some Defender-XDR-
specific fields will be missing in classic-Sentinel-only tenants, but the
core triage workflow works fine.

**Q: Does it work with US Government / Azure Government cloud?**
A: Yes, with config changes. Replace the Graph base URL in `graph_client.py`
with `graph.microsoft.us` and the Log Analytics URL with
`api.loganalytics.us`. Token scopes also need updating
(`graph.microsoft.us/.default` etc.). The auth flow is the same.

## Outgrowing this

**Q: When should I stop using this and build something bigger?**
A: Indicators that you've outgrown the interactive single-analyst pattern:
- You want unattended triage of every incoming incident
- You need a queue with concurrent analysts
- You need a web UI for non-technical analysts who don't use VS Code
- You want eval/accuracy dashboards on agent performance
- You need to scale past one tenant from one identity

When you hit two or three of these, look at:
- **Rod Trent's SIEMTriage** — the productionized version of this idea
- **Microsoft Security Copilot** — if budget allows
- **Build out from this base** — add a worker, queue, database
  incrementally; the MCP server you've already built doesn't change.

The skills and queries you've curated in this layout transfer to any of
those paths — that's the most valuable thing you build along the way.
