# Quick Reference

One-page cheat sheet. For everything else, see [`docs/`](docs/).

## Common prompts

| What I want | Type in Copilot Chat (Agent Mode) |
|---|---|
| See current incidents | `List my 5 most recent active incidents.` |
| Triage one | `Triage incident <id>. Produce a verdict with evidence.` |
| Investigate a user | `Investigate user user@domain.com for the last 7 days.` |
| Check an IP/hash/domain | `Investigate IP 203.0.113.42` · `Is this hash malicious? <sha256>` · `Look up domain evil.example.com` |
| Pivot from a triage | `Now investigate the user from that incident.` |
| Write a hunt | `Write a KQL query to find <pattern>.` |
| Save useful query | `Save that query to the library with a metadata header.` |
| End-of-shift summary | `Summarize what I triaged today. What's still Inconclusive?` |

## Verdict classifications

| Class | Meaning | Action |
|---|---|---|
| **TruePositive** | Confirmed malicious | Escalate / respond |
| **FalsePositive** | Real event, benign cause, proven | Close with evidence in comments |
| **Benign** | Real event, expected behavior, rule too noisy | Close + flag for tuning |
| **Inconclusive** | Confidence < 0.85, can't decide | Follow `deepDivePlan` — don't close blind |

## Tool inventory

| Tool | Purpose |
|---|---|
| `list_recent_incidents` | List Sentinel/Defender XDR incidents |
| `get_incident` | Pull incident + alerts + entities by ID |
| `get_alert` | Pull single alert with full detail |
| `run_kql` | Execute KQL against Log Analytics |
| `get_risky_user` | Entra Identity Protection risk state |
| `get_user_auth_methods` | List user's MFA methods |
| `get_user_signins` | Recent interactive sign-ins via Graph |
| `enrich_ip` | VirusTotal + AbuseIPDB + GreyNoise |
| `enrich_hash` | VirusTotal file hash lookup |
| `enrich_domain` | VirusTotal domain lookup |

## File locations

| What | Where |
|---|---|
| Universal agent rules | `.github/copilot-instructions.md` |
| Skill workflows | `.github/skills/<skill>/SKILL.md` |
| KQL library | `queries/<domain>/*.kql` |
| Generated reports | `reports/<skill>/<id>.md` |
| Working JSON | `temp/triage-<id>.json` |
| MCP server config | `.vscode/mcp.json` (gitignored) |
| Secrets | `.env` (gitignored) |
| MCP server code | `mcp-apps/siem-tools-mcp/src/siem_tools/` |

## Search the KQL library

```bash
grep -ri "password spray" queries/      # by keyword
grep -ri "T1110" queries/               # by MITRE technique
grep -ri "SigninLogs" queries/          # by table
```

## Emergency commands

| Situation | Run this |
|---|---|
| MCP server won't start | `cd mcp-apps/siem-tools-mcp && pytest -q` |
| Can't authenticate | `python -c "import sys;sys.path.insert(0,'mcp-apps/siem-tools-mcp/src');from dotenv import load_dotenv;load_dotenv();from siem_tools.auth import graph_token;print(len(graph_token()))"` |
| KQL not working | `python -c "import asyncio,sys;sys.path.insert(0,'mcp-apps/siem-tools-mcp/src');from dotenv import load_dotenv;load_dotenv();from siem_tools.loganalytics import run_kql;print(asyncio.run(run_kql('SigninLogs|take 1','PT1H')))"` |
| Verify TI keys | `python scripts/enrich_ips.py 8.8.8.8` |
| Clean old temp files | `python scripts/cleanup_temp.py --days 3` |
| Re-generate report from JSON | `python scripts/generate_report.py temp/triage-<id>.json` |

## Doc map

| Doc | Read when |
|---|---|
| [`docs/overview.md`](docs/overview.md) | First time — what is this thing |
| [`docs/getting-started.md`](docs/getting-started.md) | Installing |
| [`docs/service-principal-setup.md`](docs/service-principal-setup.md) | Creating the SP |
| [`docs/daily-use.md`](docs/daily-use.md) | After install, learning to use it |
| [`docs/understanding-verdicts.md`](docs/understanding-verdicts.md) | Reading reports |
| [`docs/troubleshooting.md`](docs/troubleshooting.md) | When something breaks |
| [`docs/faq.md`](docs/faq.md) | Quick answers |
| [`docs/architecture.md`](docs/architecture.md) | Curious how it works |

## Three rules you must remember

1. **The agent is read-only.** No action it suggests has been executed.
   You execute, or no one does.
2. **Inconclusive ≠ close it as low risk.** That's the alert fatigue this
   tool was built to prevent. Follow the deep-dive plan.
3. **Sanity-check the evidence.** Every claim should have a tool source
   and a specific number, timestamp, or named entity. If it doesn't,
   the agent is guessing.
