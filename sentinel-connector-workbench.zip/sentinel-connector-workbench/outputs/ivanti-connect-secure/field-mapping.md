# Ivanti Connect Secure — Field Mapping

## Native Syslog table columns (set by NXLog `<Exec>` block)

| Sentinel column | NXLog source | Notes |
|---|---|---|
| `TimeGenerated` | `parse_syslog()` timestamp | RFC 5424 ISO timestamp from the inner appliance frame |
| `Computer` | `$Hostname` (renamed from `HostName` via DCR `transformKql`) | Often the upstream relay's hostname when relayed — use `ApplianceHost` from the parser instead |
| `HostIP` | `$MessageSourceAddress` | The IP that sent the syslog frame to NXLog (may be the relay) |
| `Facility` | `$SyslogFacility` | Typically `local6` or `local7` per appliance configuration |
| `SeverityLevel` | `$SyslogSeverity` | `info` / `notice` / `err` etc. |
| `SyslogMessage` | `$Message` | The full inner payload — parser extracts everything from here |
| `ProcessName` | `$SourceName` | `PulseSecure` (preserved across the Ivanti rebrand) |
| `ProcessID` | `$ProcessID` | Often empty for this appliance |
| `SourceSystem` | Set by DCR `transformKql` to `NXLog-Ivanti-ConnectSecure` | All workbench-collected events start with `NXLog-` |

## `_CF` enrichment columns (org-standard, populated by NXLog)

| Column | Value | Source in NXLog |
|---|---|---|
| `DeviceVendor_CF` | `Ivanti` | Hardcoded literal in `<Exec>` |
| `DeviceProduct_CF` | `Connect Secure` | Hardcoded literal in `<Exec>` |
| `DatasourceName_CF` | `Ivanti_ConnectSecure` | Hardcoded literal — `<Vendor>_<Product>` PascalCase |
| `DeviceAddress_CF` | (IP NXLog received from) | `$MessageSourceAddress` — typically the relay |
| `RawLog_CF` | (verbatim wire frame) | `$raw_event` — forensic only, large |
| `NXLogInputModuleName_CF` | `im_ivanti-connectsecure_udp` | `$SourceModuleName` |
| `NXLogRouteName_CF` | `route_ivanti-connectsecure_azure` | Hardcoded literal in `<Exec>` |
| `NXLogServerName_CF` | (collector hostname) | `hostname()` |

## Parser-extracted fields (analyst-facing, set by `IvantiConnectSecureAudit()`)

### Frame-level (every event)

| Field | Type | Source | Description |
|---|---|---|---|
| `ApplianceHost` | string | `extract(@"\s+(\S+)\s+PulseSecure:", 1, Msg)` | Hostname of the originating appliance, distinct from the relay |
| `NodeID` | string | `extract(@"PulseSecure: - - - \S+ \S+ - (\S+) -", 1, Msg)` | Cluster node identifier (e.g., `ssl1_dr`, `SSL2`) |
| `SourceIP` | string | `extract(@"\s+\[([^\]]+)\]\s+\S+::System", 1, Msg)` | IP attributed to the event source (`127.0.0.1` = local appliance) |
| `Realm` | string | `extract(@"\]\s+([^:]+?)::System", 1, Msg)` | Top-level realm role: `Root`, `Default Network`, `SSL2` |
| `RealmName` | string | `extract(@"::System\(([^)]*)\)", 1, Msg)` | Specific realm name, empty parens if not realm-tagged |
| `EventText` | string | `extract(@"\)\[\]\[\]\s+-\s+(.+)$", 1, Msg)` | Free-form event description — feeds all per-stream extractions |
| `Stream` | string | `case(...)` over `EventText` content | Logical stream: `UserAccess` / `WebServer` / `AdminAccess` / `Events` |
| `EventCategory` | string | ASIM `case(...)` | Maps to `Authentication`, `AuthenticationFailed`, `NetworkSessionDeny`, etc. |

### UserAccess / authentication

| Field | Type | Source | Notes |
|---|---|---|---|
| `VPNUser` | string | `extract(@"user '([^']+)'", 1, EventText)` | Authenticating user — wire format consistently single-quoted `'user@realm'` |
| `AuthenticationResult` | string | `extract(@"^(Login (?:succeeded|failed)\|Authentication failed\|Account locked)", 1, EventText)` | Login outcome string |
| `HostCheckerResult` | string | `extract(@"Host Checker policy ([^.]+)", 1, EventText)` | Endpoint compliance result — `matched` or `failed` |

### WebServer / pre-auth

| Field | Type | Source | Notes |
|---|---|---|---|
| `RequestUrl` | string | `extract(@"Unauthenticated request url (\S+)", 1, EventText)` | **Crown-jewel field for CVE detection** — anomalous URLs targeting `/dana-na/`, `/dana-cached/`, `/dana-ws/` |
| `ClientSourceIP` | string | `extract(@"(?:came from IP\|connection from\|source IP ')(\S+?)['.\s]", 1, EventText)` | External client IP making pre-auth request |
| `SslFailureReason` | string | `extract(@"Reason: '([^']+)'", 1, EventText)` | TLS handshake failure reason |
| `HostHeaderRejected` | bool | `EventText has "host header was rejected"` | Host-header-based access denial |
| `RealmRestrictionFail` | bool | `EventText has "source IP restriction"` | Realm source-IP-policy denial |
| `SuspiciousUrl` | bool | Regex match against known CVE-PoC URLs | Flags CVE-2019-11510, CVE-2023-46805/2024-21887, CVE-2025-0282 PoC paths |

### AdminAccess / config change

| Field | Type | Source | Notes |
|---|---|---|---|
| `AdminUser` | string | `extract(@"(?:Admin\|Administrator) '([^']+)'", 1, EventText)` | Administrator initiating the change |
| `ConfigChangeAction` | string | `extract(@"\b(modified\|created\|deleted\|enabled\|disabled)\b", 1, EventText)` | Change verb |
| `ConfigChangeTarget` | string | `extract(@"(?:modified\|created\|deleted\|enabled\|disabled) (\S+(?:\s+\S+)?)\s*'?", 1, EventText)` | Object modified — `Sign-in URL`, `Realm`, `Authentication Server`, etc. |

## Securonix → Sentinel migration crosswalk

For analysts moving Securonix VPN-related queries to Sentinel:

| Securonix field | Sentinel equivalent (Ivanti) |
|---|---|
| `accountname` | `VPNUser` |
| `eventoutcome` | `AuthenticationResult` |
| `sourceaddress` | `ClientSourceIP` |
| `eventaction` | `EventCategory` |
| `customstring1` (was: appliance hostname) | `ApplianceHost` |
| `customstring2` (was: cluster node) | `NodeID` |
| `customstring3` (was: realm) | `Realm` / `RealmName` |
| `requesturl` | `RequestUrl` |
| `eventseverity` | `SeverityLevel` |
| `transactionnumber` | (no equivalent) — pivot via correlation ID extracted from `EventText` if needed |
