# Palo Alto Networks PAN-OS — Field Mapping

## Native CommonSecurityLog columns (set by NXLog `parse_cef()` + DCR)

| Sentinel column | NXLog source | Notes |
|---|---|---|
| `TimeGenerated` | `$EventTime` from CEF `rt` | The rt extension uses Unix-millis; NXLog converts |
| `Computer` | `$DeviceName` (renamed via DCR `transformKql`) | Hostname of the PAN device |
| `DeviceVendor` | CEF header field 2 | `Palo Alto Networks` |
| `DeviceProduct` | CEF header field 3 | `PAN-OS` |
| `DeviceVersion` | CEF header field 4 | e.g. `11.1.0` |
| `DeviceEventClassID` | CEF header field 5 | `TRAFFIC` / `THREAT` / `URL` / `DATA` / `SYSTEM` / `CONFIG` / `HIPMATCH` |
| `Activity` | CEF header field 6 (Name) | Human-readable event name |
| `LogSeverity` | CEF header field 7 | Numeric 1-10 |
| `DeviceAction` | CEF `act` extension | `allow` / `deny` / `drop` / `block` / `alert` / `reset-*` |
| `Protocol` | CEF `proto` extension | `tcp` / `udp` / `icmp` |
| `ApplicationProtocol` | CEF `app` extension | `ssl` / `web-browsing` / `dns` / etc. |
| `SourceIP` / `SourcePort` | CEF `src` / `spt` | |
| `SourceUserName` | CEF `suser` | User identified via User-ID |
| `DestinationIP` / `DestinationPort` | CEF `dst` / `dpt` | |
| `DestinationUserName` | CEF `duser` | Server-side user (rare) |
| `RequestURL` | CEF `request` | Full URL for URL-filtering events |
| `RequestMethod` | CEF `requestMethod` | HTTP method (URL events) |
| `RequestClientApplication` | CEF `requestClientApplication` | User-Agent header |
| `ReceivedBytes` / `SentBytes` | CEF `in` / `out` | Session byte counts |

## `_CF` enrichment columns (org-standard, populated by NXLog)

| Column | Value | Source in NXLog |
|---|---|---|
| `DeviceVendor_CF` | `Palo Alto Networks` | Hardcoded literal in `<Exec>` |
| `DeviceProduct_CF` | `PAN-OS` | Hardcoded literal in `<Exec>` |
| `DatasourceName_CF` | `PaloAltoNetworks_PANOS` | Hardcoded literal — `<Vendor>_<Product>` PascalCase |
| `DeviceAddress_CF` | (IP NXLog received from) | `$MessageSourceAddress` |
| `RawLog_CF` | (verbatim CEF wire frame) | `$raw_event` — forensic only |
| `NXLogInputModuleName_CF` | `im_paloaltonetworks-panos_udp` | `$SourceModuleName` |
| `NXLogRouteName_CF` | `route_paloaltonetworks-panos_azure` | Hardcoded literal |
| `NXLogServerName_CF` | (collector hostname) | `hostname()` |

## Parser-extracted fields (from `AdditionalExtensions`)

PAN-OS sends ~40 vendor-specific extensions in the CEF `extension` field. The most-queried ones are extracted here:

### Policy and session

| Field | Type | CEF extension | Notes |
|---|---|---|---|
| `PolicyName` | string | `PanOSRuleName` | Security policy rule name that matched |
| `PolicyUUID` | string | `PanOSRuleUUID` | Policy unique identifier (stable across rule renames) |
| `SessionID` | long | `PanOSSessionID` | Firewall session — pivot field for flow correlation |
| `SessionDuration` | int | `PanOSElapsedTime` | Seconds the session lasted |

### Threat and URL filtering

| Field | Type | CEF extension | Notes |
|---|---|---|---|
| `ThreatID` | int | `PanOSThreatID` | PAN-OS threat signature ID |
| `ThreatCategory` | string | `PanOSThreatCategory` | `vulnerability` / `spyware` / `virus` / `phishing` |
| `Severity` | string | `PanOSSeverity` | `critical` / `high` / `medium` / `low` / `informational` |
| `URLCategory` | string | `PanOSURLCategory` | URL filtering category |
| `URLCategoryList` | string | `PanOSURLCategoryList` | Multi-category match list |
| `AppCategory` | string | `PanOSAppCategory` | Application identification category |
| `AppSubcategory` | string | `PanOSAppSubcategory` | Application sub-category |
| `HighRiskCategory` | bool | (derived) | True when URLCategory matches a curated high-risk list |
| `SuspiciousThreat` | bool | (derived) | True for high/critical Threat-stream events |

### Network topology

| Field | Type | CEF extension | Notes |
|---|---|---|---|
| `SrcZone` / `DstZone` | string | `PanOSSourceZone` / `PanOSDestinationZone` | Firewall zone names |
| `SrcCountry` / `DstCountry` | string | `PanOSSourceLocation` / `PanOSDestinationLocation` | Geo-IP country codes |
| `Direction` | string | `PanOSDirection` | `client-to-server` / `server-to-client` |

### NAT and counts

| Field | Type | CEF extension | Notes |
|---|---|---|---|
| `NATSourceIP` / `NATSourcePort` | string / int | `PanOSNATSourceIP` / `PanOSNATSourcePort` | Post-NAT source |
| `NATDestIP` / `NATDestPort` | string / int | `PanOSNATDestinationIP` / `PanOSNATDestinationPort` | Post-NAT destination |
| `PacketsSent` / `PacketsReceived` | long | `PanOSPacketsSent` / `PanOSPacketsReceived` | Session packet counts |

### Web browsing context

| Field | Type | CEF extension | Notes |
|---|---|---|---|
| `XForwardedFor` | string | `PanOSXForwardedFor` | XFF header from HTTP client |
| `UserAgent` | string | `PanOSUserAgent` | Or use `RequestClientApplication` (auto-mapped) |
| `HTTPMethod` | string | `PanOSHTTPMethod` | Or use `RequestMethod` (auto-mapped) |
| `Referer` | string | `PanOSReferer` | HTTP Referer header |

### Identity and configuration

| Field | Type | CEF extension | Notes |
|---|---|---|---|
| `HIPName` | string | `PanOSHIPName` | Host Information Profile match name (HIPMATCH stream) |
| `AdminUser` | string | `PanOSAdminUser` | Admin who initiated configuration change |
| `ConfigChange` | string | `PanOSConfigChange` | Configuration change description |

## Securonix → Sentinel migration crosswalk

For analysts moving Securonix PAN-OS queries to Sentinel:

| Securonix field | Sentinel equivalent (PAN-OS) |
|---|---|
| `sourceaddress` | `SourceIP` |
| `destinationaddress` | `DestinationIP` |
| `sourceport` | `SourcePort` |
| `destinationport` | `DestinationPort` |
| `accountname` | `SourceUserName` |
| `eventaction` | `DeviceAction` |
| `eventoutcome` | `EventResult` (derived in parser) |
| `applicationname` | `ApplicationProtocol` |
| `protocol` | `Protocol` |
| `bytesin` / `bytesout` | `ReceivedBytes` / `SentBytes` |
| `customstring1` (was: rule name) | `PolicyName` |
| `customstring2` (was: URL category) | `URLCategory` |
| `customstring6` (was: threat name) | `ThreatCategory` |
| `transactionnumber` (was: session ID) | `SessionID` |
| `requesturl` | `RequestURL` |
| `additionalinfo` | `AdditionalExtensions` (then `extract()` for specific fields) |

## Things deliberately NOT auto-extracted

These extensions are populated in `AdditionalExtensions` but not extracted by default — promote them to `extend` clauses if your environment queries them often:

- `PanOSContentType` — MIME type for URL events
- `PanOSPcapID` — packet capture file ID (forensic pivot)
- `PanOSReportID` — WildFire report ID
- `PanOSDeviceGroupHierarchyLevel*` — Panorama device-group context
- `PanOSVirtualSystem` — vsys name (multi-tenant deployments)
- `PanOSFlags` — generic firewall session flags

Run a one-off query to find frequently-used unparsed fields:
```kql
PaloAltoNetworksPANOSAudit(ago(7d), now())
| extend ext = AdditionalExtensions
| extend keys = extract_all(@'PanOS([A-Za-z]+)=', ext)
| mv-expand keys
| summarize count() by tostring(keys)
| order by count_ desc
```
