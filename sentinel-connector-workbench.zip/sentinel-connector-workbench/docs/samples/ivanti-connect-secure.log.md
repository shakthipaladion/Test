# Ivanti Connect Secure — Sample Wire-Format Logs

Sanitised samples of the seven event types the parser handles. Each is a
complete frame as it arrives at NXLog after an upstream syslog relay has
wrapped the appliance's RFC 5424 payload in an outer RFC 3164 envelope.

`parse_syslog()` consumes the outer header. The embedded
`1 [iso-ts] [appliance-host] PulseSecure: - - -` 5424 frame and the
event text are preserved in `$SyslogMessage` for the parser's
`extract()` regex work.

All identifiers below are placeholders. Real samples should be
sanitised similarly before committing to the repo.

## Sample 1 — VPN Login Success (UserAccess stream)
```
<14>Jan 28 13:42:11 [relay-ip] 1 2026-01-28T13:42:11.234Z [appliance-host] PulseSecure: - - - id=auth_succ - SSL2 - [10.40.20.5] Default Network::System(example.test)[][] - Login succeeded for user 'jdoe@example.test' from 10.40.20.5
```

## Sample 2 — VPN Login Failure (UserAccess stream)
```
<14>Jan 28 13:42:14 [relay-ip] 1 2026-01-28T13:42:14.567Z [appliance-host] PulseSecure: - - - id=auth_fail - SSL2 - [203.0.113.45] Default Network::System(example.test)[][] - Login failed for user 'jdoe@example.test' from 203.0.113.45 - Reason: 'Invalid credentials'
```

## Sample 3 — Account Locked (UserAccess stream)
```
<14>Jan 28 13:42:17 [relay-ip] 1 2026-01-28T13:42:17.890Z [appliance-host] PulseSecure: - - - id=acct_lock - SSL2 - [203.0.113.45] Default Network::System(example.test)[][] - Account locked for user 'jdoe@example.test' from 203.0.113.45 - 5 failed attempts within policy window
```

## Sample 4 — Pre-Auth URL Request (WebServer stream) — CVE PoC shape
```
<14>Jan 28 13:43:22 [relay-ip] 1 2026-01-28T13:43:22.001Z [appliance-host] PulseSecure: - - - id=web_unauth - SSL2 - [127.0.0.1] Root::System()[][] - Unauthenticated request url /dana-na/../dana/html5acc/guacamole/../../../../../../../etc/passwd?/dana/html5acc/guacamole/ came from IP 198.51.100.77
```

## Sample 5 — SSL Negotiation Failure (WebServer stream)
```
<14>Jan 28 13:43:30 [relay-ip] 1 2026-01-28T13:43:30.110Z [appliance-host] PulseSecure: - - - id=ssl_fail - SSL2 - [127.0.0.1] Root::System()[][] - SSL negotiation failed while client at source IP '198.51.100.77' - Reason: 'unexpected eof while reading'
```

## Sample 6 — Host Header Rejected (WebServer stream)
```
<14>Jan 28 13:43:42 [relay-ip] 1 2026-01-28T13:43:42.220Z [appliance-host] PulseSecure: - - - id=hh_reject - SSL2 - [127.0.0.1] Root::System()[][] - Connection from 198.51.100.99 - host header was rejected: 'evil.example.com'
```

## Sample 7 — Admin Config Change (AdminAccess stream)
```
<14>Jan 28 13:50:01 [relay-ip] 1 2026-01-28T13:50:01.330Z [appliance-host] PulseSecure: - - - id=cfg_chg - SSL2 - [10.0.0.10] Root::System()[][] - Administrator 'admin1@example.test' modified Authentication Server 'PrimaryRADIUS' - changed shared secret
```

## Notes on the wire format

- `PulseSecure:` is the wire-format application name — preserved across the Ivanti rebrand. This is what the parser's `where SyslogMessage has "PulseSecure:"` filter keys on.
- `[iso-ts]`, `[appliance-host]` are the inner RFC 5424 fields, captured by the parser's frame-level extraction.
- `SSL2` (or `ssl1_dr`, `ssl2_dr`) is the cluster `NodeID` — distinguishes Active/Passive cluster nodes when one collector aggregates multiple appliances.
- `Default Network` and `Root` are realm names — `Realm`/`RealmName` extractions.
- Square brackets `[...]` after the `PulseSecure:` header carry the `SourceIP` (often `127.0.0.1` for appliance-internal events).
- The `EventText` after the trailing `- ` is where all higher-level fields (`VPNUser`, `RequestUrl`, `AdminUser`, etc.) live.
