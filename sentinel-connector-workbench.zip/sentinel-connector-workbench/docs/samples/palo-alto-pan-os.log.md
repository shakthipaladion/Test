# Palo Alto Networks PAN-OS — Sample Wire-Format Logs (CEF)

Sanitised CEF samples for the seven log subsystems PAN-OS emits. Each
shows the canonical CEF format produced by selecting "CEF" from the
PAN-OS Server Profile dropdown (Section 01 Step 1.3 of the integration
guide).

The CEF header is pipe-delimited with seven fields:
`CEF:<ver>|<DeviceVendor>|<DeviceProduct>|<DeviceVersion>|<DeviceEventClassID>|<Name>|<Severity>|<Extension>`

The extension is `key=value` pairs separated by spaces. Standard extensions
(`src`, `dst`, `act`, `proto`, etc.) are auto-mapped to native
CommonSecurityLog columns by NXLog's `parse_cef()`. Vendor-specific
extensions (the `PanOS*` keys) land in `AdditionalExtensions` for parser
regex extraction.

## Sample 1 — TRAFFIC allow (Stream = Traffic)
```
<14>Apr 28 13:42:11 [pan-fw-host] CEF:0|Palo Alto Networks|PAN-OS|11.1.0|TRAFFIC|allow|1|rt=Apr 28 2026 13:42:11 src=10.40.20.5 spt=51234 dst=203.0.113.10 dpt=443 act=allow proto=tcp app=ssl in=4280 out=18540 PanOSRuleName=allow-web-out PanOSSessionID=12345678 PanOSSourceZone=trust PanOSDestinationZone=untrust PanOSSourceLocation=AE PanOSDestinationLocation=US PanOSDirection=client-to-server PanOSAppCategory=networking PanOSAppSubcategory=encrypted-tunnel PanOSElapsedTime=187 PanOSPacketsSent=29 PanOSPacketsReceived=42
```

## Sample 2 — THREAT detected (Stream = Threat)
```
<14>Apr 28 13:42:14 [pan-fw-host] CEF:0|Palo Alto Networks|PAN-OS|11.1.0|THREAT|spyware|7|rt=Apr 28 2026 13:42:14 src=198.51.100.77 spt=44811 dst=10.40.20.5 dpt=443 act=block proto=tcp app=web-browsing PanOSRuleName=allow-web-out PanOSSessionID=12345701 PanOSThreatID=39082 PanOSThreatCategory=spyware PanOSSeverity=high PanOSSourceZone=untrust PanOSDestinationZone=trust PanOSSourceLocation=RU PanOSDestinationLocation=AE
```

## Sample 3 — URL filtering BLOCK (Stream = URLFiltering)
```
<14>Apr 28 13:42:18 [pan-fw-host] CEF:0|Palo Alto Networks|PAN-OS|11.1.0|URL|block-url|3|rt=Apr 28 2026 13:42:18 src=10.40.20.5 spt=51301 dst=192.0.2.42 dpt=443 act=block-url proto=tcp app=web-browsing request=https://example-malware.test/cmd.php requestMethod=GET PanOSRuleName=url-filter-default PanOSSessionID=12345710 PanOSURLCategory=command-and-control PanOSURLCategoryList=command-and-control,malware suser=jdoe@example.test
```

## Sample 4 — URL filtering ALLOW (Stream = URLFiltering, high volume)
```
<14>Apr 28 13:42:20 [pan-fw-host] CEF:0|Palo Alto Networks|PAN-OS|11.1.0|URL|alert|1|rt=Apr 28 2026 13:42:20 src=10.40.20.5 spt=51310 dst=203.0.113.50 dpt=443 act=alert proto=tcp app=ssl request=https://example.com/login requestMethod=GET PanOSRuleName=allow-web-out PanOSSessionID=12345712 PanOSURLCategory=business-and-economy suser=jdoe@example.test PanOSUserAgent=Mozilla/5.0
```

## Sample 5 — SYSTEM event, HA failover (Stream = System)
```
<14>Apr 28 13:43:02 [pan-fw-host] CEF:0|Palo Alto Networks|PAN-OS|11.1.0|SYSTEM|ha|3|rt=Apr 28 2026 13:43:02 act=ha-state-change PanOSSeverity=high msg=HA peer state changed from active to passive
```

## Sample 6 — CONFIG change (Stream = Configuration)
```
<14>Apr 28 13:50:01 [pan-fw-host] CEF:0|Palo Alto Networks|PAN-OS|11.1.0|CONFIG|edit|1|rt=Apr 28 2026 13:50:01 act=edit PanOSAdminUser=admin1 PanOSConfigChange=security/rules/entry[@name='allow-web-out'] msg=committed pending changes
```

## Sample 7 — HIPMATCH (Stream = HostInformationProfile)
```
<14>Apr 28 13:51:14 [pan-fw-host] CEF:0|Palo Alto Networks|PAN-OS|11.1.0|HIPMATCH|hip|3|rt=Apr 28 2026 13:51:14 src=10.50.100.22 suser=jdoe@example.test PanOSHIPName=corp-windows-compliant PanOSSeverity=informational
```

## Notes on the wire format

- The `<14>` prefix is the syslog priority (facility 1 user, severity 6 informational). UDP/514 transport.
- `[pan-fw-host]` is the firewall hostname placeholder — `parse_syslog()` lifts this to `$Hostname` (later renamed to `DeviceName` in the Exec block).
- `CEF:0|` indicates CEF version 0.
- The `Severity` (header field 7) is numeric 1-10. Field-level severity
  for threats lives separately in `PanOSSeverity` (text: `critical`/`high`/`medium`/`low`).
- `rt=Apr 28 2026 13:42:11` is the receive time as a string — NXLog
  parses this into `$EventTime` and that becomes `TimeGenerated`.
- Standard CEF extensions like `src`, `dst`, `spt`, `dpt`, `act`, `proto`, `app`, `request`, `requestMethod`, `suser` are auto-mapped to first-class columns. Don't extract these manually.
- All `PanOS*` extensions are vendor-specific — they need anchored regex
  extraction in the parser (see Section 07 of the integration guide and `field-mapping.md`).
