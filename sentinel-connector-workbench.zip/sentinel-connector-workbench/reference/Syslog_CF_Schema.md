# Sentinel `_CF` Column Schema — Org-Standard Enrichment

Every NXLog-collected integration in the workbench enriches its events with **eight `_CF` columns** that extend the native Sentinel table schema (`Syslog`, `CommonSecurityLog`, `SecurityEvent`, etc.). These columns are populated by NXLog's `om_http` `<Exec>` block, declared in the DCR's `streamDeclarations`, and survive the `transformKql` rename to land on every row in the target table.

## Why `_CF`?

The `_CF` suffix is a deliberate org convention — *Custom Field* — that distinguishes our enrichment from Microsoft's reserved column names. Three reasons:

1. **No collision with Microsoft.** Microsoft occasionally adds new columns to built-in tables (`Syslog`, `CommonSecurityLog`). Naming our columns with a `_CF` suffix guarantees zero risk of a future Microsoft column shadowing ours.
2. **Vendor filtering on relayed data.** When a syslog forwarder relays events between zones, the relay's IP/hostname can end up in native `Computer` / `HostName` / `HostIP` columns. Filtering on those would miss the actual source. `DeviceVendor_CF` and `DeviceProduct_CF` are set by NXLog from literal strings — they are immune to relay topology.
3. **Multi-vendor in one table.** `Syslog` is shared across every syslog source we ingest (Ivanti, Cisco, F5, Juniper, Palo Alto-when-syslog, etc.). Without `_CF` columns, you can't easily query "events from Ivanti devices" — you'd need to know each vendor's `ProcessName` value or compose fragile message-content matches. With `_CF`, every parser starts with `where DeviceVendor_CF == "<Vendor>"` and the rest follows cleanly.

## The eight columns

Set inside the NXLog `om_http` `<Exec>` block, declared in DCR `streamDeclarations`.

| Column | Type | Source in NXLog | Purpose |
|---|---|---|---|
| `DeviceVendor_CF` | string | Literal — `"Ivanti"`, `"Palo Alto Networks"`, etc. | Primary vendor filter — every parser uses this in its first `where` clause |
| `DeviceProduct_CF` | string | Literal — `"Connect Secure"`, `"PAN-OS"`, etc. | Secondary filter; distinguishes products from the same vendor |
| `DatasourceName_CF` | string | Literal — `"Ivanti_ConnectSecure"`, `"PaloAltoNetworks_PANOS"` | Used as `SourceSystem` value via the DCR's `transformKql`; analyst-facing label |
| `DeviceAddress_CF` | string | `$MessageSourceAddress` | The IP NXLog received the event from. May differ from `HostIP` when relayed — that's the whole point |
| `RawLog_CF` | string | `$raw_event` | The exact wire-format frame as NXLog received it. Reserved for forensic / debugging queries — do NOT routinely query this column (it's large) |
| `NXLogInputModuleName_CF` | string | `$SourceModuleName` | Which input block (`im_..._udp`, `im_..._tcp`, `im_..._tls`) received the event. Useful for triage when one transport stops working |
| `NXLogRouteName_CF` | string | Literal — `"route_<vendor>_azure"` | Which route this event flowed through. Distinguishes events when one collector handles multiple routes |
| `NXLogServerName_CF` | string | `hostname()` | Which collector host emitted the event to Azure. Critical for multi-collector deployments — pinpoints the failing collector when ingest gaps appear |

## How they're populated — the canonical NXLog pattern

Every `om_http` `<Exec>` block in every integration has the same `_CF` enrichment section:

```
<Exec>
    parse_syslog();   ## or parse_cef() for CEF integrations

    ## ... native Sentinel column mapping (Computer, HostName, etc.) ...

    ## ─── _CF enrichment (vendor filter keys) ─────────────────
    $DeviceVendor_CF          = "<Vendor>";          ## e.g. "Ivanti"
    $DeviceProduct_CF         = "<Product>";         ## e.g. "Connect Secure"
    $DatasourceName_CF        = "<Vendor>_<Product>"; ## e.g. "Ivanti_ConnectSecure"
    $DeviceAddress_CF         = $MessageSourceAddress;
    $RawLog_CF                = $raw_event;
    $NXLogInputModuleName_CF  = $SourceModuleName;
    $NXLogRouteName_CF        = "route_<vendor>_azure";
    $NXLogServerName_CF       = hostname();

    ## ... drops, token injection, to_json() ...
</Exec>
```

The literals (`<Vendor>`, `<Product>`, etc.) vary per integration; the structure does not.

## How they're declared in the DCR

Every DCR `streamDeclarations` must include all eight `_CF` columns alongside the native columns. From `templates/dcr/syslog-dcr.json`:

```json
"streamDeclarations": {
  "Custom-<Vendor>-<Product>": {
    "columns": [
      // 9 native Syslog columns
      { "name": "TimeGenerated",       "type": "datetime" },
      { "name": "HostName",            "type": "string"   },
      ...
      // 8 _CF enrichment columns
      { "name": "DeviceVendor_CF",         "type": "string" },
      { "name": "DeviceProduct_CF",        "type": "string" },
      { "name": "DatasourceName_CF",       "type": "string" },
      { "name": "DeviceAddress_CF",        "type": "string" },
      { "name": "RawLog_CF",               "type": "string" },
      { "name": "NXLogInputModuleName_CF", "type": "string" },
      { "name": "NXLogRouteName_CF",       "type": "string" },
      { "name": "NXLogServerName_CF",      "type": "string" }
    ]
  }
}
```

If you add a column to NXLog's `<Exec>` without adding it to the DCR's `streamDeclarations`, the DCR rejects the payload with `HTTP 400`.

## How parsers use them

Every saved parser function starts the same way:

```kql
.create-or-alter function <Vendor><Product>Audit(starttime:datetime, endtime:datetime) {
    Syslog
    | where TimeGenerated between (starttime .. endtime)
    | where DeviceVendor_CF  == "<Vendor>"
    | where DeviceProduct_CF == "<Product>"
    // ... extractions ...
}
```

**Never filter on native `Computer` / `HostName` / `HostIP`** when the source is relayed. The `_CF` filter is the one true filter.

The final `project` clause of every parser keeps the `_CF` columns on every row so analysts can pivot during triage:

```kql
| project
    TimeGenerated, Computer, SourceSystem,
    /* analyst fields */ ...,
    // _CF trace fields kept on every row for triage
    DeviceVendor_CF, DeviceProduct_CF, DatasourceName_CF,
    DeviceAddress_CF, NXLogInputModuleName_CF,
    NXLogRouteName_CF, NXLogServerName_CF, RawLog_CF
```

## Naming conventions for literal values

Three style decisions for the literals NXLog hardcodes — fixed across the workbench:

| Field | Convention | Examples |
|---|---|---|
| `DeviceVendor_CF` | Marketing display name with spaces | `"Ivanti"`, `"Palo Alto Networks"`, `"Check Point"`, `"F5 Networks"` |
| `DeviceProduct_CF` | Marketing product name with spaces | `"Connect Secure"`, `"PAN-OS"`, `"FortiGate"`, `"BIG-IP"` |
| `DatasourceName_CF` | Vendor + Product joined with underscore, no spaces | `"Ivanti_ConnectSecure"`, `"PaloAltoNetworks_PANOS"`, `"CheckPoint_NFW"`, `"F5_BIGIP"` |
| `NXLogRouteName_CF` | `route_<vendor>-<product-lower>_azure` | `"route_ivanti-connectsecure_azure"`, `"route_paloaltonetworks-panos_azure"` |

Stream name in the DCR (`Custom-<Vendor>-<Product>`) uses **PascalCase**; `DatasourceName_CF` uses **PascalCase joined with underscore**; `NXLogRouteName_CF` uses **lowercase joined with hyphens**. Three conventions for three different consumers — Azure resource naming rules, KQL `SourceSystem` field convention, NXLog config readability.

## Common queries using `_CF` columns

**Volume per vendor per collector:**
```kql
Syslog
| where TimeGenerated > ago(24h)
| summarize count() by DeviceVendor_CF, DeviceProduct_CF, NXLogServerName_CF
| order by count_ desc
```

**Has a collector silently stopped sending?**
```kql
Syslog
| where TimeGenerated > ago(2h)
| summarize LastEvent = max(TimeGenerated) by NXLogServerName_CF, DeviceVendor_CF
| extend MinutesSinceLastEvent = datetime_diff('minute', now(), LastEvent)
| where MinutesSinceLastEvent > 10
```

**Which input module is each event coming from?**
```kql
Syslog
| where TimeGenerated > ago(1h)
| where DeviceVendor_CF == "Ivanti"
| summarize count() by NXLogInputModuleName_CF
```

**Forensic dump of raw events for one source IP:**
```kql
Syslog
| where TimeGenerated > ago(1h)
| where DeviceAddress_CF == "[appliance-ip]"
| project TimeGenerated, RawLog_CF
```

## Summary

These eight `_CF` columns are the workbench's contract with Sentinel. Every NXLog config sets them. Every DCR declares them. Every parser function filters on them and projects them. They are the load-bearing pieces that make a multi-vendor, multi-collector, multi-region SIEM ingest pipeline traceable end-to-end.
