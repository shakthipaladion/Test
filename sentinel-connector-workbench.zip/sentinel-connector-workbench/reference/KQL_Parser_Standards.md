# KQL Parser Standards — Saved Function Style

Every NXLog-collected integration produces a saved KQL function in `outputs/<vendor>/parser.kql`. This document defines the function signature, structural conventions, validation gates, and anti-patterns — all matched to the workbench's house style as exemplified by `IvantiConnectSecureAudit()`.

## Function naming

`<Vendor><Product>Audit` — concatenated PascalCase, no separator, suffixed `Audit`.

Examples:
- `IvantiConnectSecureAudit`
- `PaloAltoNetworksPANOSAudit`
- `FortinetFortiGateAudit`
- `CheckPointNFWAudit`
- `CiscoASAAudit`

The `Audit` suffix is the workbench convention; it signals "this is a saved Sentinel function" without colliding with any Microsoft naming. (Earlier projects used `_CL` suffix on parser names; that's been retired here because it implied a custom log table when in fact the parser sits over the built-in `Syslog` / `CommonSecurityLog` / `SecurityEvent` tables.)

## Function signature — `(starttime, endtime)` parameters

Every parser takes two optional `datetime` parameters. Default `null`; resolved at runtime to `ago(1h)` / `now()`:

```kql
.create-or-alter function <Vendor><Product>Audit(starttime:datetime = datetime(null),
                                                 endtime:datetime   = datetime(null)) {
let _start = iff(isnull(starttime), ago(1h), starttime);
let _end   = iff(isnull(endtime),   now(),    endtime);
//
// ... body ...
}
```

Why parameters and not hard-coded `ago()`:

1. **Reusability.** A 24-hour view, a 5-minute view, an arbitrary historical window — same function, different arguments.
2. **Composability.** Other queries can wrap the parser with their own time logic without `union` / `materialize` gymnastics.
3. **Validation runs.** The Sentinel Triage MCP can call `<Parser>(ago(30m), now())` for live validation without modifying the function.

Hardcoded time ranges in the function body are an anti-pattern — see the bottom section.

## Body structure — 6 phases

```kql
.create-or-alter function <Vendor><Product>Audit(starttime:datetime = datetime(null),
                                                 endtime:datetime   = datetime(null)) {
let _start = iff(isnull(starttime), ago(1h), starttime);
let _end   = iff(isnull(endtime),   now(),    endtime);

// ── 1. _CF FILTERING — never native columns ──────────────────────
<TargetTable>
| where TimeGenerated between (_start .. _end)
| where DeviceVendor_CF  == "<Vendor>"
| where DeviceProduct_CF == "<Product>"
| where SyslogMessage has "<wire-tag>"   // optional: extra filter on app name
| extend Msg = SyslogMessage

// ── 2. FRAME-LEVEL EXTRACTION — common to all events ──────────────
| extend ApplianceHost = extract(@"<frame-pattern>", 1, Msg)
| extend NodeID        = extract(@"<frame-pattern>", 1, Msg)
...

// ── 3. STREAM ROUTING — derive logical stream from event-text shape ──
| extend Stream = case(
    EventText has_any (...), "UserAccess",
    EventText has_any (...), "WebServer",
    EventText has_any (...), "AdminAccess",
    "Events"
)

// ── 4. PER-STREAM EXTRACTION ─────────────────────────────────────
| extend VPNUser              = extract(@"<pattern>", 1, EventText)
| extend AuthenticationResult = extract(@"<pattern>", 1, EventText)
...

// ── 5. ASIM EventCategory DERIVATION ─────────────────────────────
| extend EventCategory = case(
    Stream == "UserAccess" and AuthenticationResult == "Login succeeded",     "Authentication",
    Stream == "UserAccess" and AuthenticationResult in (...),                  "AuthenticationFailed",
    Stream == "WebServer"  and isnotempty(RequestUrl),                         "NetworkSessionDeny",
    ...
    "Unknown"
)

// ── 6. FINAL PROJECTION — analyst fields + _CF trace fields ──────
| project
    TimeGenerated, Computer, SourceSystem,
    Stream, EventCategory,
    /* analyst-facing extracted fields */ ...,
    // _CF trace fields kept on every row for triage pivots
    DeviceVendor_CF, DeviceProduct_CF, DatasourceName_CF,
    DeviceAddress_CF, NXLogInputModuleName_CF,
    NXLogRouteName_CF, NXLogServerName_CF, RawLog_CF,
    RawMessage = Msg
}
```

## The non-negotiable rules

### Rule 1 — Filter by `_CF`, never native

```kql
// CORRECT — works regardless of relay topology
| where DeviceVendor_CF  == "Ivanti"
| where DeviceProduct_CF == "Connect Secure"

// WRONG — will miss events when forwarded through a relay
| where Computer has "ivanti-vpn"
| where ProcessName == "PulseSecure"
```

The relay-topology problem is real: an upstream syslog relay rewrites the source IP and hostname, so `Computer` / `HostName` / `HostIP` end up referring to the relay, not the appliance. `_CF` literals are set by NXLog from hardcoded strings and survive any relay scenario.

`ProcessName` is a *secondary* filter — sometimes useful for distinguishing event sub-streams within one vendor — but never the *primary* filter.

### Rule 2 — Extract from `SyslogMessage` (or `AdditionalExtensions` for CEF), nothing else

The native `Syslog` table only gives you `SyslogMessage` as the payload. The parser's job is to lift structured fields out of it. Don't try to extract from `Computer`, `Facility`, `SeverityLevel` — those are NXLog-populated and stable; no useful extraction lives there.

For CEF integrations, the equivalent is `AdditionalExtensions` (the catch-all column in `CommonSecurityLog` for CEF extensions that don't have a native column). Same rule: extract from there, not from native CEF columns.

### Rule 3 — Position-anchored regex

Every `extract()` regex must anchor on a **stable nearby token**, not just match the value pattern alone. Compare:

```kql
// FRAGILE — matches any IP-shaped text; will pick up the wrong IP if the
// message contains multiple
| extend SrcIP = extract(@"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", 1, Msg)

// ROBUST — anchored on the literal phrase; only matches the right IP
| extend SrcIP = extract(@"came from IP (\S+)", 1, Msg)
```

Stable tokens include: literal field-name prefixes (`user '`, `from IP`), structural punctuation (`[`, `]::System(`), known event phrases (`SSL negotiation failed while client at source IP`).

### Rule 4 — Type discipline

`extract()` always returns `string`. Cast to the right type immediately:

```kql
// WRONG — string comparison "10" < "9" returns true
| extend Severity = extract(@"sev=(\d+)", 1, Msg)
| where Severity > 5

// CORRECT
| extend Severity = toint(extract(@"sev=(\d+)", 1, Msg))
| where Severity > 5
```

For datetimes use `todatetime`; for booleans `tobool`; for IP comparisons `tostring` (already string) and `parse_ipv4`.

`toint()` of an unparseable string silently returns `null`. Validate with `isnotnull(SeverityInt)` if a downstream rule depends on it.

### Rule 5 — Use `has` and `has_any`, not `contains`

```kql
// SLOW — full string scan
| where Msg contains "Login succeeded"

// FAST — uses Sentinel's term index
| where Msg has "Login succeeded"
| extend AuthOutcome = case(
    Msg has_any ("Login succeeded", "Authentication succeeded"), "Success",
    Msg has_any ("Login failed",    "Authentication failed"),    "Failure",
    "Unknown")
```

`has` matches whole tokens against the indexed term store; `contains` does substring scan over the raw column. On large `Syslog` tables the difference is order-of-magnitude.

### Rule 6 — `case()` for conditional logic, not nested `iif`

```kql
// HARD TO READ
| extend EventCategory = iif(Stream == "UserAccess",
                          iif(AuthResult == "success", "Authentication", "AuthenticationFailed"),
                          iif(Stream == "WebServer", "NetworkSessionDeny", "Unknown"))

// CLEAR
| extend EventCategory = case(
    Stream == "UserAccess" and AuthResult == "success", "Authentication",
    Stream == "UserAccess" and AuthResult == "failure", "AuthenticationFailed",
    Stream == "WebServer",                              "NetworkSessionDeny",
    "Unknown")
```

`case()` reads top-to-bottom, returns the first match, defaults to the final argument if nothing matches.

### Rule 7 — Final `project` keeps `_CF` trace fields

The last clause is always a `project` (not `project-rename`, not `project-keep`) listing analyst-facing fields plus the eight `_CF` columns. Reasons:

- **Predictable schema for downstream queries.** Analysts know what columns will be there.
- **`_CF` columns enable triage pivots without re-querying the underlying table.** "Which collector did this event come through?" is answered by `NXLogServerName_CF` on the row, not by joining back to `Syslog`.
- **`RawLog_CF` is a forensic escape hatch.** When a parser missed something, you can see the original wire format on the row.

The order should be: time/host/category fields first, analyst-facing extracted fields next, `_CF` trace fields last.

## ASIM `EventCategory` mapping

The workbench's parsers apply `EventCategory` as the second-to-last `extend`. Use Microsoft's ASIM categories, not custom ones, so Sentinel's built-in cross-product analytics light up:

| Source event shape | `EventCategory` |
|---|---|
| Successful login | `Authentication` |
| Failed login | `AuthenticationFailed` |
| Account locked | `AccountLocked` |
| Logoff / session end | `Logoff` |
| Pre-auth web access denied | `NetworkSessionDeny` |
| TLS handshake failure | `SecurityStateChanged` |
| Realm/source-IP restriction match | `NetworkAccessDenied` |
| Admin configuration change | `ConfigurationChanged` |
| Process spawn (Windows) | `ProcessCreated` |
| File create/modify/delete | `FileChanged` |
| Network session allowed | `NetworkSession` |
| (Unmappable) | `Unknown` |

Default to `"Unknown"` rather than leaving the field empty — analysts can then filter `where EventCategory != "Unknown"` to find unparsed events.

## Validation — hard gate before file write

Before any `parser.kql` lands on disk in `outputs/<vendor>/`, the workbench requires it to be validated against the live workspace via Sentinel Triage MCP:

1. **Substitute:** Copilot inlines the function body (without the `.create-or-alter function` header) into a one-off query: `<body> | take 10`.
2. **Run:** Sentinel Triage MCP `RunAdvancedHuntingQuery` against the UAE prod workspace.
3. **Inspect:** Did the query run without errors? Did it return rows? (If not, is the source already onboarded? Greenfield is OK; existing-but-empty is not.) Do the extracted custom fields populate non-null?
4. **Annotate:** On success, insert `// VALIDATED <YYYY-MM-DD>` into the file header. Save to disk.
5. **On failure:** Do NOT save. Report the error to the user. Common failures:
   - Unknown column referenced — fix the parser's `extend` step
   - Stream key mismatch — re-check the DCR streamDeclarations
   - Empty rows for an existing-onboarded vendor — the regex is wrong; check the sample logs in `docs/samples/`
6. **If validation cannot run:** (no MCP, vendor not yet onboarded, etc.) save the file with `// VALIDATION SKIPPED — REASON: <reason>` instead of `// VALIDATED <date>`. Tell the user explicitly.

This is a **hard gate** — the workbench will not silently produce an unvalidated parser.

## Anti-patterns

### Hardcoded time ranges in the body

```kql
// WRONG
.create-or-alter function MyVendorAudit() {
    Syslog
    | where TimeGenerated > ago(24h)
    ...
}
```

The caller chooses the time range. Function shouldn't.

### `let` for the vendor name

```kql
// WRONG — adds indirection for no reason
.create-or-alter function MyVendorAudit(...) {
    let v = "Ivanti";
    let p = "Connect Secure";
    Syslog
    | where DeviceVendor_CF == v
    | where DeviceProduct_CF == p
    ...
}
```

Inline the literals — clearer to read, no scope confusion.

### Combining filtering and detection logic

```kql
// WRONG — the parser is for extraction, not threat decisions
.create-or-alter function MyVendorAudit(...) {
    Syslog
    | where DeviceVendor_CF == "MyVendor"
    | where SeverityLevel == "alert"             // detection logic — doesn't belong
    | where SyslogMessage has "blocked"          // detection logic — doesn't belong
    ...
}
```

The parser's job is exposing structured data. Filtering by severity, action, or threat indicator belongs in the analytic rule that calls the parser.

### Hardcoding column types you don't need

```kql
// WRONG — every regex extracted as `string` then explicit casts everywhere
| extend SessionID = tostring(extract(@"sid=(\d+)", 1, Msg))   // already string!
```

`extract()` returns `string`; only cast when you actually need a different type.

### Catch-all extracts on `RawLog_CF`

```kql
// WRONG — RawLog_CF is forensic, not for routine extraction
| extend SomeField = extract(@"...", 1, RawLog_CF)
```

Extract from `SyslogMessage` (or `AdditionalExtensions` for CEF). `RawLog_CF` is large and only meant for ad-hoc forensics — querying it routinely is expensive.

## Updating an existing parser

When the vendor changes their wire format (firmware update, new event types):

1. Capture new sample logs.
2. Diff the new payloads against the existing extractions — what's broken?
3. Add new `extend` steps for new fields. **Don't remove old ones immediately** — other queries may still reference them. Mark them with a `// DEPRECATED <date>` comment for one quarter, then remove.
4. Bump the parser docstring with the new version range.
5. Re-validate against the live workspace via Sentinel Triage MCP.
6. Re-annotate `// VALIDATED <new-date>`.
7. If the changes are substantial, consider promoting the updated parser to `library/syslog/<vendor>-parser.kql` so future similar integrations can branch from it.
