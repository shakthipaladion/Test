# Document Design Standards — Sentinel Integration Reference Documents

This document codifies the visual design system used by every integration document the workbench produces. The source-of-truth template is `templates/html/starter.html`. This file documents the *why* behind each choice so the design stays consistent if the template ever needs editing.

## Typography

Three IBM Plex faces, each with a specific role:

| Face | Use for | Why |
|---|---|---|
| **IBM Plex Serif** (weights 400, 600) | `h1`, `h2` only | Editorial weight — the document is a reference, not a UI. Serif headings signal "read this carefully" without shouting. |
| **IBM Plex Sans** (weights 300, 400, 500, 600, 700) | Body text, `h3` (uppercase), tables, navigation | Reads cleanly at small sizes. Multiple weights let us encode hierarchy without shouting. |
| **IBM Plex Mono** (weights 300, 400, 500, 600) | Code blocks, `code`, eyebrows, version chips, sec-tag chips | Distinguishes machine-readable from prose at a glance. |

Sizes are deliberately small — body 14px, code 11.5px, tables 13px. SOC engineers spend long sessions reading these documents; the small body size lets more content fit per scroll without the cramped feel of 12px text.

## Colour palette

The palette is named after physical materials — earth tones rather than tech-startup blues. Three colour families plus a warm neutral background:

```css
--bg:      #f2efe9;   /* warm paper-like background */
--bg2:     #e8e4dc;   /* slightly darker — table headers */
--surface: #f9f7f4;   /* alternating table rows */
--white:   #fff;      /* odd table rows, content surface */
--border:  #d0cac0;   /* warm grey */

--navy:    #1c3352;   /* primary structural — header bg, h2, sec-tag chip */
--orange:  #b85c1e;   /* accent — h3, code keyword, focus states, links */
--teal:    #1a6b6b;   /* informational callout */
--green:   #2a6640;   /* success callout */
--red:     #8b2a2a;   /* danger callout, hardcoded literals badge */

--text:        #2c2825;   /* primary text */
--text-mid:    #5a534a;   /* secondary text */
--text-dim:    #8a837a;   /* tertiary — captions, version chips */

--code-bg:     #1a1a18;   /* code-block dark background */
--code-surf:   #242420;   /* code-block top bar */
--code-bdr:    #333330;
```

The dark code blocks (almost-black `#1a1a18`) on the warm-light page background give a strong visual contrast that separates machine-readable from prose at a glance.

## Layout

The document is centred with `max-width: 1180px`. At common laptop resolutions (1440-1920px wide) this leaves comfortable side gutters. Sections have generous vertical padding (`margin-bottom: 68px`) — the document is meant to be scrolled section-by-section, not skimmed.

The sticky `<nav>` (top of viewport, `position: sticky`) lets the engineer jump between sections without scrolling back to the top — important when reading a 200-page document.

## Section structure

Eight numbered sections. Each one starts with:

```html
<div class="section" id="s0X">
  <div class="sec-hdr">
    <span class="sec-tag">0X</span>
    <h2>Section Title</h2>
  </div>
  <!-- body -->
</div>
```

The `.sec-tag` is an uppercase monospace chip with the section number — visually anchors the section without being a giant numeric heading. The `<h2>` is serif, navy.

The eight sections are fixed (Section 09 / Threat Scenarios deliberately removed):

| # | Title | Content |
|---|---|---|
| 01 | Device Config | What to do on the source device to emit logs |
| 02 | NXLog | Full nxlog.conf with active-passive toggle, operational checks table |
| 03 | DCR ARM | Deployment prerequisites table, ARM template, deployment commands, HTTP error troubleshooting |
| 04 | Field Mapping | Native + `_CF` columns, vendor-specific fields, Securonix migration crosswalk |
| 05 | Event Catalogue | What event types the vendor produces, what each means |
| 06 | Sample Logs | Sanitised wire-format examples, one per major event type |
| 07 | KQL Parser | The saved function with regex extraction and ASIM mapping |
| 08 | Validation | 5 KQL queries (VQ-01..05) confirming healthy ingestion |

## Subsections — `h3`

The third-level heading is small (11.5px) uppercase orange with a subtle bottom border. It's used for subsection separation within a section — not for outline structure. Reads more like a category label than a heading. This is intentional: heavy `h3`s would compete with `h2`s and clutter the page.

## Code blocks

Three nested elements:

```html
<div class="code-wrap">
  <div class="code-bar">
    <span class="code-label">/etc/nxlog/nxlog.conf</span>
    <span class="code-lang">nxlog</span>
  </div>
  <pre>...</pre>
</div>
```

The dark "title bar" gives every code block a label (file path, command name, etc.) on the left and a language tag on the right. The language tag enables future syntax-highlighting tools without changing the markup.

Inside `<pre>`, manual syntax-highlight spans:

| Class | Colour | Use for |
|---|---|---|
| `.cm` | `#4a4a44` (dim grey) | Comments |
| `.kw` | `#c8783c` (orange) | Keywords (`where`, `extend`, `let`, `define`) |
| `.st` | `#7aab72` (green) | String literals |
| `.vr` | `#6aa8cc` (blue) | Variables, parameters, placeholders |
| `.fn` | `#b07acc` (purple) | Function names |
| `.nm` | `#d4a050` (yellow) | Numeric literals |
| `.tp` | `#60b0c8` (teal) | Type names, table names |

Auto-syntax-highlighters can be added later but the manual spans are the canonical version. They render reliably across email, PDF export, and embedded views.

## Inline `code`

```css
code { background: var(--orange-bg); color: var(--orange); padding: 1px 5px; border-radius: 2px; }
```

Inline code uses an orange-on-pale-orange treatment — distinct from code blocks, doesn't compete with the headings. Reserved for short identifiers (column names, function names, file paths).

## Tables

Wrapped in `.tbl-wrap` for horizontal scrolling on narrow viewports. Header row is uppercase navy on warm grey; alternating body rows are white / surface; hover state is pale orange (`#fef9f4`).

Tables are used heavily — every section has at least one. Configuration tables, field mappings, command references, error code routers. Row count varies; tables don't get scrollbars (`tbl-wrap` overflow only kicks in for column-width overflow).

## Callouts — `.box`

Three variants, all left-bordered with a coloured `<span class="box-icon">` glyph:

| Class | Border | Background | Icon | Use for |
|---|---|---|---|---|
| `.box-note` | teal | pale teal | ℹ (`&#9432;`) | Informational — explanations, context |
| `.box-warn` | orange | pale orange | ⚠ (`&#9888;`) | Warnings — common mistakes, gotchas |
| `.box-ok` | green | pale green | ✓ (`&#10003;`) | Confirmations — validation status, success criteria |
| `.box-danger` | red | pale red | ✗ | (Reserved — only for genuine danger; rarely used) |

A document with too many callouts feels noisy. Aim for 1-3 per section.

## Pipeline diagram (header only)

The header has a bespoke "pipeline" visualisation — a horizontal flow of monospace chips connected by `→` arrows. It shows the data path at a glance: vendor → transport → NXLog → parser → DCR → table → function. Highlights (orange) mark the most important nodes; dims (translucent) mark intermediate steps.

Implemented purely with `<div>` and CSS — no SVG, no JavaScript, prints cleanly to PDF.

## Badges and chips

Several small reusable chip styles:

- `.tag-csl` — table-name chip (light blue), used in the version-chip area to call out the target table
- `.fld` — field-name chip in `.fields-list` (warm grey monospace), used when listing many fields without a table
- `.ver-chip` — top-right of the header (translucent white on navy), shows version range and target table

## Footer

```html
<footer>
  <span>{{VENDOR}} {{PRODUCT}} Sentinel Integration · v{{DOC_VERSION}} · Validated {{VALIDATED_DATE}}</span>
  <span>Generated by Sentinel Connector Workbench</span>
</footer>
```

Navy bar, pale-grey monospace text. Identifies the document and its provenance without shouting.

## Print-friendliness

The CSS deliberately:
- Uses `position: sticky` (which print stylesheets handle by anchoring at section break)
- Avoids hover-only content — everything visible is in the static render
- Keeps tables non-fixed-height so they reflow at print
- Uses high-contrast borders that survive black-and-white printing

PDF export from Chromium renders cleanly without modification.

## Accessibility

- Colour is never the only signal — every callout has an icon as well as a colour
- WCAG AA contrast on text-over-background pairs (the warm-on-warm palette is checked: `--text` over `--bg`, `--orange` over `--orange-bg`, `--white` over `--navy` all pass)
- Section IDs (`#s01` to `#s08`) match heading text in stable form, supporting deep links

## What this document deliberately doesn't include

A few things the design system *doesn't* have, on purpose:

- **No dark mode.** Engineers print these or live in the browser at full brightness; the warm-light palette is calibrated for both. A dark mode would need a parallel palette and double the maintenance cost.
- **No interactive elements** beyond the sticky nav. No collapsible sections, no in-page search, no live KQL execution. The document is a reference, not an app — interactivity belongs in Sentinel.
- **No vendor logos.** The header uses typography, not vendor identity. Logos would imply a partnership or endorsement we don't have, and they'd date the document.
- **No "edit toolbar" buttons.** Earlier templates had Edit/Save/Cancel chips that did nothing functional. Removed — they invited confusion about whether the doc was live-editable.
