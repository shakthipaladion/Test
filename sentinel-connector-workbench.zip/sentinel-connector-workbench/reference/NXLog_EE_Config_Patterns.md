# NXLog Enterprise Edition — Configuration Patterns

This is the workbench's authoritative reference for NXLog EE configuration. **Pattern A** (`om_http` with inline `<Exec>` enrichment) is the primary and only production pattern used by the workbench. Earlier patterns (`om_azuremonitor`, separate `pm_*` processors, in-document bearer-token scripts) are deliberately not used.

## Why Pattern A

We use `om_http` rather than NXLog EE's native `om_azuremonitor` module for one operational reason: **split network routing**. The bearer-token refresh script needs to traverse the corporate HTTP proxy to reach `login.microsoftonline.com`; the high-volume DCE ingest must bypass the proxy and exit via ExpressRoute. `om_azuremonitor` handles both the OAuth call and the data POST internally, forcing both onto the same network path. With `om_http` plus an out-of-band cron-driven refresh script, we route each call where it needs to go.

A secondary benefit: `om_http`'s `<OnError>` block can inspect the HTTP response code and react granularly (force token reload on 401, log on 429, etc.). `om_azuremonitor` is more opaque.

See `reference/Azure_Bearer_Token_Refresh.md` for the refresh script and the split-routing rationale.

## File structure

A complete `nxlog.conf` for the workbench has the following block order:

```
1.  Failover toggle           — define ACTIVE_DESTINATION
2.  Global directives         — paths, pidfile, log file, log level
3.  DCR endpoint defines      — DCE_ENDPOINT_PROD, DCR_RULE_ID_PROD, etc.
4.  Stream define             — DCR_STREAM = Custom-<Vendor>-<Product>
5.  Module path / cache dir   — Moduledir, CacheDir, SpoolDir
6.  Extensions                — xm_syslog, xm_json (always); xm_cef as needed
7.  Inputs                    — im_udp / im_tcp / im_ssl per device transport
8.  Outputs                   — om_azure_prod_uae, om_azure_dr_ch
9.  Route                     — single route, references %ACTIVE_DESTINATION%
```

Both `<Output>` blocks are present in the file at all times — the route picks one of them via the `%ACTIVE_DESTINATION%` define at the top.

## Pattern A — `om_http` with inline `<Exec>` enrichment

**No separate processor.** All parsing, mapping, `_CF` enrichment, and serialisation happen inline in the `<Output>` block's `<Exec>`. The path is `Input → Output (parses + enriches + posts)` — no `<Processor>` in between.

The `<Exec>` block has 8 phases, in order:

```
<Exec>
    parse_syslog();                      ## 1. Parse the syslog frame
    if $Message == undef { drop(); }     ## 2. Drop malformed events

    $Computer = $Hostname;               ## 3. Map parsed fields to native Syslog columns
    $HostName = $Hostname;
    $SyslogMessage = $Message;
    ...

    $DeviceVendor_CF  = "Ivanti";        ## 4. _CF enrichment (the eight org-standard columns)
    $DeviceProduct_CF = "Connect Secure";
    ...

    delete($EventReceivedTime);          ## 5. Strip NXLog-internal fields
    delete($SourceModuleName);
    ...

    if $Computer == undef { drop(); }    ## 6. Drop events missing required fields

    if get_var('aad_bearer_token') == undef    ## 7. Load token on first event
        { set_var('aad_bearer_token', file_read('%TOKEN_CACHE%')); }
    add_http_header('Authorization', 'Bearer ' + get_var('aad_bearer_token'));

    to_json();                           ## 8. Serialise the enriched record
</Exec>
```

This sequence is deliberate. Some specific points:

- **Phase 2 drops malformed events early** — keep-alive frames, partial lines, anything `parse_syslog()` couldn't make sense of.
- **Phase 3 maps NXLog field names to Sentinel column names.** `$Hostname` (NXLog) → `$Computer` (Sentinel). This rename is done in NXLog rather than in DCR `transformKql` because we want NXLog to send well-named JSON, and `transformKql` reserves its capacity for the post-ingest `Computer = HostName` step (see DCR section).
- **Phase 4 — `_CF` enrichment** is the workbench's signature. Eight columns set from literals or NXLog built-in functions. Always all eight, always in this order.
- **Phase 5 deletes NXLog-internal fields** that would otherwise serialise as JSON keys and either confuse the DCR or pollute the table with nulls.
- **Phase 7 loads the bearer token** from the cache file written by the cron refresh script. `get_var` is module-scoped — first call returns `undef`, subsequent calls return the cached value within the NXLog process. The `<Schedule>` block (below) refreshes it every 60 seconds.

## `<Schedule>` block — token cache refresh

Every `<Output>` block needs:

```
<Schedule>
    Every 60 sec
    <Exec>
        set_var('aad_bearer_token', file_read('%TOKEN_CACHE%'));
    </Exec>
</Schedule>
```

This is what keeps the NXLog process's in-memory token in sync with the cache file written by the cron-driven `refresh_azure_token.sh` (which runs every 25 minutes — see `Azure_Bearer_Token_Refresh.md`). The 60-second cadence ensures NXLog never tries to use a stale token when the cron has just refreshed it.

## `<OnError>` block — response-code router

Every `<Output>` block ends with:

```
<OnError>
    RetryLimit 5
    <Exec>
        $response_code = get_response_code();

        if $response_code == 204 { drop(); }                 ## Success — Azure accepted the batch
        else if $response_code == 401 {                       ## Token stale — force reload
            set_var('aad_bearer_token', file_read('%TOKEN_CACHE%'));
            log_warning('401 Unauthorized — token reloaded');
        }
        else if $response_code == 429 {                       ## Rate limit
            log_warning('429 Too Many Requests');
        }
        else {                                                ## Anything else (400/403/404/5xx)
            log_warning('Azure ingestion error: ' + $response_code);
        }
    </Exec>
</OnError>
```

`RetryLimit 5` covers transient failures. The `<Exec>` block reacts to specific status codes:
- **204** is success, drop the in-flight batch (it was accepted).
- **401** triggers an immediate cache-file re-read so the next retry uses a fresh token, without waiting 60 seconds for the `<Schedule>` tick.
- **429** rate-limit — log it, NXLog's retry will eventually succeed when Azure releases the limit.
- **Anything else** — log with the code; investigate via `grep om_http /var/log/nxlog/nxlog.log`.

## Active-passive failover via `%ACTIVE_DESTINATION%` toggle

The toggle pattern at the top of `nxlog.conf`:

```
define ACTIVE_DESTINATION  om_azure_prod_uae    # ACTIVE   — UAE production
# define ACTIVE_DESTINATION  om_azure_dr_ch      # STANDBY — CH disaster recovery
```

The route uses the variable rather than a literal output name:

```
<Route route_<vendor>_azure>
    Path  im_<vendor>_udp
          => %ACTIVE_DESTINATION%
</Route>
```

**Failover procedure** (UAE → CH) takes about 30 seconds:

```bash
# 1. SSH to each NXLog collector
sudo vi /etc/nxlog/nxlog.conf
# 2. Edit the toggle — comment the prod line, uncomment the DR line:
#       # define ACTIVE_DESTINATION  om_azure_prod_uae   # was active
#       define ACTIVE_DESTINATION  om_azure_dr_ch         # now active
# 3. Validate
sudo nxlog -v
# 4. Reload
sudo systemctl reload nxlog
# 5. Confirm new destination is live (within ~30 seconds you should see HTTP 204s
#    from the CH DCE in the NXLog log)
sudo tail -f /var/log/nxlog/nxlog.log | grep om_azure_dr_ch
```

**Failback** is the same procedure in reverse. Both `<Output>` blocks remain defined at all times; only the toggle changes.

**Why this is genuinely zero-RTO:**
- The CH DCR is provisioned and ready (deployed alongside the prod DCR by the same workbench DCR ARM template, just to a different RG/region).
- The same NXLog Entra app has `Monitoring Metrics Publisher` on both DCRs.
- The same bearer token works for both (one tenant, one app).
- The cache file is fresh, valid for both.
- All you change is which `<Output>` the route resolves to.

## Common configuration errors

1. **Stream name mismatch between NXLog and DCR.** `Stream` value in NXLog's URL path must exactly equal the key in DCR `streamDeclarations`. Mismatch returns HTTP 400. Always grep both files for the same string.
2. **`AddHeader Accept-Encoding: identity` missing.** Without this, NXLog may attempt gzip and Azure responds with HTTP 415. Always present in the workbench template.
3. **`HTTPSCAFile` pointing to a missing CA bundle.** Linux distros put the CA in different places — `/etc/ssl/certs/`, `/etc/pki/tls/certs/`, etc. The workbench convention is `/opt/nxlog/cert/DigiCertGlobalRootG2.crt` deployed alongside NXLog so paths are consistent across collectors.
4. **`SavePos TRUE` missing on `im_file`** (where used for log-tail integrations). Without it, NXLog re-reads the entire file on restart, double-ingesting events.
5. **Toggle line uncommented twice.** Both `define ACTIVE_DESTINATION` lines uncommented at once — last one wins, but creates confusion in audits. Always exactly one uncommented.
6. **Forgetting to reload after toggle flip.** `nxlog -v` validates syntax but doesn't apply config; `systemctl reload nxlog` is required.

## Validation procedure after every config change

```bash
# 1. Syntax validation (no startup, no network)
sudo nxlog -v

# 2. Reload (graceful — preserves in-flight batches)
sudo systemctl reload nxlog

# 3. Confirm modules loaded
sudo journalctl -u nxlog --since "1 minute ago"

# 4. Confirm bound ports
ss -tulnp | grep nxlog

# 5. Confirm successful posts
sleep 30
sudo grep "HTTP 204" /var/log/nxlog/nxlog.log | tail -5
```

If all five steps pass, the integration is healthy. If step 5 returns nothing within 60 seconds, check the operational checks table in the per-integration document (Section 02).

## Patterns we deliberately don't use

For completeness, here's what's in the broader NXLog world that the workbench rejects:

- **`om_azuremonitor`** — can't satisfy the split-routing requirement
- **NXLog Community Edition** — lacks `xm_cef`, `xm_json`, `om_http` features we depend on
- **Separate `<Processor>` blocks** (Pattern B) — adds complexity for no gain when the parser is simple inline
- **In-config bearer-token retrieval** — embedding curl in NXLog's `<Schedule>` complicates security review and makes secret rotation messy

## Variants by transport

Pattern A is universal across syslog (UDP/TCP/TLS) integrations. The only thing that changes per-integration is the `<Input>` block. Skill files document the per-archetype variants:

- `.github/skills/syslog-integration/SKILL.md` — RFC 3164/5424 syslog over UDP/TCP/TLS
- `.github/skills/cef-integration/SKILL.md` — CEF (Common Event Format) over syslog transports; also Pattern A but uses `parse_cef()` and lands in `CommonSecurityLog`
- `.github/skills/windows-eventlog-integration/SKILL.md` — Windows Event Log via `im_msvistalog`; Pattern A but the parser is `xm_json` formatting rather than syslog
- `.github/skills/json-api-integration/SKILL.md` — REST API push via `im_http`; Pattern A applies, the input is HTTP rather than syslog
