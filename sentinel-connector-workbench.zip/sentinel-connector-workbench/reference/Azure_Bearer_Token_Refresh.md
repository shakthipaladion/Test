# Azure Bearer Token Refresh — NXLog `om_http` Authentication

This is the **canonical reference** for the bearer-token refresh script that NXLog reads from a cache file on every `om_http` POST. It is deployed **once per collector**, not per integration. Every integration document points back here rather than embedding the script.

## Why this exists separately

Earlier iterations of integration documentation embedded the refresh script in each per-integration document. That created documentation drift — a script change had to be replicated across 30+ documents, and inevitably some lagged. By keeping the script in one canonical location:

- One source of truth for the bash script, the cron entry, file permissions
- Per-integration documents stay focused on the data source, not the auth plumbing
- Updates to the auth pattern need only be applied here

## Architecture — split routing

The refresh script and NXLog use **two different network paths** to Azure, and this is intentional:

```
                    ┌──────────────────────────────┐
                    │   NXLog collector (Linux)    │
                    └──────────────────────────────┘
                            │           │
                            │           │
        ┌───────────────────┘           └────────────────────┐
        │                                                    │
        │ refresh_azure_token.sh                             │ NXLog om_http
        │ POST .../oauth2/v2.0/token                         │ POST .../streams/<name>
        │                                                    │
        ▼                                                    ▼
   ┌────────────────────────┐                     ┌──────────────────────────┐
   │ Corporate HTTP proxy   │                     │ Azure ExpressRoute       │
   │ (allowed for OAuth     │                     │ (direct, bypasses proxy, │
   │ to login.microsoft     │                     │ no chance of proxy-side  │
   │ online.com)            │                     │ throughput limits)       │
   └────────────────────────┘                     └──────────────────────────┘
        │                                                    │
        ▼                                                    ▼
   login.microsoftonline.com                       <dce>.<region>.ingest.monitor.azure.com
```

**Why split:** OAuth calls are low-volume (one per 25 minutes per collector) but go to a Microsoft endpoint that's typically allowlisted on the corporate proxy. DCE ingest is high-volume (potentially thousands of POSTs per minute per collector) and shouldn't traverse the proxy where it would chew up proxy bandwidth and throughput. Routing OAuth through the proxy and ingest direct via ExpressRoute keeps both paths happy.

This is configured in two places: the `--proxy` flag on the curl call inside `refresh_azure_token.sh`, and the absence of any `HTTPSProxy` directive in NXLog's `om_http` block.

## Tenant model

This deployment uses **one Microsoft Entra tenant** with subscriptions in two regions (UAE and Switzerland). One app registration. One `client_id`/`client_secret` pair. **One bearer token works for both regional DCRs** — the same SP is granted `Monitoring Metrics Publisher` on both DCR resources.

**Implications:**
- One `azure_sp.env` file
- One `refresh_azure_token.sh` script
- One cron entry
- One `azure_bearer_token.cache` file
- Both `<Output>` blocks in NXLog read the same cache file

If your deployment ever moves to a multi-tenant model (separate Entra tenants per region for regulatory isolation), this doc has to fork into two parallel script invocations and two cache files.

## File layout on the collector

```
/opt/nxlog/
├── bin/
│   └── refresh_azure_token.sh       # The refresh script (this doc)
├── cert/
│   ├── azure_sp.env                  # Sourced by the script — credentials
│   ├── azure_bearer_token.cache      # Token cache — read by NXLog every 60 sec
│   └── DigiCertGlobalRootG2.crt      # CA used by NXLog to verify Azure HTTPS endpoints
└── etc/
    └── nxlog.conf                    # Has <Output> blocks reading the cache file

/etc/cron.d/
└── azure-token-refresh               # Cron entry that runs the script every 25 min

/var/log/nxlog/
├── nxlog.log                         # NXLog's runtime log
└── token_refresh.log                 # Refresh-script log
```

## Credentials file — `/opt/nxlog/cert/azure_sp.env`

```bash
# Azure AD service principal credentials for NXLog DCE ingest auth.
# This file is sourced by /opt/nxlog/bin/refresh_azure_token.sh.

TENANT_ID=[entra-tenant-id]
CLIENT_ID=[app-registration-client-id]
CLIENT_SECRET=[app-registration-client-secret]
```

**Required permissions:**
```bash
sudo chown root:nxlog /opt/nxlog/cert/azure_sp.env
sudo chmod 640 /opt/nxlog/cert/azure_sp.env
```

`640` lets root and the `nxlog` group read; nobody else. The refresh script runs as the `nxlog` user via cron and needs read access; nothing else does.

## Refresh script — `/opt/nxlog/bin/refresh_azure_token.sh`

```bash
#!/bin/bash
# ──────────────────────────────────────────────────────────────────────
# Refresh Azure AD bearer token for NXLog om_http ingestion to DCE.
# Runs every 25 minutes via cron. Token lifetime is ~60 minutes; the
# 25-minute interval gives 35 minutes of headroom before expiry.
# ──────────────────────────────────────────────────────────────────────

set -uo pipefail

# ── Source credentials from the env file ──────────────────────────────
source /opt/nxlog/cert/azure_sp.env
# Expected: TENANT_ID, CLIENT_ID, CLIENT_SECRET

TOKEN_CACHE="/opt/nxlog/cert/azure_bearer_token.cache"
TOKEN_CACHE_TMP="${TOKEN_CACHE}.tmp"
HTTP_PROXY_URL="http://[corp-proxy-host]:[corp-proxy-port]"
LOG="/var/log/nxlog/token_refresh.log"

# ── OAuth call routed via corporate proxy ─────────────────────────────
# scope=https://monitor.azure.com/.default is the audience that DCEs
# accept. grant_type=client_credentials is the standard SP flow.
RESPONSE=$(curl --silent --fail --max-time 30 \
    --proxy "${HTTP_PROXY_URL}" \
    -X POST "https://login.microsoftonline.com/${TENANT_ID}/oauth2/v2.0/token" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&scope=https%3A%2F%2Fmonitor.azure.com%2F.default&grant_type=client_credentials")

if [ $? -ne 0 ] || [ -z "$RESPONSE" ]; then
    echo "$(date -Is) ERROR: token refresh failed (curl)" >> "$LOG"
    exit 1
fi

TOKEN=$(echo "$RESPONSE" | jq -r '.access_token')

if [ -z "$TOKEN" ] || [ "$TOKEN" == "null" ]; then
    echo "$(date -Is) ERROR: empty/null token in response" >> "$LOG"
    exit 1
fi

# ── Atomic write — NXLog reads this cache file every 60 sec; we must
#    not let it ever read a partial / truncated token ────────────────
echo -n "$TOKEN" > "$TOKEN_CACHE_TMP"
chmod 600 "$TOKEN_CACHE_TMP"
chown nxlog:nxlog "$TOKEN_CACHE_TMP"
mv -f "$TOKEN_CACHE_TMP" "$TOKEN_CACHE"

echo "$(date -Is) OK: token refreshed (length=${#TOKEN})" >> "$LOG"
```

**Required permissions:**
```bash
sudo chown root:nxlog /opt/nxlog/bin/refresh_azure_token.sh
sudo chmod 750 /opt/nxlog/bin/refresh_azure_token.sh
```

## Cron entry — `/etc/cron.d/azure-token-refresh`

```cron
# Refresh Azure bearer token every 25 minutes.
# Token TTL is ~60 min; the 25-min interval gives 35 min headroom.
*/25 * * * * nxlog  /opt/nxlog/bin/refresh_azure_token.sh
```

The script runs as the `nxlog` user (the same user NXLog itself runs as), so it can write the cache file with the right ownership the first time. The `crond` service must be running.

## First-time bootstrap

After deploying the script and credentials but before starting NXLog, run the script manually once to populate the cache:

```bash
sudo -u nxlog /opt/nxlog/bin/refresh_azure_token.sh
ls -la /opt/nxlog/cert/azure_bearer_token.cache
# Expect: -rw------- 1 nxlog nxlog ~1500 bytes
cat /var/log/nxlog/token_refresh.log
# Expect: 2026-MM-DDT...:OK: token refreshed (length=1500-or-so)
```

If this first run fails, NXLog will start but every event POST will return HTTP 401 until the cache is populated — fix the bootstrap before starting NXLog to avoid log noise.

## Operational health checks

Run these any time NXLog starts returning HTTP 401 in its log:

```bash
# 1. Token cache freshness — should be within last 25 minutes
stat /opt/nxlog/cert/azure_bearer_token.cache | grep Modify

# 2. Recent refresh log lines — should be a steady cadence of OK messages
tail -20 /var/log/nxlog/token_refresh.log

# 3. cron entry exists and crond is running
cat /etc/cron.d/azure-token-refresh
systemctl status cron      # Debian/Ubuntu
systemctl status crond     # RHEL/CentOS

# 4. Manual run — does it succeed?
sudo -u nxlog /opt/nxlog/bin/refresh_azure_token.sh
echo "Exit code: $?"

# 5. Is the proxy reachable?
curl --silent --fail --max-time 10 --proxy http://[corp-proxy-host]:[corp-proxy-port] \
     https://login.microsoftonline.com/  >/dev/null && echo "Proxy reachable" || echo "Proxy DOWN"

# 6. Does the SP still have role assignment on both DCRs?
az role assignment list --assignee [client-id] --query "[].{role:roleDefinitionName, scope:scope}" -o table
```

## Troubleshooting

| Symptom | Likely cause | Action |
|---|---|---|
| `token_refresh.log` shows ERROR repeatedly | Proxy unreachable, secret rotated, or tenant ID wrong | Run script manually, check `azure_sp.env`, check proxy |
| Cache file timestamp >25 min old | cron stopped, or script silently failing | Restart cron, run manually, check log |
| NXLog log has bursts of `HTTP 401` | Cache file is empty or stale at moment of NXLog read | Confirm cache file freshness; if fresh, force NXLog to reload (`systemctl reload nxlog`) — sometimes NXLog clings to a previously-loaded token |
| All NXLog `om_http` calls return `HTTP 403` | Role assignment missing or scoped wrong | Re-assign `Monitoring Metrics Publisher` on the **DCR resource** (not the RG, not the workspace) |
| Cache file is fresh but token rejected | Client secret expired; or the token's audience is wrong | Rotate the secret in Entra, update `azure_sp.env`, force-run the script |
| OAuth call succeeds but `.access_token` is empty | Tenant has Conditional Access blocking SP, or wrong scope | Check Entra sign-in logs for the SP — look for CA failures |

## Failover note

The bearer token works for **both** regional DCRs (UAE and CH) because the same SP has `Monitoring Metrics Publisher` on both. There is no DR-specific token to manage. When the `%ACTIVE_DESTINATION%` toggle in `nxlog.conf` flips from prod to DR, the existing cache file is reused by the new active output — failover is genuinely instantaneous, with no token-refresh delay.

## Related references

- `reference/NXLog_EE_Config_Patterns.md` — full Pattern A explanation, the `<Exec>` block structure, the `<OnError>` response-code router
- `reference/Syslog_CF_Schema.md` — what each `_CF` column means and where it's populated
- The per-integration `nxlog.conf` files in `outputs/<vendor>/` — they reference `%TOKEN_CACHE%` but never embed this script
