# CEF → CommonSecurityLog Mapping Reference

For vendors that emit Common Event Format (CEF), the workbench routes events through `parse_cef()` in NXLog and lands them in Sentinel's built-in `CommonSecurityLog` table — augmented with the standard 8 `_CF` columns just like syslog integrations. This document maps the CEF wire format to `CommonSecurityLog` columns and documents the workbench's CEF-specific decisions.

This is the *secondary* schema reference. The primary is `Syslog_CF_Schema.md` — that's the default path for new integrations. CEF is used only when the vendor confirms RFC-compliant CEF support.

## When to use the CEF path vs the Syslog path

Use CEF when:
- The vendor explicitly emits `CEF:0|<Vendor>|<Product>|<Version>|<EventClassID>|<Name>|<Severity>|<Extensions>` — verifiable in a sample log
- The vendor's CEF mapping is documented and stable (vendors change CEF formats less often than they change proprietary syslog)

Use plain Syslog when:
- The vendor sends RFC 3164/5424 with a structured but non-CEF payload (typical for Linux services, network OS, application logs)
- The vendor labels their output "CEF" but the wire format isn't actually compliant (common with older Cisco devices, some Trend Micro products) — *check the sample before committing*

If unsure, use Syslog. CEF should be a positive identification, not a default assumption.

## CEF wire format

```
CEF:<Version>|<DeviceVendor>|<DeviceProduct>|<DeviceVersion>|<DeviceEventClassID>|<Name>|<Severity>|<Extension>
```

The first seven fields are the **header** — pipe-delimited, fixed positions. The eighth and beyond is the **extension** — `key=value` pairs separated by spaces, with `\=` as the literal equals escape inside values.

Example:
```
CEF:0|Palo Alto Networks|PAN-OS|11.1.0|TRAFFIC|allow|1|rt=Apr 28 2026 13:42:11 src=10.0.0.5 dst=10.0.0.10 act=allow proto=tcp app=ssl PanOSRuleName=allow-web
```

## Header → CommonSecurityLog

| CEF header field | CommonSecurityLog column | Notes |
|---|---|---|
| `Version` | (not stored) | Always `0` for CEF v0 |
| `DeviceVendor` | `DeviceVendor` | Direct match |
| `DeviceProduct` | `DeviceProduct` | Direct match |
| `DeviceVersion` | `DeviceVersion` | Vendor's product/firmware version |
| `DeviceEventClassID` | `DeviceEventClassID` | Vendor-specific event identifier |
| `Name` | `Activity` | Human-readable event name |
| `Severity` | `LogSeverity` | Numeric (0-10) or text — preserve as-is |

## Standard CEF extensions → CommonSecurityLog (auto-mapped)

These keys parse natively to first-class columns. **Never** put them in the parser's manual extraction logic — they're already there.

### Network — sources and destinations

| CEF key | Column | Type |
|---|---|---|
| `src` | `SourceIP` | string |
| `spt` | `SourcePort` | int |
| `smac` | `SourceMACAddress` | string |
| `shost` | `SourceHostName` | string |
| `suser` | `SourceUserName` | string |
| `suid` | `SourceUserID` | string |
| `dst` | `DestinationIP` | string |
| `dpt` | `DestinationPort` | int |
| `dmac` | `DestinationMACAddress` | string |
| `dhost` | `DestinationHostName` | string |
| `duser` | `DestinationUserName` | string |
| `duid` | `DestinationUserID` | string |
| `dlat` / `dlong` | `DestinationGeoLatitude` / `DestinationGeoLongitude` | real |

### Network — protocols and traffic

| CEF key | Column |
|---|---|
| `proto` | `Protocol` |
| `app` | `ApplicationProtocol` |
| `in` | `ReceivedBytes` |
| `out` | `SentBytes` |

### Action and outcome

| CEF key | Column |
|---|---|
| `act` | `DeviceAction` |
| `outcome` | `EventOutcome` |
| `reason` | `Reason` |

### URLs / files

| CEF key | Column |
|---|---|
| `request` | `RequestURL` |
| `requestMethod` | `RequestMethod` |
| `requestClientApplication` | `RequestClientApplication` |
| `fname` | `FileName` |
| `fsize` | `FileSize` |
| `fileHash` | `FileHash` |
| `filePath` | `FilePath` |

### Time

| CEF key | Column | Notes |
|---|---|---|
| `rt` | `ReceiptTime` | Project to `TimeGenerated` via DCR transformKql when meaningful |
| `start` / `end` | `StartTime` / `EndTime` | Session boundaries |

### Device-side metadata

| CEF key | Column |
|---|---|
| `dvc` | `DeviceAddress` |
| `dvchost` | `DeviceName` |
| `deviceFacility` | `DeviceFacility` |
| `deviceInboundInterface` / `deviceOutboundInterface` | `DeviceInboundInterface` / `DeviceOutboundInterface` |

### Custom fields (vendor-extensible slots)

CEF reserves 6 string, 3 number, 4 floating-point, and 4 IPv6 custom-field pairs that vendors use for arbitrary fields. The label column documents what the vendor put in the value column.

| CEF value | CEF label | Sentinel value column | Sentinel label column |
|---|---|---|---|
| `cs1` | `cs1Label` | `DeviceCustomString1` | `DeviceCustomString1Label` |
| `cs2` | `cs2Label` | `DeviceCustomString2` | `DeviceCustomString2Label` |
| ... | ... | ... | ... |
| `cs6` | `cs6Label` | `DeviceCustomString6` | `DeviceCustomString6Label` |
| `cn1` | `cn1Label` | `DeviceCustomNumber1` | `DeviceCustomNumber1Label` |
| `cn2` / `cn3` | ... | `DeviceCustomNumber2` / `DeviceCustomNumber3` | ... |
| `cfp1`...`cfp4` | `cfpNLabel` | `DeviceCustomFloatingPoint1`-`4` | `DeviceCustomFloatingPointNLabel` |
| `c6a1`...`c6a4` | `c6aNLabel` | `DeviceCustomIPv6Address1`-`4` | `DeviceCustomIPv6AddressNLabel` |

In your parser, always check the `Label` column before relying on the value column — different events from the same vendor can repurpose the same `cs1` slot.

## Vendor-specific extensions → AdditionalExtensions

Anything not in the standard mapping lands in the `AdditionalExtensions` column as a serialised key-value list:

```
AdditionalExtensions = "PanOSRuleName=allow-web;PanOSSessionID=12345;PanOSThreatID=39082"
```

The parser function extracts these with anchored `extract()`:

```kql
| extend
    PolicyName = extract(@'PanOSRuleName=([^;]+)', 1, AdditionalExtensions),
    SessionID  = tolong(extract(@'PanOSSessionID=([0-9]+)', 1, AdditionalExtensions)),
    ThreatID   = toint(extract(@'PanOSThreatID=([0-9]+)', 1, AdditionalExtensions))
```

Same regex-anchoring rules as syslog parsers (see `KQL_Parser_Standards.md` Rule 3): always anchor on the field-name prefix; never extract by value pattern alone.

## CEF + `_CF` columns — workbench convention

Even though `CommonSecurityLog` already has rich vendor metadata via `DeviceVendor` and `DeviceProduct`, the workbench **still adds the eight `_CF` columns to every CEF integration**. Reasons:

- **Consistency.** Every NXLog-collected integration in the workbench has the same 8 `_CF` columns — `_CF` filtering works identically across syslog and CEF integrations.
- **Defence against schema drift.** If Microsoft ever changes how `DeviceVendor` is populated (it's happened before with the AMA migration), `_CF` columns are guaranteed stable.
- **Collector traceability.** `NXLogServerName_CF`, `NXLogInputModuleName_CF`, `NXLogRouteName_CF` aren't in `CommonSecurityLog` natively — they're operational metadata only `_CF` provides.

The DCR streamDeclarations for CEF integrations list both the standard `CommonSecurityLog` columns AND the 8 `_CF` columns:

```json
"streamDeclarations": {
  "Custom-PaloAltoNetworks-PANOS": {
    "columns": [
      // ... standard CommonSecurityLog columns ...
      { "name": "TimeGenerated",         "type": "datetime" },
      { "name": "DeviceVendor",          "type": "string"   },
      { "name": "DeviceProduct",         "type": "string"   },
      // ... etc ...

      // Workbench _CF enrichment
      { "name": "DeviceVendor_CF",       "type": "string" },
      { "name": "DeviceProduct_CF",      "type": "string" },
      { "name": "DatasourceName_CF",     "type": "string" },
      { "name": "DeviceAddress_CF",      "type": "string" },
      { "name": "RawLog_CF",             "type": "string" },
      { "name": "NXLogInputModuleName_CF","type": "string" },
      { "name": "NXLogRouteName_CF",     "type": "string" },
      { "name": "NXLogServerName_CF",    "type": "string" }
    ]
  }
}
```

The `_CF` columns are populated by the same NXLog `<Exec>` block as syslog integrations — same eight literals, same source expressions.

`outputStream` for CEF integrations is `Microsoft-CommonSecurityLog` (not `Microsoft-Syslog`).

## Securonix → Sentinel migration crosswalk

For SOC analysts migrating Securonix queries to Sentinel CEF parsers, here are the most common Securonix field names and their Sentinel equivalents:

| Securonix field | Sentinel column |
|---|---|
| `sourceaddress` | `SourceIP` |
| `sourceport` | `SourcePort` |
| `destinationaddress` | `DestinationIP` |
| `destinationport` | `DestinationPort` |
| `accountname` | `SourceUserName` |
| `eventoutcome` | `EventOutcome` |
| `eventaction` | `DeviceAction` |
| `eventseverity` | `LogSeverity` |
| `bytesin` / `bytesout` | `ReceivedBytes` / `SentBytes` |
| `protocol` | `Protocol` |
| `applicationprotocol` | `ApplicationProtocol` |
| `requesturl` | `RequestURL` |
| `filename` / `filehash` | `FileName` / `FileHash` |
| `transactionstring1`/`2`/`3` | `DeviceCustomString1`/`2`/`3` |

Securonix-specific fields starting with `customstring`, `transactionnumber`, or `additionalinfo` map to `AdditionalExtensions` and require explicit extraction.

## Things deliberately NOT in CommonSecurityLog

Common fields that don't have a native column — go to `AdditionalExtensions` or a `DeviceCustomString` slot:

- `policyName` / `ruleName` (firewall rule that matched)
- `category` (vendor's threat category)
- `signatureID` (vendor IPS/IDS signature ID)
- `confidenceLevel` / `riskScore`
- `threatId` / `threatName`
- `userAgent` (often goes to `RequestClientApplication`)
- `httpStatus`
- `tlsVersion` / `cipherSuite`
- `clientCommonName` / `serverCommonName`

If your environment queries one of these often, promote it to a `DeviceCustomString*` slot via the DCR's `transformKql` projection.
