# ASIM EventCategory Reference

Microsoft's **Advanced Security Information Model (ASIM)** is a normalised schema layer that lets queries work across vendors. The workbench's parsers apply ASIM's `EventCategory` field as the second-to-last `extend` step, so cross-product Sentinel analytics light up automatically.

## When to set EventCategory

Always. Every parser the workbench produces sets `EventCategory` on every row. Default to `"Unknown"` if no mapping fits — this lets analysts filter `where EventCategory != "Unknown"` to find unparsed events that might need parser updates.

## Standard category values

The full list Microsoft documents is large (40+ categories); the workbench uses this subset because it covers virtually all NXLog-collected security telemetry. Add new categories only when an existing one genuinely doesn't fit.

### Authentication & identity

| EventCategory | Source event examples |
|---|---|
| `Authentication` | Successful login (any kind — VPN, SSH, RDP, SAML, app sign-in) |
| `AuthenticationFailed` | Failed login, wrong password, expired account, locked-out attempt |
| `AccountLocked` | Account locked due to repeated failures or admin action |
| `AccountUnlocked` | Account unlocked, password reset, lockout expired |
| `Logoff` | Session end, logout, disconnect |
| `SessionTimedOut` | Session expired due to idle/max-session timeouts |
| `SessionTransferred` | Session re-keyed, single-sign-on hop, federated auth bridge |

### Network sessions

| EventCategory | Source event examples |
|---|---|
| `NetworkSession` | Allowed network connection (firewall allow rule, IDS in monitor mode) |
| `NetworkSessionDeny` | Denied network connection (firewall drop, web proxy block) |
| `NetworkAccessDenied` | Access denied at the policy level (geo block, time-of-day, source-IP-restriction) |
| `WebFiltered` | URL category block, content filter match |
| `DnsActivity` | DNS query/response/refused (DNS firewall, RPZ, Sinkhole) |

### Process & file activity

| EventCategory | Source event examples |
|---|---|
| `ProcessCreated` | Sysmon Event ID 1, Windows 4688, Linux execve |
| `ProcessTerminated` | Sysmon 5, exit syscalls |
| `FileCreated` | New file write, Sysmon 11, Linux audit syscall:open(O_CREAT) |
| `FileDeleted` | File unlink |
| `FileModified` | Existing file write, content change |
| `FileAccessed` | Read access (rarely worth logging at scale; usually only for sensitive paths) |

### Configuration & administration

| EventCategory | Source event examples |
|---|---|
| `ConfigurationChanged` | Admin changed a setting — firewall rule, AD object, Sentinel rule, GPO |
| `UserManagement` | User created, deleted, modified, role changed |
| `GroupManagement` | Group membership change, group create/delete |
| `PolicyChanged` | Audit policy, password policy, conditional-access policy edit |
| `ServiceStartStop` | Windows service started or stopped, daemon restart |

### Threats & security state

| EventCategory | Source event examples |
|---|---|
| `Malware` | AV/EDR detected malware, hash match, signature match |
| `ThreatDetected` | IPS/IDS signature hit, behavioural analytics flag |
| `SecurityStateChanged` | TLS version downgrade, cert expiry warning, host-checker state, AV signature update |
| `Vulnerability` | Vulnerability scanner finding, CVE match in installed software |

### Catch-all

| EventCategory | When to use |
|---|---|
| `Unknown` | The event didn't match any of the above. Use sparingly — investigate and add a real mapping if you see lots of `Unknown` rows. |

## Mapping pattern in the parser

Always use a single `case()` clause with conditions ordered most-specific to least-specific. Example from the Ivanti parser:

```kql
| extend EventCategory = case(
    Stream == "UserAccess" and AuthenticationResult == "Login succeeded",                "Authentication",
    Stream == "UserAccess" and AuthenticationResult in ("Login failed", "Authentication failed"), "AuthenticationFailed",
    Stream == "UserAccess" and AuthenticationResult == "Account locked",                  "AccountLocked",
    Stream == "UserAccess" and EventText has_any ("Session ended", "Logged out"),         "Logoff",
    Stream == "UserAccess" and isnotempty(HostCheckerResult),                             "SecurityStateChanged",
    Stream == "WebServer"  and isnotempty(RequestUrl),                                    "NetworkSessionDeny",
    Stream == "WebServer"  and EventText has "SSL negotiation failed",                    "SecurityStateChanged",
    Stream == "WebServer"  and HostHeaderRejected,                                        "NetworkSessionDeny",
    Stream == "WebServer"  and RealmRestrictionFail,                                      "NetworkAccessDenied",
    Stream == "AdminAccess" and isnotempty(ConfigChangeAction),                           "ConfigurationChanged",
    "Unknown"
)
```

Three things to notice:

1. The conditions combine `Stream` (broad routing) with specific extracted fields. Specific-first means an `Authentication` event isn't accidentally caught by a broader rule.
2. Multiple conditions can map to the same category (`SecurityStateChanged` covers both Host-Checker results and SSL failures — both are "security posture changed").
3. The default `"Unknown"` is at the bottom — never silently drop unmapped events.

## EventResult — paired with EventCategory

For `Authentication` and `NetworkSession*` categories, ASIM also defines `EventResult`. Use `Success`, `Failure`, `Partial`, or `NA`:

```kql
| extend EventResult = case(
    EventCategory == "Authentication",       "Success",
    EventCategory == "AuthenticationFailed", "Failure",
    EventCategory == "AccountLocked",        "Failure",
    EventCategory == "NetworkSession",       "Success",
    EventCategory in ("NetworkSessionDeny", "NetworkAccessDenied"), "Failure",
    "NA"
)
```

The workbench parsers don't always set `EventResult` because some categories (`ConfigurationChanged`, `Logoff`, `Malware`) don't have a clean Success/Failure interpretation. Add it where it makes sense for that data source.

## Reference

Microsoft's full ASIM schema documentation is at https://learn.microsoft.com/en-us/azure/sentinel/normalization. When in doubt about a less-common category (`AuditEvent`, `ThreatIntelMatch`, etc.), check there.
