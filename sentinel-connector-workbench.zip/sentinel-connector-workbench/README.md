# Sentinel Connector Workbench

A VS Code + GitHub Copilot Agent Mode framework that generates production-ready Microsoft Sentinel data-source integration bundles. Hand Copilot a vendor name and a sample log; get back an NXLog Enterprise config, a dual-region DCR ARM template, a validated KQL parser, and a polished HTML integration document.

Built for environments where:
- Sentinel runs in **multiple regions** with active-passive failover (this deployment: UAE prod + CH DR)
- Log collection uses **NXLog Enterprise Edition** with the `om_http` Pattern A
- A single **Entra tenant** issues credentials that work across both regional DCRs
- Every integration must follow a **fixed eight-section document structure** and a **fixed `_CF` enrichment schema**
- Every parser must be **validated against the live workspace** before being saved

Detection engineering (analytic rules, hunting queries, threat scenarios) lives in a separate project — this workbench produces the integrations only.

## What's in the box

```
sentinel-connector-workbench/
├── .github/
│   ├── copilot-instructions.md          ← 15 Universal Rules (the load-bearing file)
│   └── skills/
│       ├── syslog-integration/SKILL.md       ← Default skill for RFC 3164/5424 syslog
│       ├── cef-integration/SKILL.md          ← For RFC-compliant CEF (PAN-OS, FortiGate, etc.)
│       ├── windows-eventlog-integration/SKILL.md  ← For im_msvistalog → SecurityEvent/WindowsEvent
│       └── json-api-integration/SKILL.md     ← For REST-API push/pull (CrowdStrike, Okta, etc.)
├── .vscode/
│   └── mcp.json.template                ← 5 MCP servers wiring (sentinel-triage, kql-search, etc.)
├── reference/
│   ├── NXLog_EE_Config_Patterns.md      ← Pattern A explained, %ACTIVE_DESTINATION% toggle, OnError
│   ├── KQL_Parser_Standards.md          ← Function naming, _CF filter rule, validation gate
│   ├── Syslog_CF_Schema.md              ← The eight _CF columns — how they're set + queried
│   ├── CEF_to_CommonSecurityLog_Mapping.md  ← Standard CEF extensions, custom-string slots
│   ├── ASIM_EventCategory_Reference.md  ← The category vocabulary parsers map to
│   ├── Document_Design_Standards.md     ← IBM Plex typography, navy/orange/teal palette
│   └── Azure_Bearer_Token_Refresh.md    ← Centralised token-refresh script — once per collector
├── templates/
│   ├── nxlog/syslog-input.conf          ← Pattern A with %ACTIVE_DESTINATION% toggle
│   ├── dcr/syslog-dcr.json              ← Single ARM template — deploys to either region
│   ├── kql/syslog-parser-template.kql   ← Parser skeleton with placeholder substitution points
│   └── html/starter.html                ← 8-section integration guide template
├── library/                              ← Curated parsers/configs from prior integrations (empty initially)
├── outputs/
│   ├── ivanti-connect-secure/           ← Worked example: Syslog + _CF path
│   └── palo-alto-pan-os/                ← Worked example: CEF + _CF path
├── scripts/
│   ├── refresh_azure_token.sh           ← Deployable token-refresh script (cron every 25 min)
│   ├── validate_dcr.py                  ← Lints DCR templates against workbench standards
│   └── deploy_dcr.ps1                   ← Deploys a DCR template to both UAE and CH RGs
├── docs/
│   └── samples/                          ← Sanitised sample wire-format logs
├── config.json.template                  ← Tenant/region/SP config (copy to config.json, gitignored)
├── .gitignore
└── README.md (this file)
```

## Quick start

### 1. Clone and configure

```bash
git clone <this repo>
cd sentinel-connector-workbench

cp config.json.template config.json
cp .vscode/mcp.json.template .vscode/mcp.json

# Edit both files — replace [tokens] with real tenant/subscription/workspace IDs
```

### 2. Open in VS Code with GitHub Copilot Agent Mode

VS Code + the GitHub Copilot extension (Agent Mode) reads `.github/copilot-instructions.md` automatically and surfaces the four skills based on your prompt. The MCP servers in `.vscode/mcp.json` give Copilot direct access to your Sentinel workspace for parser validation.

### 3. Onboard a new data source

In VS Code's Copilot chat:

```
@workspace I need to onboard <vendor> <product> to Sentinel.
We have a sample log in docs/samples/<vendor>-sample.log.
Major event types are: <auth, traffic, config-change, ...>.
Transport is <UDP/514 | TCP/601 | TLS/6514>.
```

Copilot will:
1. Detect the right skill from the vendor / format keywords
2. Ask for any missing inputs in one consolidated message
3. Generate the six-file bundle in `outputs/<vendor-product>/`
4. Validate the parser against the live workspace via Sentinel Triage MCP (Rule 10 hard gate)
5. Annotate the parser with `// VALIDATED <date>` or explicitly tell you why validation was skipped

### 4. Deploy

```bash
# Validate the generated DCR
python3 scripts/validate_dcr.py outputs/<vendor-product>/dcr-arm-template.json

# Deploy to both regions
pwsh scripts/deploy_dcr.ps1 -BundlePath outputs/<vendor-product>

# The script outputs the DCE endpoint and DCR immutable ID for each region.
# Substitute these into outputs/<vendor-product>/nxlog.conf:
#   define DCE_ENDPOINT_PROD     https://...
#   define DCR_RULE_ID_PROD      [immutable-id]
#   define DCE_ENDPOINT_DR       https://...
#   define DCR_RULE_ID_DR        [immutable-id]

# Deploy nxlog.conf to each collector and reload
scp outputs/<vendor-product>/nxlog.conf [collector]:/etc/nxlog/
ssh [collector] "sudo nxlog -v && sudo systemctl reload nxlog"
```

### 5. Operational verification

Open `outputs/<vendor-product>/integration-guide.html` in a browser. Section 08 has five validation queries (`VQ-01` through `VQ-05`) — run them in Sentinel to confirm:

- VQ-01: Events flowing per Stream and EventCategory
- VQ-02: Every appliance heartbeating
- VQ-03: Primary-data-content query — events look right
- VQ-04: Parser coverage above 95% (i.e., very few `Unknown` EventCategory rows)
- VQ-05: Top failure sources surface useful triage candidates

If all five pass, the integration is healthy.

## Architecture

```
[devices]  ────UDP/514, TCP/601, TLS/6514────►  [NXLog collector]
                                                       │
                                                       │ om_http (Pattern A)
                                                       │ %ACTIVE_DESTINATION% toggle
                                                       │
                              ┌────────────────────────┴───────────────────────┐
                              │                                                 │
                              ▼                                                 ▼
                  ╔════════════════════════╗                       ╔════════════════════════╗
                  ║   UAE prod DCE         ║                       ║   CH DR DCE            ║
                  ║   dce-prod-uae         ║                       ║   dce-dr-ch            ║
                  ║                        ║                       ║                        ║
                  ║   DCR (per-source)     ║                       ║   DCR (per-source)     ║
                  ║   streamDeclarations:  ║                       ║   streamDeclarations:  ║
                  ║   Custom-Vendor-Product║                       ║   Custom-Vendor-Product║
                  ║                        ║                       ║                        ║
                  ║   transformKql:        ║                       ║   transformKql:        ║
                  ║   extend Computer      ║                       ║   extend Computer      ║
                  ║   = HostName ...       ║                       ║   = HostName ...       ║
                  ║                        ║                       ║                        ║
                  ║   outputStream:        ║                       ║   outputStream:        ║
                  ║   Microsoft-Syslog     ║                       ║   Microsoft-Syslog     ║
                  ║   (or *-CommonSecLog,  ║                       ║   (or *-CommonSecLog,  ║
                  ║    *-SecurityEvent,    ║                       ║    *-SecurityEvent,    ║
                  ║    *-WindowsEvent)     ║                       ║    *-WindowsEvent)     ║
                  ╚════════════════════════╝                       ╚════════════════════════╝
                              │                                                 │
                              ▼                                                 ▼
                  ┌────────────────────────┐                       ┌────────────────────────┐
                  │  UAE Sentinel          │                       │  CH Sentinel           │
                  │  (active by default)   │                       │  (cold standby —       │
                  │                        │                       │   DCR provisioned,     │
                  │  + 8 _CF cols          │                       │   no traffic until     │
                  │  + parser fn           │                       │   failover toggle      │
                  └────────────────────────┘                       │   flipped)             │
                                                                   └────────────────────────┘

   Authentication: ONE Entra tenant. ONE app registration. ONE bearer token in cache file.
   Same Service Principal granted "Monitoring Metrics Publisher" on both DCRs.
   Token refresh: cron-driven /opt/nxlog/bin/refresh_azure_token.sh every 25 min.
   OAuth call routes via corporate proxy; DCE ingest direct via ExpressRoute.
   Failover: edit %ACTIVE_DESTINATION% in nxlog.conf, systemctl reload — ~30 seconds.
```

## The eight `_CF` columns

Every workbench-generated integration sets these eight columns on every row, regardless of target table or log format:

| Column | Source |
|---|---|
| `DeviceVendor_CF` | Hardcoded literal in NXLog `<Exec>` (e.g., `"Ivanti"`) |
| `DeviceProduct_CF` | Hardcoded literal (e.g., `"Connect Secure"`) |
| `DatasourceName_CF` | `<Vendor>_<Product>` PascalCase (e.g., `"Ivanti_ConnectSecure"`) |
| `DeviceAddress_CF` | `$MessageSourceAddress` |
| `RawLog_CF` | `$raw_event` (forensic only, large — don't query routinely) |
| `NXLogInputModuleName_CF` | `$SourceModuleName` |
| `NXLogRouteName_CF` | Hardcoded literal (e.g., `"route_ivanti-connectsecure_azure"`) |
| `NXLogServerName_CF` | `hostname()` |

Every parser starts with `where DeviceVendor_CF == "<Vendor>" | where DeviceProduct_CF == "<Product>"` — never filtering on native columns. This survives any upstream relay topology where native `Computer`/`HostName` would be the relay's identity rather than the appliance's. See `reference/Syslog_CF_Schema.md` for the full rationale.

## The eight document sections

Every generated integration guide has exactly these sections — fixed structure for SOC consistency:

```
01 Device Config       — what to do on the source device
02 NXLog               — full nxlog.conf with %ACTIVE_DESTINATION% toggle
03 DCR ARM             — DCR ARM template (deploys to both regions)
04 Field Mapping       — native + _CF column mapping tables
05 Event Catalogue     — vendor event types per stream
06 Sample Logs         — sanitised wire-format samples
07 KQL Parser          — saved function with regex extraction
08 Validation          — 5 KQL queries (VQ-01..VQ-05) confirming healthy ingestion
```

Section 09 (Threat Scenarios) is deliberately removed. Detection engineering lives in the separate detection-engineering project.

## Skill detection

Copilot picks the right skill from your prompt's keywords:

| You say | Skill |
|---|---|
| "Palo Alto", "Fortinet", "Check Point", "F5", "CEF" | `cef-integration` |
| "Cisco IOS", "Juniper Junos", "Ivanti", "syslog", anything else syslog-shaped | `syslog-integration` (default) |
| "Windows", "Active Directory", "Event ID", "Sysmon" | `windows-eventlog-integration` |
| "CrowdStrike", "Okta API", "REST API", "JSON ingestion" | `json-api-integration` |

If the keywords are ambiguous, Copilot asks once and proceeds.

## Worked examples

Two complete bundles ship with the workbench so you can see the output shape end-to-end before generating your own:

- **`outputs/ivanti-connect-secure/`** — Syslog + `_CF` path. Demonstrates RFC 5424 syslog with the `PulseSecure:` wire tag, position-anchored regex extraction, ASIM EventCategory mapping with stream routing, and a `SuspiciousUrl` flag for Ivanti CVE PoC paths.
- **`outputs/palo-alto-pan-os/`** — CEF + `_CF` path. Demonstrates `parse_cef()` auto-mapping standard CEF extensions to native CommonSecurityLog columns, with parser regex extraction lifting `PanOS*` vendor extensions out of `AdditionalExtensions`.

Both share the same `om_http` Pattern A, the same `%ACTIVE_DESTINATION%` toggle, the same eight `_CF` columns, and the same eight-section document structure — they only differ where the log format genuinely requires it.

## Validation hard gate

Rule 10 in `.github/copilot-instructions.md`: **Copilot will not write `parser.kql` to disk until the parser has been validated against the live workspace via Sentinel Triage MCP** (`RunAdvancedHuntingQuery`). On success, the file header is annotated `// VALIDATED <date>`. On failure, the file isn't written and the user is told why. If validation can't run (no MCP, no events in the table yet), the file is written with `// VALIDATION SKIPPED — REASON: <reason>` and the user is told explicitly.

This is the single most important workbench guardrail — it prevents shipping parsers that look right but don't run.

## Failover procedure

The DR pattern is **active-passive via toggle**, not dual-ingest:

```
# At top of every generated nxlog.conf:
define ACTIVE_DESTINATION  om_azure_prod_uae    # ACTIVE   — UAE production
# define ACTIVE_DESTINATION  om_azure_dr_ch      # STANDBY — CH disaster recovery

# To fail over (~30 seconds):
sudo vi /etc/nxlog/nxlog.conf  # swap the comments on the two lines above
sudo nxlog -v                   # validate syntax
sudo systemctl reload nxlog     # apply

# Verify within 30 seconds:
sudo tail -f /var/log/nxlog/nxlog.log | grep om_azure_dr_ch
# Expect: HTTP 204 responses against the CH DCE
```

Both regional DCRs are provisioned ahead of time. The same Entra app has `Monitoring Metrics Publisher` on both. The same bearer token works for both. Failover changes only which `<Output>` block the route resolves to — no token re-authentication delay.

## Known good vs not-yet-validated

The two worked examples (`ivanti-connect-secure`, `palo-alto-pan-os`) ship with `// VALIDATION SKIPPED` headers because the workbench bundle was generated outside the live MCP environment. Re-run the validation gate against your actual UAE prod workspace before relying on either parser for production analytics — Copilot will do this automatically the first time you ask it to use either bundle.

## Adding a new vendor

The workflow your engineers will follow:

1. Capture sample logs (one per major event type) into `docs/samples/<vendor>-sample.log`
2. Open Copilot chat in VS Code: *"Onboard <vendor> <product> to Sentinel"*
3. Answer Copilot's clarification questions (if any)
4. Review the generated bundle in `outputs/<vendor>-<product>/`
5. Deploy the DCRs and the NXLog config
6. Run the five validation queries
7. Commit the bundle to git so it's reproducible / auditable

If a vendor's wire format differs significantly from the worked examples, copy a working parser into `library/<archetype>/` so future similar integrations branch from it rather than from the empty template.
