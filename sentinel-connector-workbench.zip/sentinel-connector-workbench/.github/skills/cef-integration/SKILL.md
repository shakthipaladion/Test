# Skill: CEF Integration

This skill produces an integration bundle for vendors that emit RFC-compliant Common Event Format (CEF) — landing in Sentinel's built-in `CommonSecurityLog` table, enriched with the eight `_CF` columns. It inherits the architecture of `syslog-integration` and differs only where CEF requires it.

If the vendor *labels* their output "CEF" but the wire format isn't actually compliant (common with older Cisco devices, some Trend Micro products), use `syslog-integration` instead. **Verify against a real sample before committing to this skill.**

## Triggers

Activate this skill when the user mentions any of:
- A specific vendor known for RFC-compliant CEF: Palo Alto Networks, Fortinet (FortiGate), Check Point, F5 (ASM/AWAF), CyberArk, Trend Micro Deep Security, Symantec, McAfee, Bluecoat ProxySG, Sophos
- Generic phrasing: "CEF", "CEF:0", "Common Event Format", "ArcSight CEF"
- A sample log starting with `CEF:0|<Vendor>|<Product>|...`

## Differences from syslog-integration

The 8-phase workflow is identical. Only specific values change:

| Item | Syslog | CEF |
|---|---|---|
| NXLog parse function | `parse_syslog()` | `parse_cef()` |
| NXLog template | `templates/nxlog/syslog-input.conf` | `templates/nxlog/syslog-input.conf` (same template, swap `parse_syslog` → `parse_cef` in the `{{NXLOG_PARSE_FN}}` token) |
| DCR template | `templates/dcr/syslog-dcr.json` | use the same template but adjust column declarations to match CEF native columns + `_CF` (see below) |
| DCR `outputStream` | `Microsoft-Syslog` | `Microsoft-CommonSecurityLog` |
| Target table | `Syslog` | `CommonSecurityLog` |
| Parser source columns | `SyslogMessage` | `AdditionalExtensions` (CEF extensions); + named columns (`SourceIP`, `DestinationIP`, etc.) |
| `transformKql` | `extend Computer = HostName` | `extend Computer = DeviceName` |
| Reference doc | `Syslog_CF_Schema.md` | `CEF_to_CommonSecurityLog_Mapping.md` (read both — the `_CF` schema is the same; CEF mapping doc adds CEF-specific guidance) |

Everything else — the active-passive failover toggle, the eight `_CF` columns, the `<Exec>` block 8-phase structure, the parser's `(starttime, endtime)` signature, the validation hard gate, the 8-section document structure — is identical.

## CEF-specific column declarations in the DCR

CEF integrations declare a different column set in `streamDeclarations`. The columns reflect `CommonSecurityLog`'s native schema plus the 8 `_CF` columns. From `templates/dcr/syslog-dcr.json`, replace the columns array with:

```json
"columns": [
  { "name": "TimeGenerated",            "type": "datetime" },
  { "name": "DeviceVendor",             "type": "string"   },
  { "name": "DeviceProduct",            "type": "string"   },
  { "name": "DeviceVersion",            "type": "string"   },
  { "name": "DeviceEventClassID",       "type": "string"   },
  { "name": "Activity",                 "type": "string"   },
  { "name": "LogSeverity",              "type": "string"   },
  { "name": "DeviceAction",             "type": "string"   },
  { "name": "SourceIP",                 "type": "string"   },
  { "name": "SourcePort",               "type": "int"      },
  { "name": "SourceUserName",           "type": "string"   },
  { "name": "DestinationIP",            "type": "string"   },
  { "name": "DestinationPort",          "type": "int"      },
  { "name": "DestinationUserName",      "type": "string"   },
  { "name": "Protocol",                 "type": "string"   },
  { "name": "ApplicationProtocol",      "type": "string"   },
  { "name": "RequestURL",               "type": "string"   },
  { "name": "RequestMethod",            "type": "string"   },
  { "name": "DeviceCustomString1",      "type": "string"   },
  { "name": "DeviceCustomString1Label", "type": "string"   },
  { "name": "DeviceCustomString2",      "type": "string"   },
  { "name": "DeviceCustomString2Label", "type": "string"   },
  { "name": "DeviceCustomString3",      "type": "string"   },
  { "name": "DeviceCustomString3Label", "type": "string"   },
  { "name": "DeviceCustomString4",      "type": "string"   },
  { "name": "DeviceCustomString4Label", "type": "string"   },
  { "name": "DeviceCustomString5",      "type": "string"   },
  { "name": "DeviceCustomString5Label", "type": "string"   },
  { "name": "DeviceCustomString6",      "type": "string"   },
  { "name": "DeviceCustomString6Label", "type": "string"   },
  { "name": "DeviceCustomNumber1",      "type": "long"     },
  { "name": "DeviceCustomNumber1Label", "type": "string"   },
  { "name": "AdditionalExtensions",     "type": "string"   },
  { "name": "DeviceName",               "type": "string"   },
  { "name": "DeviceAddress",            "type": "string"   },

  { "name": "DeviceVendor_CF",          "type": "string"   },
  { "name": "DeviceProduct_CF",         "type": "string"   },
  { "name": "DatasourceName_CF",        "type": "string"   },
  { "name": "DeviceAddress_CF",         "type": "string"   },
  { "name": "RawLog_CF",                "type": "string"   },
  { "name": "NXLogInputModuleName_CF",  "type": "string"   },
  { "name": "NXLogRouteName_CF",        "type": "string"   },
  { "name": "NXLogServerName_CF",       "type": "string"   }
]
```

Add additional columns (e.g., `DeviceCustomNumber2`/`3`, `DeviceCustomFloatingPoint1`-`4`, `DeviceCustomIPv6Address1`-`4`) only when the specific vendor uses those slots.

## CEF-specific NXLog `<Exec>` block adjustments

In Phase 4 (`_CF` enrichment) the literals change per vendor. In Phase 3 (mapping native fields), CEF's `parse_cef()` populates a different set of NXLog field names than `parse_syslog()`:

```
<Exec>
    parse_cef();
    if $Message == undef or $Message == '' { drop(); }

    ## Map parsed CEF fields onto Sentinel CommonSecurityLog columns
    $TimeGenerated         = $EventTime;
    $DeviceVendor          = $CEF.DeviceVendor;
    $DeviceProduct         = $CEF.DeviceProduct;
    $DeviceVersion         = $CEF.DeviceVersion;
    $DeviceEventClassID    = $CEF.DeviceEventClassID;
    $Activity              = $CEF.Name;
    $LogSeverity           = $CEF.Severity;
    $DeviceName            = $Hostname;        ## NXLog's parsed syslog hostname
    $DeviceAddress         = $MessageSourceAddress;

    ## Standard CEF extensions auto-populated to native columns by parse_cef
    ## ($SourceIP, $DestinationIP, $DeviceAction, etc.)
    ## Just confirm no need to manually re-assign — they're already on the record.

    ## _CF enrichment (eight workbench-standard columns)
    $DeviceVendor_CF          = "<Vendor>";              ## e.g. "Palo Alto Networks"
    $DeviceProduct_CF         = "<Product>";             ## e.g. "PAN-OS"
    $DatasourceName_CF        = "<Vendor>_<Product>";    ## e.g. "PaloAltoNetworks_PANOS"
    $DeviceAddress_CF         = $MessageSourceAddress;
    $RawLog_CF                = $raw_event;
    $NXLogInputModuleName_CF  = $SourceModuleName;
    $NXLogRouteName_CF        = "route_<vendor>-<product-lower>_azure";
    $NXLogServerName_CF       = hostname();

    ## Strip NXLog-internal fields
    delete($EventReceivedTime); delete($SourceModuleName);
    delete($SourceModuleType);  delete($EventTime);
    delete($Hostname);          delete($MessageSourceAddress);

    ## Token loading and serialisation — identical to syslog
    if get_var('aad_bearer_token') == undef {
        set_var('aad_bearer_token', file_read('%TOKEN_CACHE%'));
    }
    add_http_header('Authorization', 'Bearer ' + get_var('aad_bearer_token'));
    to_json();
</Exec>
```

The `parse_cef()` function populates a `$CEF` namespace; standard extensions like `src` / `dst` / `act` are also surfaced as top-level NXLog fields.

## CEF-specific parser body

The parser's frame extraction phase is much simpler than syslog — `parse_cef()` and the DCR have already done most of the work. Focus parser logic on:

1. **`AdditionalExtensions` parsing** — vendor-specific keys not in the standard CEF mapping. Use anchored regex: `extract(@'PanOSRuleName=([^;]+)', 1, AdditionalExtensions)`.
2. **`DeviceCustomString*` lookups** — check the matching `Label` column to know what each slot holds.
3. **Subsystem routing** — many vendors emit multiple event types under one `DeviceProduct`; the parser routes by `Activity` or `DeviceEventClassID`.

Example skeleton:

```kql
.create-or-alter function <Vendor><Product>Audit(starttime:datetime = datetime(null),
                                                 endtime:datetime   = datetime(null)) {
let _start = iff(isnull(starttime), ago(1h), starttime);
let _end   = iff(isnull(endtime),   now(),    endtime);
//
CommonSecurityLog
| where TimeGenerated between (_start .. _end)
| where DeviceVendor_CF  == "<Vendor>"
| where DeviceProduct_CF == "<Product>"
//
// AdditionalExtensions parsing — vendor-specific fields
| extend
    PolicyName = extract(@'<VendorPrefix>RuleName=([^;]+)',  1, AdditionalExtensions),
    SessionID  = tolong(extract(@'<VendorPrefix>SessionID=([0-9]+)', 1, AdditionalExtensions)),
    ThreatID   = toint(extract(@'<VendorPrefix>ThreatID=([0-9]+)',   1, AdditionalExtensions))
//
// Subsystem routing
| extend Stream = case(
    Activity has_any ("traffic", "TRAFFIC"),    "Traffic",
    Activity has_any ("threat", "THREAT"),      "Threat",
    Activity has_any ("system", "SYSTEM"),      "System",
    Activity has_any ("config", "CONFIG"),      "Configuration",
    "Other"
)
//
// ASIM EventCategory derivation
| extend EventCategory = case(
    Stream == "Traffic"  and DeviceAction == "allow",  "NetworkSession",
    Stream == "Traffic"  and DeviceAction == "deny",   "NetworkSessionDeny",
    Stream == "Threat",                                 "ThreatDetected",
    Stream == "Configuration",                         "ConfigurationChanged",
    "Unknown"
)
//
// Final projection
| project
    TimeGenerated, Computer = DeviceName, SourceSystem,
    Stream, EventCategory,
    DeviceVendor, DeviceProduct,
    SourceIP, SourcePort, SourceUserName,
    DestinationIP, DestinationPort, DestinationUserName,
    Protocol, ApplicationProtocol, RequestURL,
    DeviceAction, Activity, LogSeverity,
    PolicyName, SessionID, ThreatID,
    // _CF trace fields
    DeviceVendor_CF, DeviceProduct_CF, DatasourceName_CF,
    DeviceAddress_CF, NXLogInputModuleName_CF,
    NXLogRouteName_CF, NXLogServerName_CF, RawLog_CF
}
```

## Worked example

`outputs/palo-alto-pan-os/` is a complete worked example using this skill — reference its structure when generating new CEF integrations.

## File outputs

Same as `syslog-integration`:
```
outputs/<vendor-product>/
├── nxlog.conf
├── dcr-arm-template.json
├── field-mapping.md
├── parser.kql
├── validation-queries.kql
└── integration-guide.html
```

## Acceptance checks

Same as `syslog-integration`, plus:
- [ ] DCR `outputStream` = `Microsoft-CommonSecurityLog`
- [ ] DCR `transformKql` uses `extend Computer = DeviceName` (not `HostName`)
- [ ] NXLog config uses `parse_cef()` (not `parse_syslog()`)
- [ ] Parser filters `CommonSecurityLog` (not `Syslog`)
- [ ] `AdditionalExtensions` extractions use anchored regex
- [ ] `DeviceCustomString*` slots are documented in field mapping (which slot holds what)
