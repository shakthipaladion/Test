# Skill: Windows Event Log Integration

This skill produces an integration bundle for Windows hosts forwarding events via NXLog's `im_msvistalog` module — landing in either `SecurityEvent` (Windows Security channel) or `WindowsEvent` (other Windows channels), enriched with the eight `_CF` columns.

## Triggers

Activate this skill when the user mentions:
- "Windows", "Windows Event Log", "Windows Security log", "Windows event channel"
- "Active Directory", "Domain Controller", "DC logs"
- "Event ID", "EventID", "im_msvistalog", "WEC"
- "Sysmon" (custom Windows event channel)

## Channel-to-table decision

| Channel | Target table | DCR `outputStream` |
|---|---|---|
| Windows **Security** channel | `SecurityEvent` | `Microsoft-SecurityEvent` |
| Windows **System**, **Application**, custom (Sysmon, Defender, AppLocker, etc.) | `WindowsEvent` | `Microsoft-WindowsEvent` |

`SecurityEvent` is the "fat" table with rich first-class columns for every Security-channel event (LogonType, TargetUserName, NewProcessName, etc.). `WindowsEvent` is a more flexible schema that takes any other channel and stores the event data as XML/JSON.

If the user wants to ingest **both** Security and other channels, generate **two integrations** — one bundle per target table — with two separate DCRs and two streams. Don't try to mix channels into one DCR.

## Differences from syslog-integration

| Item | Syslog | Windows |
|---|---|---|
| NXLog input module | `im_udp` / `im_tcp` / `im_ssl` | `im_msvistalog` |
| NXLog parse function | `parse_syslog()` | (none — `im_msvistalog` produces structured fields directly) |
| Wire transport | UDP/TCP/TLS to the NXLog collector | NXLog runs **on each Windows host** (or on a Windows Event Collector aggregator) |
| Target table | `Syslog` | `SecurityEvent` or `WindowsEvent` |
| `outputStream` | `Microsoft-Syslog` | `Microsoft-SecurityEvent` / `Microsoft-WindowsEvent` |
| Event filtering | All events received | Use `<QueryXML>` to filter at source — events are high-volume |

## NXLog deployment topology

Two patterns:

**Pattern W1 — NXLog on each Windows host:** install NXLog Enterprise as a Windows service on every monitored host. `im_msvistalog` reads the local event log; `om_http` POSTs directly to Azure DCE. Bearer token cache is per-host. Best for 10s of hosts.

**Pattern W2 — Windows Event Collector + NXLog Linux relay:** Windows hosts forward via WinRM/WEC to a Windows Event Collector (WEC) server. NXLog runs on a Linux relay that pulls events from WEC via WMI/PSRemoting (or WEC re-emits via syslog to the Linux NXLog). Best for 100s+ hosts.

The workbench skill defaults to **Pattern W1** unless the user specifies otherwise — confirm with the user.

## NXLog `<Input>` block — `im_msvistalog`

```
<Input im_windows_security>
    Module      im_msvistalog
    SavePos     TRUE
    ReadFromLast TRUE
    <QueryXML>
        <QueryList>
            <Query Id="0">
                <Select Path="Security">*</Select>
                <!-- Select Path="System">*</Select -->
                <!-- Select Path="Application">*</Select -->
            </Query>
        </QueryList>
    </QueryXML>
</Input>
```

**Critical settings:**
- `SavePos TRUE` — NXLog records its position in the channel; on restart resumes from where it left off rather than re-reading.
- `ReadFromLast TRUE` — first time NXLog starts on a host, it skips the entire historical channel and only reads new events. (Without this, the first NXLog start ingests months of historical events into Sentinel, which is rarely what you want.)
- `<QueryXML>` — exact same XPath query language as Windows Event Viewer's "Filter Current Log" → "XML" tab. Test queries in Event Viewer first.

## NXLog `<Exec>` block — Windows Security channel example

```
<Exec>
    ## im_msvistalog populates structured fields directly — no parse function call needed.
    ## We map the NXLog-named fields onto SecurityEvent column names where they differ.

    if $EventID == undef { drop(); }

    $Computer       = $Hostname;
    $TimeGenerated  = $EventTime;
    $EventID        = $EventID;
    $Channel        = $Channel;
    $Task           = $Task;

    ## SecurityEvent-specific high-value columns (varies by EventID)
    $TargetUserName     = $TargetUserName;
    $TargetDomainName   = $TargetDomainName;
    $SubjectUserName    = $SubjectUserName;
    $SubjectDomainName  = $SubjectDomainName;
    $LogonType          = $LogonType;
    $IpAddress          = $IpAddress;
    $WorkstationName    = $WorkstationName;
    $NewProcessName     = $NewProcessName;
    $ParentProcessName  = $ParentProcessName;

    ## _CF enrichment
    $DeviceVendor_CF          = "Microsoft";
    $DeviceProduct_CF         = "Windows";
    $DatasourceName_CF        = "Microsoft_Windows_SecurityChannel";
    $DeviceAddress_CF         = $MessageSourceAddress;
    $RawLog_CF                = $raw_event;
    $NXLogInputModuleName_CF  = $SourceModuleName;
    $NXLogRouteName_CF        = "route_windows-security_azure";
    $NXLogServerName_CF       = hostname();

    delete($EventReceivedTime); delete($SourceModuleName);
    delete($SourceModuleType);  delete($EventTime);
    delete($Hostname);

    if get_var('aad_bearer_token') == undef {
        set_var('aad_bearer_token', file_read('%TOKEN_CACHE%'));
    }
    add_http_header('Authorization', 'Bearer ' + get_var('aad_bearer_token'));
    to_json();
</Exec>
```

For non-Security channels (System / Application / Sysmon / etc.) targeting `WindowsEvent`, the column mapping is simpler — just `Computer`, `Channel`, `EventID`, `EventData` — because `WindowsEvent` stores the bulk of the payload as XML in the `EventData` column.

## DCR `streamDeclarations` for Windows

For `SecurityEvent` target:
```json
"streamDeclarations": {
  "Custom-Microsoft-WindowsSecurity": {
    "columns": [
      { "name": "TimeGenerated",          "type": "datetime" },
      { "name": "Computer",               "type": "string"   },
      { "name": "EventID",                "type": "int"      },
      { "name": "Channel",                "type": "string"   },
      { "name": "Task",                   "type": "int"      },
      { "name": "Account",                "type": "string"   },
      { "name": "TargetUserName",         "type": "string"   },
      { "name": "TargetDomainName",       "type": "string"   },
      { "name": "SubjectUserName",        "type": "string"   },
      { "name": "SubjectDomainName",      "type": "string"   },
      { "name": "LogonType",              "type": "int"      },
      { "name": "IpAddress",              "type": "string"   },
      { "name": "WorkstationName",        "type": "string"   },
      { "name": "NewProcessName",         "type": "string"   },
      { "name": "ParentProcessName",      "type": "string"   },
      // ... 8 _CF columns
      { "name": "DeviceVendor_CF",        "type": "string"   },
      { "name": "DeviceProduct_CF",       "type": "string"   },
      { "name": "DatasourceName_CF",      "type": "string"   },
      { "name": "DeviceAddress_CF",       "type": "string"   },
      { "name": "RawLog_CF",              "type": "string"   },
      { "name": "NXLogInputModuleName_CF","type": "string"   },
      { "name": "NXLogRouteName_CF",      "type": "string"   },
      { "name": "NXLogServerName_CF",     "type": "string"   }
    ]
  }
}
```

`outputStream` = `Microsoft-SecurityEvent`. `transformKql` = `source` (no rename needed — `Computer` is already the right name).

## Stream-naming convention

| Channel | Stream key |
|---|---|
| Security | `Custom-Microsoft-WindowsSecurity` |
| System / Application (combined) | `Custom-Microsoft-WindowsSystem` |
| Sysmon | `Custom-Microsoft-Sysmon` |
| Defender | `Custom-Microsoft-Defender` |

## Parser style

The parser filters by `EventID` ranges to derive `EventCategory`. Common Security-channel mappings:

```kql
.create-or-alter function MicrosoftWindowsSecurityAudit(starttime:datetime = datetime(null),
                                                       endtime:datetime   = datetime(null)) {
let _start = iff(isnull(starttime), ago(1h), starttime);
let _end   = iff(isnull(endtime),   now(),    endtime);
//
SecurityEvent
| where TimeGenerated between (_start .. _end)
| where DeviceVendor_CF  == "Microsoft"
| where DeviceProduct_CF == "Windows"
//
| extend EventCategory = case(
    EventID == 4624,                                  "Authentication",        // successful logon
    EventID == 4625,                                  "AuthenticationFailed",  // failed logon
    EventID == 4634,                                  "Logoff",
    EventID == 4740,                                  "AccountLocked",
    EventID in (4720, 4722, 4724, 4738),              "UserManagement",
    EventID in (4727, 4728, 4729, 4730, 4754, 4756),  "GroupManagement",
    EventID == 4688,                                  "ProcessCreated",
    EventID == 4689,                                  "ProcessTerminated",
    EventID == 4663,                                  "FileAccessed",
    EventID in (4719, 4739, 4817, 4902, 4904),        "PolicyChanged",
    "Unknown"
)
//
| project
    TimeGenerated, Computer,
    EventID, EventCategory,
    TargetUserName, TargetDomainName,
    SubjectUserName, SubjectDomainName,
    LogonType, IpAddress, WorkstationName,
    NewProcessName, ParentProcessName,
    DeviceVendor_CF, DeviceProduct_CF, DatasourceName_CF,
    DeviceAddress_CF, NXLogInputModuleName_CF,
    NXLogRouteName_CF, NXLogServerName_CF, RawLog_CF
}
```

## File outputs

Same as `syslog-integration`. The bundle includes:
- `nxlog.conf` — Pattern W1 by default; commented-out alternative `im_wmi` block for Pattern W2
- `dcr-arm-template.json` — uses `Microsoft-SecurityEvent` or `Microsoft-WindowsEvent` outputStream
- `parser.kql` — `MicrosoftWindowsSecurityAudit` or `MicrosoftWindowsSystemAudit` etc.
- `validation-queries.kql` — VQ-01 through VQ-05
- `field-mapping.md`
- `integration-guide.html`

## Acceptance checks

Same as `syslog-integration`, plus:
- [ ] `im_msvistalog` has `SavePos TRUE` and `ReadFromLast TRUE`
- [ ] `<QueryXML>` is documented in field-mapping.md (which channels, which event IDs)
- [ ] `outputStream` matches the chosen channel (`Microsoft-SecurityEvent` for Security, `Microsoft-WindowsEvent` for others)
- [ ] If user wanted both Security and other channels, two separate bundles were generated
