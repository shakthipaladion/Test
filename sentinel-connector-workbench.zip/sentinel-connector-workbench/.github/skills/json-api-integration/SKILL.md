# Skill: JSON API Integration

This skill produces a bundle for vendors that emit JSON via a REST API — either pushing to an HTTP endpoint NXLog exposes (`im_http`) or NXLog pulling from the vendor's API on a schedule. Lands in a custom `<VendorProduct>_CL` table since no built-in fits, enriched with the eight `_CF` columns.

## Triggers

Activate this skill when the user mentions:
- A specific JSON-API vendor: CrowdStrike (Falcon Streaming), Zscaler (ZIA/ZPA NSS feed), Okta (System Log API), Duo (Admin API), Splunk Forwarder JSON
- Generic phrasing: "REST API", "JSON ingestion", "API pull", "webhook", "im_http push"

## Key decisions

### Push vs Pull

| Pattern | Vendor | NXLog input |
|---|---|---|
| **Push** — vendor sends to a URL we expose | CrowdStrike Falcon Streaming, webhook integrations | `im_http` listening on a TLS port |
| **Pull** — NXLog calls vendor API on schedule | Zscaler NSS feed, Okta System Log, Duo Admin API | `im_http` in client mode with `<Schedule>` |

If the vendor offers both, prefer **push** (lower latency, lower complexity, no missed events on schedule gaps).

### Custom table naming

Custom Log Analytics tables:
- Name pattern: `<Vendor><Product>_CL`
- Examples: `CrowdStrikeFalcon_CL`, `OktaSystemLog_CL`, `ZscalerInternetAccess_CL`
- The `_CL` suffix is required by Sentinel for custom tables.
- Stream key in DCR: `Custom-<Vendor>-<Product>` (workbench convention — same as syslog/CEF skills)
- `outputStream` in DCR: `Custom-<Vendor>-<Product>_CL` (Sentinel convention for direct-to-custom-table)

## Differences from syslog-integration

| Item | Syslog | JSON API |
|---|---|---|
| NXLog input | `im_udp` etc. | `im_http` (server mode for push, client mode for pull) |
| Parse function | `parse_syslog()` | (none — `xm_json` parses, NXLog produces structured fields) |
| Target table | Built-in `Syslog` | Custom `<Vendor><Product>_CL` |
| `outputStream` | `Microsoft-Syslog` | `Custom-<Vendor>-<Product>_CL` |
| Authentication to vendor | None (just receives syslog) | API key / OAuth — second credential set on the collector |
| Table provisioning | Automatic (built-in) | **Must be created in advance via DCR-API table provisioning** |

## NXLog `<Input>` for push pattern (vendor → NXLog)

```
<Input im_<vendor>_http_push>
    Module          im_http
    ListenAddr      0.0.0.0:8443
    HTTPSCertFile   %CERTDIR%/nxlog-receiver-cert.pem
    HTTPSCertKeyFile %CERTDIR%/nxlog-receiver-key.pem
    HTTPSCAFile     %CERTDIR%/<vendor>-ca.pem        ## Vendor's signing CA
    HTTPSAllowUntrusted FALSE
    <Exec>
        ## im_http delivers the body in $raw_event; xm_json parses it
        parse_json();
        ## After parse_json, all top-level JSON keys are NXLog field variables
    </Exec>
</Input>
```

Vendor-side configuration: vendor's webhook/streaming endpoint is set to `https://[nxlog-host]:8443/<vendor>-events` with the API key/secret in the `Authorization` header (vendor-specific header).

## NXLog `<Input>` for pull pattern (NXLog → vendor)

```
<Input im_<vendor>_http_pull>
    Module          im_http
    URL             https://api.<vendor>.com/v1/events
    HTTPSCAFile     %CERTDIR%/DigiCertGlobalRootCA.crt
    AddHeader       Authorization: Bearer [vendor-api-token]
    <Schedule>
        Every 60 sec
    </Schedule>
    <Exec>
        parse_json();
        ## Stateful pagination — track last-seen event ID
        if get_var('last_event_id') == undef {
            set_var('last_event_id', '');
        }
        ## ... vendor-specific cursor management ...
    </Exec>
</Input>
```

Stateful pagination is vendor-specific; check the vendor's API docs for the cursor field name (`since`, `next_token`, `cursor`, `start_time`).

## NXLog `<Output>` block

The `<Exec>` block is the same shape as syslog — `_CF` enrichment, token loading, `to_json()`. The only difference is the URL points to a custom-stream DCR:

```
URL  %DCE_ENDPOINT_PROD%/dataCollectionRules/%DCR_RULE_ID_PROD%/streams/Custom-<Vendor>-<Product>?api-version=2023-01-01
```

## DCR with a custom table

Custom tables in Log Analytics need to exist before the DCR can reference them. The workbench convention is to provision the table in the same ARM template:

```json
"resources": [
  {
    "type": "Microsoft.OperationalInsights/workspaces/tables",
    "apiVersion": "2022-10-01",
    "name": "[concat(split(parameters('workspaceResourceId'), '/')[8], '/<Vendor><Product>_CL')]",
    "properties": {
      "schema": {
        "name": "<Vendor><Product>_CL",
        "columns": [
          { "name": "TimeGenerated",            "type": "datetime" },
          { "name": "EventType",                "type": "string"   },
          { "name": "EventID",                  "type": "string"   },
          { "name": "User",                     "type": "string"   },
          { "name": "SourceIP",                 "type": "string"   },
          { "name": "Action",                   "type": "string"   },
          { "name": "Outcome",                  "type": "string"   },
          { "name": "RawData",                  "type": "dynamic"  },
          { "name": "DeviceVendor_CF",          "type": "string"   },
          { "name": "DeviceProduct_CF",         "type": "string"   },
          { "name": "DatasourceName_CF",        "type": "string"   },
          { "name": "DeviceAddress_CF",         "type": "string"   },
          { "name": "RawLog_CF",                "type": "string"   },
          { "name": "NXLogInputModuleName_CF",  "type": "string"   },
          { "name": "NXLogRouteName_CF",        "type": "string"   },
          { "name": "NXLogServerName_CF",       "type": "string"   }
        ]
      },
      "retentionInDays": 90
    }
  },
  {
    "type": "Microsoft.Insights/dataCollectionRules",
    /* ... DCR resource referencing the custom table ... */
  }
]
```

Column set is **vendor-specific** — design it from the JSON payload schema. Standard fields the workbench expects:
- Always: `TimeGenerated`, `RawData` (catch-all `dynamic`), and the 8 `_CF` columns
- Recommended: `EventType`, `EventID`, `User`, `SourceIP`, `Action`, `Outcome` for cross-vendor consistency
- Vendor-specific: anything else from the JSON payload that's queried regularly

`outputStream` in `dataFlows` is the custom-stream form: `"Custom-<Vendor>-<Product>_CL"`.

## API credential management

API keys/tokens for the vendor are **separate** from the Azure bearer token. Convention:
- `/opt/nxlog/cert/<vendor>_api.env` — sourced by NXLog or by an out-of-band refresh script
- File permissions: `640` root:nxlog
- Rotation: vendor-specific; document in the integration guide

If the vendor uses OAuth (Okta, CrowdStrike), an out-of-band refresh script similar to `refresh_azure_token.sh` is needed for the vendor's token. Document it alongside the Azure refresh script in `reference/`.

## Parser style

```kql
.create-or-alter function <Vendor><Product>Audit(starttime:datetime = datetime(null),
                                                 endtime:datetime   = datetime(null)) {
let _start = iff(isnull(starttime), ago(1h), starttime);
let _end   = iff(isnull(endtime),   now(),    endtime);
//
<Vendor><Product>_CL                      // <-- custom table directly
| where TimeGenerated between (_start .. _end)
| where DeviceVendor_CF  == "<Vendor>"
| where DeviceProduct_CF == "<Product>"
//
// Extract from JSON payload — RawData is dynamic
| extend
    EventType = tostring(RawData.event_type),
    User      = tostring(RawData.user_name),
    SourceIP  = tostring(RawData.source_ip)
//
| extend EventCategory = case(
    EventType == "user.session.start",                        "Authentication",
    EventType == "user.session.start.fail",                   "AuthenticationFailed",
    EventType in ("config.change", "policy.update"),          "ConfigurationChanged",
    "Unknown"
)
//
| project
    TimeGenerated, EventType, EventID, EventCategory,
    User, SourceIP, Action, Outcome,
    DeviceVendor_CF, DeviceProduct_CF, DatasourceName_CF,
    DeviceAddress_CF, NXLogInputModuleName_CF,
    NXLogRouteName_CF, NXLogServerName_CF, RawLog_CF
}
```

## Acceptance checks

Same as `syslog-integration`, plus:
- [ ] Custom table is provisioned in the ARM template (or user told to provision it separately first)
- [ ] Vendor API credential is stored in a separate env file with `640` perms
- [ ] If OAuth: refresh script and cron entry are documented (or referenced from `reference/Azure_Bearer_Token_Refresh.md` if reusing that pattern)
- [ ] Custom table column set matches what NXLog actually sends (no schema drift)
- [ ] `outputStream` in DCR is `Custom-<Vendor>-<Product>_CL` (custom-table form)
