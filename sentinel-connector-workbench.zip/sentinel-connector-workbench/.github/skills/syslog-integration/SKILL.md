# Skill: Syslog Integration

This skill is the **workbench default** — invoked whenever the user names a vendor that emits RFC 3164 / RFC 5424 syslog without CEF compliance. It produces a complete bundle landing in Sentinel's built-in `Syslog` table, enriched with the eight `_CF` columns.

When in doubt about which skill to use, start here. CEF is a positive identification, not a default.

## Triggers

Activate this skill when the user mentions any of:
- A specific vendor that emits RFC syslog: Ivanti, Pulse Secure, Connect Secure, Cisco IOS/NX-OS, Juniper Junos, Arista EOS, Aruba ArubaOS, F5 syslog (non-CEF mode), most appliance vendors
- Generic phrasing: "syslog", "RFC 3164", "RFC 5424", "UDP 514", "TCP 601", "TLS 6514", "syslog ingestion"
- Statements like "we get plain syslog from this device", "the device emits non-CEF syslog"

If the user says "CEF" or names a vendor known for CEF (Palo Alto, Fortinet, Check Point, F5 ASM, etc.), activate `cef-integration` instead.

## Inputs

Before producing output, ensure you have:

1. **Vendor display name** — `"Ivanti"`, `"Cisco"`, `"Juniper Networks"`, etc. (with spaces if applicable)
2. **Product display name** — `"Connect Secure"`, `"IOS"`, `"Junos OS"`
3. **Wire transport** — UDP/514, TCP/601, or TLS/6514. Most appliances default UDP; ask if unspecified.
4. **At least one sample log** — needed for parser regex extraction. If absent, ask before generating; do NOT guess wire format.
5. **Major event categories** — what does this device emit? (auth events, admin actions, network sessions, etc.)

If anything is missing, ask in **one** consolidated message — don't ask multiple times.

## Eight-phase workflow (mirrors the 8 document sections)

Each phase produces one section of the integration document AND one or more files in `outputs/<vendor>-<product>/`.

### Phase 1 — Device Configuration (Section 01)

Produce a written walkthrough of:
- Where on the device to configure syslog forwarding (admin UI navigation path)
- Which event categories / channels to enable
- Destination = the NXLog collector (`[collector-ip]:514`)
- Recommended logging level (typically info or higher; not debug)
- Time/timezone configuration so timestamps make sense in Sentinel

This is prose + small tables. No file output beyond the section content in `integration-guide.html`.

### Phase 2 — NXLog Configuration (Section 02 + `nxlog.conf`)

Substitute `templates/nxlog/syslog-input.conf` with these tokens:

| Token | Value example |
|---|---|
| `{{VENDOR}}` | `Ivanti` |
| `{{PRODUCT}}` | `Connect Secure` |
| `{{PRODUCT_NOSPACE}}` | `ConnectSecure` |
| `{{VENDOR_HYPHEN_LOWER}}` | `ivanti-connectsecure` |
| `{{STREAM_NAME}}` | `Custom-Ivanti-ConnectSecure` |
| `{{NXLOG_INPUT_MODULE}}` | `im_udp` (or `im_tcp` / `im_ssl`) |
| `{{NXLOG_PARSE_FN}}` | `parse_syslog` |
| `{{TRANSPORT_PORT}}` | `514` (UDP), `601` (TCP), `6514` (TLS) |
| `{{TARGET_TABLE_LITERAL}}` | `Syslog` |
| `{{DCE_ENDPOINT_PROD}}` | `[dce-prod-uae-endpoint]` |
| `{{DCE_ENDPOINT_DR}}` | `[dce-dr-ch-endpoint]` |
| `{{DCR_IMMUTABLE_ID_PROD}}` | `[dcr-immutable-id-prod]` |
| `{{DCR_IMMUTABLE_ID_DR}}` | `[dcr-immutable-id-dr]` |

Save to `outputs/<vendor-product>/nxlog.conf`. The HTML's Section 02 embeds this file inside a `<pre>` block.

The conf includes:
- `define ACTIVE_DESTINATION om_azure_prod_uae` (DR commented standby)
- One `<Input>` block (uncomment alternate transports as needed)
- TWO `<Output>` blocks (om_azure_prod_uae, om_azure_dr_ch) — both with full 8-phase Exec, Schedule, OnError
- ONE `<Route>` referencing `%ACTIVE_DESTINATION%`

Section 02 also includes the operational checks table from the HTML template (10 rows of system commands and expected results).

### Phase 3 — DCR ARM Template (Section 03 + `dcr-arm-template.json`)

Substitute `templates/dcr/syslog-dcr.json` parameters:
- `streamName` = `Custom-<Vendor>-<Product>` (PascalCase, no spaces)
- `datasourceName` = `NXLog-<Vendor>-<Product>` (matches `transformKql`)
- `dcrName` will be parameterised at deploy — pattern is `dcr-<vendor-kebab>-<product-kebab>-<region>`
- `deviceVendor` = display name (e.g., `"Ivanti"`)
- `deviceProduct` = display name (e.g., `"Connect Secure"`)

Save to `outputs/<vendor-product>/dcr-arm-template.json`. The HTML's Section 03 embeds the JSON, deployment commands (CLI + PowerShell), and the HTTP error troubleshooting callout from the HTML template.

Generate two example deployment commands (one per region):

```bash
# UAE prod
az deployment group create \
  --resource-group [uae-rg] \
  --template-file dcr-arm-template.json \
  --parameters deviceVendor="<Vendor>" \
               deviceProduct="<Product>" \
               streamName="Custom-<Vendor>-<Product>" \
               datasourceName="NXLog-<Vendor>-<Product>" \
               dcrName="dcr-<vendor-kebab>-<product-kebab>-prod-uae" \
               dataCollectionEndpointId="/subscriptions/[uae-sub-id]/.../dce-prod-uae" \
               workspaceResourceId="/subscriptions/[uae-sub-id]/.../[uae-workspace]" \
               location="uaenorth"

# CH DR
az deployment group create \
  --resource-group [ch-rg] \
  --template-file dcr-arm-template.json \
  --parameters [...same...] dcrName="dcr-<vendor-kebab>-<product-kebab>-dr-ch" \
               dataCollectionEndpointId="/subscriptions/[ch-sub-id]/.../dce-dr-ch" \
               workspaceResourceId="/subscriptions/[ch-sub-id]/.../[ch-workspace]" \
               location="switzerlandnorth"
```

Then `az role assignment create` for the NXLog SP, scoped to each DCR's resource ID.

### Phase 4 — Field Mapping (Section 04 + `field-mapping.md`)

Produce three tables:

**Table 1 — Native Syslog columns set by NXLog** (from the `<Exec>` block):
| Sentinel column | NXLog source |
|---|---|
| `Computer` | `$Hostname` |
| `HostName` | `$Hostname` (renamed via DCR `transformKql` → `Computer`) |
| `HostIP` | `$MessageSourceAddress` |
| `Facility` | `$SyslogFacility` |
| `SeverityLevel` | `$SyslogSeverity` |
| `SyslogMessage` | `$Message` |
| `ProcessName` | `$SourceName` |
| `ProcessID` | `$ProcessID` |

**Table 2 — `_CF` enrichment columns** — copy from `reference/Syslog_CF_Schema.md`. Always all 8.

**Table 3 — Parser-extracted analyst fields** — vendor-specific. From the parser's `extend` clauses, list each extracted field name, its type, and what it represents.

Save the combined three tables as `outputs/<vendor-product>/field-mapping.md`. The HTML's Section 04 embeds the same content.

### Phase 5 — Event Catalogue (Section 05)

For each "stream" (logical grouping of events from this vendor — Auth/UserAccess/AdminAccess/etc.), document:
- What sub-events appear in the syslog payload
- What each one means (in plain SOC English)
- Which extracted fields are populated for that sub-event
- SIEM relevance (informational, useful for triage, useful for detection)

Format: prose subsections, one per stream. No file output beyond Section 05 of the HTML.

### Phase 6 — Sample Logs (Section 06)

Embed sanitised wire-format samples — one per major event type — inside `<pre>` blocks in Section 06. Use IP `[device-ip]`, hostname `[device-hostname]`, username `[sample-user]`, etc. Real samples should be sanitised before embedding.

If samples are absent, ask the user to provide at least one per event type before generating the parser. The parser regex relies on real samples.

### Phase 7 — KQL Parser (Section 07 + `parser.kql`)

Build the parser by substituting `templates/kql/syslog-parser-template.kql`:

| Token | Notes |
|---|---|
| `{{PARSER_FUNCTION}}` | `<Vendor><Product>Audit` PascalCase concatenated |
| `{{VENDOR}}` | Display name |
| `{{PRODUCT}}` | Display name |
| `{{TARGET_TABLE}}` | `Syslog` |
| `{{ADDITIONAL_FILTERS}}` | Optional `where SyslogMessage has "<wire-tag>"` if vendor has a stable process name in messages |
| `{{FRAME_EXTRACTIONS}}` | Common-to-all-events extractions (e.g., appliance hostname, node ID, source IP from frame envelope) |
| `{{STREAM_ROUTING}}` | `extend Stream = case(...)` deriving logical stream from event-text shape |
| `{{STREAM_FIELD_EXTRACTIONS}}` | Per-stream `extend` clauses extracting analyst fields |
| `{{EVENT_CATEGORY_DERIVATION}}` | ASIM `EventCategory = case(...)` mapping |
| `{{ANALYST_FIELDS}}` | Comma-separated list of extracted field names for the final `project` |

**Validation gate (Rule 10):**
1. Inline the function body as `<body> | take 10`
2. Run via Sentinel Triage MCP `RunAdvancedHuntingQuery` against the UAE prod workspace
3. On success: annotate `// VALIDATED <YYYY-MM-DD>`, save file
4. On failure: report the error, do NOT save
5. If MCP unavailable or source not yet onboarded: save with `// VALIDATION SKIPPED — REASON: <reason>` and tell the user explicitly

The HTML's Section 07 embeds the parser body and shows the function signature.

### Phase 8 — Validation Queries (Section 08 + `validation-queries.kql`)

Generate exactly five queries — `VQ-01` through `VQ-05`:

**VQ-01 — Event coverage by stream:** Counts events grouped by logical stream + event category over the last hour.

```kql
<Vendor><Product>Audit(ago(1h), now())
| summarize EventCount = count() by Stream, EventCategory
| order by EventCount desc
```

**VQ-02 — Appliance heartbeat:** Last event time per appliance, flagging any silent ones.

```kql
<Vendor><Product>Audit(ago(2h), now())
| summarize LastEvent = max(TimeGenerated), EventCount = count() by ApplianceHost = Computer, DeviceAddress_CF
| extend MinutesSinceLastEvent = datetime_diff('minute', now(), LastEvent)
| extend Status = iff(MinutesSinceLastEvent > 10, 'STALE', 'HEALTHY')
| order by Status desc, MinutesSinceLastEvent desc
```

**VQ-03 — Primary-data-content query:** The most useful single query for the dominant event type — typically authentication for VPN/firewall, configuration changes for management plane, etc. Returns recent events with key extracted fields.

**VQ-04 — Parser coverage:** What percent of events the parser successfully categorises (i.e., `EventCategory != "Unknown"`).

```kql
<Vendor><Product>Audit(ago(24h), now())
| summarize Total = count(), Mapped = countif(EventCategory != "Unknown")
| extend CoveragePercent = round(100.0 * Mapped / Total, 2)
```

**VQ-05 — Top failure sources:** Top source IPs / users / hosts producing failed events (auth fails, denies, errors). Useful for both triage (is the device under attack?) and tuning (is one host generating noise?).

Save all five to `outputs/<vendor-product>/validation-queries.kql` with `// VQ-NN — <description>` headers separating each. The HTML's Section 08 embeds them in `<pre>` blocks.

## Integration Guide HTML Generation

After Phases 1-8 produce content, substitute `templates/html/starter.html` with everything. Save to `outputs/<vendor-product>/integration-guide.html`.

Token substitution map for the HTML:

| Token | Source |
|---|---|
| `{{VENDOR}}` `{{PRODUCT}}` | Phase 1 inputs |
| `{{VERSION_RANGE}}` | What firmware versions this integration supports — from user input or "Multiple firmware versions" |
| `{{HEADER_DESC_BODY}}` | One-paragraph summary of what events this collects (e.g., "user authentication, web access, and administrative changes") |
| `{{LOG_FORMAT}}` | `Syslog` |
| `{{TRANSPORT}}` | `UDP/514` etc. |
| `{{TARGET_TABLE}}` | `Syslog` |
| `{{TARGET_TABLE_DESC}}` | `Native Sentinel table` |
| `{{STREAM_NAME}}` | `Custom-<Vendor>-<Product>` |
| `{{OUTPUT_STREAM}}` | `Microsoft-Syslog` |
| `{{PARSER_FUNCTION}}` | `<Vendor><Product>Audit` |
| `{{NXLOG_INPUT_MODULE}}` | `im_udp` / `im_tcp` / `im_ssl` |
| `{{NXLOG_PARSE_FN}}` | `parse_syslog` |
| `{{DOC_VERSION}}` | `1.0` (initial) |
| `{{VALIDATED_DATE}}` | Today's date in `YYYY-MM-DD` |
| `{{VALIDATION_STATUS}}` | `VALIDATED` or `SKIPPED — <reason>` from Phase 7 gate |
| `{{SECTION_01..08}}` | Content from each phase above |

## File outputs

Required files in `outputs/<vendor-product>/`:

```
nxlog.conf                  ← Phase 2
dcr-arm-template.json       ← Phase 3
field-mapping.md            ← Phase 4
parser.kql                  ← Phase 7 (after validation gate)
validation-queries.kql      ← Phase 8
integration-guide.html      ← All phases assembled
```

Optional: `integration-guide.docx` if user explicitly requests Word format.

## Final acceptance checks

Before declaring complete, verify:
- [ ] All six required files exist
- [ ] No real IPs, hostnames, credentials anywhere
- [ ] DCR JSON parses (`python3 -c 'import json; json.load(open("dcr-arm-template.json"))'`)
- [ ] Parser annotated with `// VALIDATED <date>` OR explicit user notification of skip
- [ ] All five VQ-NN queries defined
- [ ] HTML opens in a browser with no broken styling
- [ ] All 8 sections populated (no `{{...}}` tokens left unsubstituted)

If any check fails, fix it before responding to the user.

## Worked example

`outputs/ivanti-connect-secure/` is a complete worked example using this skill. Reference its structure, tone, and content depth when generating new integrations.
