<#
.SYNOPSIS
    Deploy a generated DCR ARM template to both UAE prod and CH DR Sentinel workspaces.

.DESCRIPTION
    Reads config.json for tenant/region settings, then runs `az deployment group create`
    twice — once per region. Same ARM template, different parameters per region.

    After deployment, assigns 'Monitoring Metrics Publisher' role to the NXLog SP on
    each DCR resource. Reports the resulting DCR immutable ID and DCE ingestion endpoint
    for each region — these are the values to substitute into the per-collector nxlog.conf.

.PARAMETER BundlePath
    Path to outputs/<vendor-product>/. Required.

.PARAMETER Region
    'prod' | 'dr' | 'both' (default: 'both'). Set to a single region when redeploying.

.EXAMPLE
    .\deploy_dcr.ps1 -BundlePath outputs\ivanti-connect-secure
    .\deploy_dcr.ps1 -BundlePath outputs\palo-alto-pan-os -Region prod

.NOTES
    Requires:
      - Azure CLI (az) authenticated and able to deploy to both RGs
      - The deploying principal needs 'Monitoring Contributor' on both RGs
      - config.json present at repo root
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$BundlePath,

    [Parameter(Mandatory=$false)]
    [ValidateSet('prod', 'dr', 'both')]
    [string]$Region = 'both'
)

$ErrorActionPreference = 'Stop'

# ── Resolve paths ─────────────────────────────────────────────────────────
$repoRoot   = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$configPath = Join-Path $repoRoot 'config.json'
$templatePath = Join-Path $BundlePath 'dcr-arm-template.json'

if (-not (Test-Path $configPath)) {
    throw "config.json not found at $configPath. Copy config.json.template to config.json and fill in tenant details first."
}

if (-not (Test-Path $templatePath)) {
    throw "dcr-arm-template.json not found at $templatePath. Generate the bundle first."
}

$config = Get-Content $configPath -Raw | ConvertFrom-Json

# ── Derive vendor / product / stream from bundle directory name ──────────
$bundleName = Split-Path $BundlePath -Leaf
# Convention: outputs/<vendor-kebab>-<product-kebab>/
# Extract vendor and product portions for naming the DCR resource and the stream.
# This is best-effort — the user may want to override; ask if ambiguous.

Write-Host "=== Deploy DCR for bundle: $bundleName ===" -ForegroundColor Cyan
Write-Host "Template:    $templatePath" -ForegroundColor DarkGray
Write-Host "Region(s):   $Region" -ForegroundColor DarkGray

# Read a few values from the ARM template parameters defaults to construct deploy names
$template = Get-Content $templatePath -Raw | ConvertFrom-Json

# Prompt for parameters not set in config — these come from the bundle
$deviceVendor   = Read-Host "DeviceVendor    (PascalCase, e.g. Ivanti)"
$deviceProduct  = Read-Host "DeviceProduct   (PascalCase, e.g. ConnectSecure)"
$streamName     = "Custom-$deviceVendor-$deviceProduct"
$datasourceName = "NXLog-$deviceVendor-$deviceProduct"

Write-Host ""
Write-Host "Stream name:    $streamName"
Write-Host "Datasource:     $datasourceName"
Write-Host ""

# ── Build the per-region deployment closures ─────────────────────────────
$regions = @{}

if ($Region -in @('prod', 'both')) {
    $regions['prod'] = @{
        Label             = $config.tenants.prod.label
        SubscriptionId    = $config.tenants.prod.subscription_id
        ResourceGroup     = $config.tenants.prod.resource_group
        Location          = $config.tenants.prod.location
        WorkspaceId       = $config.tenants.prod.workspace_resource_id
        DceResourceId     = $config.tenants.prod.dce_resource_id
        DcrName           = "dcr-$bundleName-prod-uae"
    }
}

if ($Region -in @('dr', 'both')) {
    $regions['dr'] = @{
        Label             = $config.tenants.dr.label
        SubscriptionId    = $config.tenants.dr.subscription_id
        ResourceGroup     = $config.tenants.dr.resource_group
        Location          = $config.tenants.dr.location
        WorkspaceId       = $config.tenants.dr.workspace_resource_id
        DceResourceId     = $config.tenants.dr.dce_resource_id
        DcrName           = "dcr-$bundleName-dr-ch"
    }
}

# ── Deploy each region ────────────────────────────────────────────────────
$deployResults = @{}

foreach ($r in $regions.Keys) {
    $reg = $regions[$r]

    Write-Host ""
    Write-Host "─── Deploying to $($reg.Label) ───────────────────" -ForegroundColor Yellow
    Write-Host "  Subscription: $($reg.SubscriptionId)"
    Write-Host "  RG:           $($reg.ResourceGroup)"
    Write-Host "  DCR name:     $($reg.DcrName)"

    az account set --subscription $reg.SubscriptionId | Out-Null

    $deployOutput = az deployment group create `
        --resource-group $reg.ResourceGroup `
        --template-file $templatePath `
        --parameters `
            deviceVendor="$deviceVendor" `
            deviceProduct="$deviceProduct" `
            streamName="$streamName" `
            datasourceName="$datasourceName" `
            dcrName="$($reg.DcrName)" `
            dataCollectionEndpointId="$($reg.DceResourceId)" `
            workspaceResourceId="$($reg.WorkspaceId)" `
            location="$($reg.Location)" `
        --output json | ConvertFrom-Json

    if ($LASTEXITCODE -ne 0) {
        Write-Host "  ✗ Deployment failed for $($reg.Label)" -ForegroundColor Red
        continue
    }

    $dcrResourceId   = $deployOutput.properties.outputs.dcrResourceId.value
    $dcrImmutableId  = $deployOutput.properties.outputs.dcrImmutableId.value
    $dceEndpoint     = $deployOutput.properties.outputs.dceIngestionEndpoint.value

    Write-Host "  ✓ Deployed" -ForegroundColor Green
    Write-Host "    DCR resource ID:   $dcrResourceId"
    Write-Host "    DCR immutable ID:  $dcrImmutableId"
    Write-Host "    DCE endpoint:      $dceEndpoint"

    $deployResults[$r] = @{
        DcrResourceId   = $dcrResourceId
        DcrImmutableId  = $dcrImmutableId
        DceEndpoint     = $dceEndpoint
    }

    # ── Assign Monitoring Metrics Publisher on the DCR ───────────────
    $spObjectId = az ad sp show --id $config.tenants.service_principal.client_id --query id -o tsv
    if ([string]::IsNullOrEmpty($spObjectId)) {
        Write-Host "  ⚠ Could not find SP $($config.tenants.service_principal.client_id) — skipping role assignment" -ForegroundColor Yellow
    }
    else {
        az role assignment create `
            --assignee-object-id $spObjectId `
            --assignee-principal-type ServicePrincipal `
            --role "Monitoring Metrics Publisher" `
            --scope $dcrResourceId | Out-Null

        if ($LASTEXITCODE -eq 0) {
            Write-Host "  ✓ Role assigned to NXLog SP" -ForegroundColor Green
        } else {
            Write-Host "  ⚠ Role assignment failed (may already exist)" -ForegroundColor Yellow
        }
    }
}

# ── Summary — what to put in nxlog.conf ──────────────────────────────────
Write-Host ""
Write-Host "═══ NXLog config substitutions ═══" -ForegroundColor Cyan
Write-Host ""
Write-Host "Edit outputs/$bundleName/nxlog.conf and substitute:"
Write-Host ""

if ($deployResults.ContainsKey('prod')) {
    Write-Host "  {{DCE_ENDPOINT_PROD}}      = $($deployResults['prod'].DceEndpoint)"
    Write-Host "  {{DCR_IMMUTABLE_ID_PROD}}  = $($deployResults['prod'].DcrImmutableId)"
}
if ($deployResults.ContainsKey('dr')) {
    Write-Host "  {{DCE_ENDPOINT_DR}}        = $($deployResults['dr'].DceEndpoint)"
    Write-Host "  {{DCR_IMMUTABLE_ID_DR}}    = $($deployResults['dr'].DcrImmutableId)"
}

Write-Host ""
Write-Host "Then deploy nxlog.conf to each collector and: sudo systemctl reload nxlog"
Write-Host ""
