#!/usr/bin/env python3
"""
validate_dcr.py — Sentinel Connector Workbench DCR template validator.

Checks that a generated DCR ARM template matches the workbench's house
standards. Run as part of the validation gate before declaring a bundle
complete.

Usage:
    python3 scripts/validate_dcr.py outputs/<vendor>/dcr-arm-template.json

Exit codes:
    0 = valid
    1 = one or more failures
    2 = file not found / parse error

Checks performed:
    1. JSON parses
    2. ARM template has the required top-level structure
    3. streamDeclarations key matches Custom-<Vendor>-<Product> pattern
    4. All 8 _CF columns are declared
    5. transformKql renames HostName -> Computer (or DeviceName for CEF)
    6. outputStream is a built-in Microsoft-* stream OR a Custom-*_CL stream
    7. Required parameters are present
    8. Required outputs are present
"""

import json
import re
import sys
from pathlib import Path
from typing import Any

# ── Workbench standards ─────────────────────────────────────────────────

REQUIRED_CF_COLUMNS = {
    "DeviceVendor_CF",
    "DeviceProduct_CF",
    "DatasourceName_CF",
    "DeviceAddress_CF",
    "RawLog_CF",
    "NXLogInputModuleName_CF",
    "NXLogRouteName_CF",
    "NXLogServerName_CF",
}

VALID_OUTPUT_STREAMS_BUILTIN = {
    "Microsoft-Syslog",
    "Microsoft-CommonSecurityLog",
    "Microsoft-SecurityEvent",
    "Microsoft-WindowsEvent",
}

REQUIRED_PARAMETERS = {
    "deviceVendor",
    "deviceProduct",
    "streamName",
    "datasourceName",
    "dcrName",
    "dataCollectionEndpointId",
    "workspaceResourceId",
    "location",
}

REQUIRED_OUTPUTS = {
    "dcrName",
    "dcrResourceId",
    "dcrImmutableId",
}

STREAM_NAME_PATTERN = re.compile(r"^Custom-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)+$")
CUSTOM_TABLE_STREAM = re.compile(r"^Custom-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)+_CL$")

# ── Validation ────────────────────────────────────────────────────────────


class ValidationResult:
    def __init__(self):
        self.failures: list[str] = []
        self.warnings: list[str] = []
        self.passed_count = 0

    def fail(self, msg: str) -> None:
        self.failures.append(msg)

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)

    def pass_(self, _msg: str) -> None:
        self.passed_count += 1


def validate(template: dict[str, Any]) -> ValidationResult:
    r = ValidationResult()

    # 1. Top-level structure
    if "$schema" not in template:
        r.fail("Missing top-level '$schema'")
    else:
        r.pass_("Has $schema")

    if "resources" not in template or not isinstance(template["resources"], list):
        r.fail("Missing or invalid 'resources' array")
        return r
    r.pass_("Has resources array")

    # Find the DCR resource
    dcr = next(
        (
            res
            for res in template["resources"]
            if res.get("type") == "Microsoft.Insights/dataCollectionRules"
        ),
        None,
    )
    if dcr is None:
        r.fail("No Microsoft.Insights/dataCollectionRules resource found")
        return r
    r.pass_("Has a DCR resource")

    props = dcr.get("properties", {})

    # 2. streamDeclarations
    stream_decls = props.get("streamDeclarations", {})
    if not stream_decls:
        r.fail("DCR has no streamDeclarations")
        return r
    if len(stream_decls) > 1:
        r.warn(f"Multiple stream declarations ({len(stream_decls)}) — usually one per DCR")

    for stream_key, stream_def in stream_decls.items():
        # Stream key may be a literal "Custom-..." or an ARM expression
        # "[parameters('streamName')]" — both are acceptable.
        if stream_key.startswith("[parameters("):
            r.pass_(f"Stream key uses parameter reference: {stream_key}")
        elif STREAM_NAME_PATTERN.match(stream_key) or CUSTOM_TABLE_STREAM.match(stream_key):
            r.pass_(f"Stream key matches Custom-<Vendor>-<Product> pattern: {stream_key}")
        else:
            r.fail(
                f"Stream key '{stream_key}' doesn't match the workbench pattern "
                "Custom-<Vendor>-<Product> (PascalCase, single hyphens)"
            )

        # Columns
        cols = stream_def.get("columns", [])
        col_names = {c["name"] for c in cols if isinstance(c, dict) and "name" in c}

        # 3. Eight _CF columns must all be present
        missing_cf = REQUIRED_CF_COLUMNS - col_names
        if missing_cf:
            r.fail(f"Missing required _CF columns: {sorted(missing_cf)}")
        else:
            r.pass_("All 8 _CF columns declared")

        # 4. TimeGenerated must be present
        if "TimeGenerated" not in col_names:
            r.fail("Missing TimeGenerated column")
        else:
            r.pass_("Has TimeGenerated")

    # 5. dataFlows
    data_flows = props.get("dataFlows", [])
    if not data_flows:
        r.fail("DCR has no dataFlows")
        return r

    for flow in data_flows:
        # outputStream
        out_stream = flow.get("outputStream", "")
        if (
            out_stream in VALID_OUTPUT_STREAMS_BUILTIN
            or CUSTOM_TABLE_STREAM.match(out_stream)
        ):
            r.pass_(f"outputStream is valid: {out_stream}")
        else:
            r.fail(
                f"outputStream '{out_stream}' must be one of "
                f"{sorted(VALID_OUTPUT_STREAMS_BUILTIN)} or Custom-...-_CL"
            )

        # transformKql
        transform = flow.get("transformKql", "")
        if "extend Computer" not in transform and "extend SourceSystem" not in transform:
            r.warn(
                "transformKql doesn't appear to set Computer/SourceSystem — "
                "is this intentional?"
            )
        else:
            r.pass_("transformKql sets Computer/SourceSystem")

    # 6. Required parameters
    params = template.get("parameters", {})
    missing_params = REQUIRED_PARAMETERS - set(params.keys())
    if missing_params:
        r.fail(f"Missing required parameters: {sorted(missing_params)}")
    else:
        r.pass_("All required parameters declared")

    # 7. Required outputs
    outputs = template.get("outputs", {})
    missing_outputs = REQUIRED_OUTPUTS - set(outputs.keys())
    if missing_outputs:
        r.fail(f"Missing required outputs: {sorted(missing_outputs)}")
    else:
        r.pass_("All required outputs declared")

    return r


def main() -> int:
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <path-to-dcr-arm-template.json>", file=sys.stderr)
        return 2

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"ERROR: file not found: {path}", file=sys.stderr)
        return 2

    try:
        with path.open() as f:
            template = json.load(f)
    except json.JSONDecodeError as e:
        print(f"ERROR: JSON parse failed: {e}", file=sys.stderr)
        return 2

    result = validate(template)

    print(f"=== DCR validation: {path} ===")
    print(f"Checks passed:  {result.passed_count}")
    print(f"Warnings:       {len(result.warnings)}")
    print(f"Failures:       {len(result.failures)}")

    if result.warnings:
        print("\nWarnings:")
        for w in result.warnings:
            print(f"  ⚠ {w}")

    if result.failures:
        print("\nFailures:")
        for f in result.failures:
            print(f"  ✗ {f}")
        return 1

    print("\n✓ All workbench standards passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
