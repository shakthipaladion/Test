#!/bin/bash
# ════════════════════════════════════════════════════════════════════════════
# refresh_azure_token.sh
# ────────────────────────────────────────────────────────────────────────────
# Refresh Azure AD bearer token for NXLog om_http ingestion to the DCE.
# Runs every 25 minutes via /etc/cron.d/azure-token-refresh.
#
# Token lifetime is ~60 minutes; the 25-minute interval gives 35 minutes
# of headroom before expiry. NXLog reads the cache file via <Schedule>
# every 60 seconds, so a freshly refreshed token reaches the in-memory
# variable inside 60 seconds of cron run.
#
# Architecture notes:
#   • OAuth call routes via the corporate HTTP proxy (--proxy flag).
#   • DCE ingest from NXLog routes direct via ExpressRoute (no proxy).
#   • One Entra tenant, one app registration. The same token works for
#     both UAE and CH DCRs because the same SP has Monitoring Metrics
#     Publisher on both DCRs.
#
# Reference: reference/Azure_Bearer_Token_Refresh.md (in the workbench repo)
# ════════════════════════════════════════════════════════════════════════════

set -uo pipefail

# ── Source credentials from the env file ────────────────────────────────────
CRED_FILE="/opt/nxlog/cert/azure_sp.env"

if [ ! -r "$CRED_FILE" ]; then
    echo "$(date -Is) ERROR: cannot read credentials file $CRED_FILE" >&2
    exit 1
fi

# shellcheck disable=SC1090
source "$CRED_FILE"

# Validate required variables are set
: "${TENANT_ID:?TENANT_ID not set in $CRED_FILE}"
: "${CLIENT_ID:?CLIENT_ID not set in $CRED_FILE}"
: "${CLIENT_SECRET:?CLIENT_SECRET not set in $CRED_FILE}"

# ── Paths and config ──────────────────────────────────────────────────────
TOKEN_CACHE="/opt/nxlog/cert/azure_bearer_token.cache"
TOKEN_CACHE_TMP="${TOKEN_CACHE}.tmp"
HTTP_PROXY_URL="${HTTP_PROXY_URL:-http://[corp-proxy-host]:[corp-proxy-port]}"
LOG="/var/log/nxlog/token_refresh.log"

# Ensure log directory exists
mkdir -p "$(dirname "$LOG")"

# ── OAuth call routed via corporate proxy ─────────────────────────────────
# scope=https://monitor.azure.com/.default is the audience that DCEs accept.
# grant_type=client_credentials is the standard SP flow.
RESPONSE=$(curl --silent --fail --max-time 30 \
    --proxy "${HTTP_PROXY_URL}" \
    -X POST "https://login.microsoftonline.com/${TENANT_ID}/oauth2/v2.0/token" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&scope=https%3A%2F%2Fmonitor.azure.com%2F.default&grant_type=client_credentials" 2>&1)

CURL_RC=$?

if [ $CURL_RC -ne 0 ] || [ -z "$RESPONSE" ]; then
    echo "$(date -Is) ERROR: token refresh failed (curl rc=$CURL_RC, response=${RESPONSE:0:200})" >> "$LOG"
    exit 1
fi

# ── Parse token from JSON response ────────────────────────────────────────
TOKEN=$(echo "$RESPONSE" | jq -r '.access_token // empty')

if [ -z "$TOKEN" ] || [ "$TOKEN" == "null" ]; then
    echo "$(date -Is) ERROR: empty/null access_token in response: ${RESPONSE:0:300}" >> "$LOG"
    exit 1
fi

# ── Atomic write — NXLog reads this cache file every 60 sec; we must not
#    let it ever read a partial/truncated token ────────────────────────────
echo -n "$TOKEN" > "$TOKEN_CACHE_TMP"
chmod 600 "$TOKEN_CACHE_TMP"
chown nxlog:nxlog "$TOKEN_CACHE_TMP" 2>/dev/null || true
mv -f "$TOKEN_CACHE_TMP" "$TOKEN_CACHE"

# ── Success log entry ────────────────────────────────────────────────────
echo "$(date -Is) OK: token refreshed (length=${#TOKEN})" >> "$LOG"

# Truncate log if it grows beyond 10 MB
if [ -f "$LOG" ] && [ "$(stat -c%s "$LOG" 2>/dev/null || echo 0)" -gt 10485760 ]; then
    tail -1000 "$LOG" > "${LOG}.tmp" && mv "${LOG}.tmp" "$LOG"
fi

exit 0
