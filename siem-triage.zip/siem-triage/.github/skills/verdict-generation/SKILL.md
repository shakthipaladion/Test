---
description: Assemble the final verdict JSON + markdown report and write it to disk.
triggers: ["produce verdict", "summarize findings", end of any triage workflow]
---

# Verdict Generation

Use this skill at the end of every triage workflow. It owns the final
output format and the file writes.

## Verdict JSON schema

```json
{
  "incidentId": "string (or 'standalone-user-<upn>' / 'standalone-ioc-<value>')",
  "skill": "incident-triage | user-investigation | ioc-investigation",
  "timestamp": "ISO 8601 UTC",
  "classification": "TruePositive | FalsePositive | Benign | Inconclusive",
  "confidence": 0.0,
  "summary": "one sentence",
  "evidence": [
    {
      "claim": "specific factual statement with numbers, timestamps, or named entities",
      "source": "tool_name or queries/<path>.kql",
      "data": "the raw datum supporting the claim — quoted KQL row, API field, etc."
    }
  ],
  "entitiesInvestigated": {
    "users": ["upn@domain"],
    "ips": ["1.2.3.4"],
    "hosts": ["HOSTNAME"],
    "hashes": ["abc123..."],
    "domains": ["evil.example.com"]
  },
  "kqlRun": [
    {"query": "<kql>", "source": "queries/<path>.kql or ad-hoc", "rowCount": 0}
  ],
  "deepDivePlan": [
    "one step per array element"
  ],
  "recommendedActions": [
    "advisory only — for the human analyst to execute"
  ],
  "handoffState": "awaiting_decision"
}
```

## Hard rules

1. **`confidence < 0.85` ⇒ `classification = "Inconclusive"`.** No exceptions.
2. **Every `evidence[].claim` must have a `source` that is a tool you
   actually called.** If you find yourself wanting to write evidence with
   no source, that's a signal you're guessing — remove it.
3. **`evidence` must have at least 1 entry for any non-Inconclusive verdict.**
4. **`recommendedActions` are advisory, framed as recommendations.**
   ✅ "Recommend isolating host `WS-042` pending forensic acquisition."
   ❌ "Isolate WS-042."
5. **`handoffState` is always `"awaiting_decision"`.** The agent never
   sets it to anything else.

## Output procedure

1. **Emit the JSON** as a fenced ```json``` code block in the chat.
2. **Write the JSON** to `temp/triage-<incidentId>.json`.
3. **Write a markdown report** to `reports/<skill>/<incidentId>.md` using
   the template below.
4. **End the chat reply** with a 2–3 sentence prose summary and an explicit
   handoff line:
   > "Verdict ready at `reports/<skill>/<incidentId>.md`. Awaiting your
   > decision: close, proceed deep dive, or escalate."

## Markdown report template

```markdown
# Triage Verdict — <incidentId>

**Classification:** <classification> · **Confidence:** <0.00>
**Skill:** <skill> · **Timestamp:** <ISO 8601 UTC>

## Summary

<one-sentence verdict>

## Evidence

| # | Claim | Source |
|---|-------|--------|
| 1 | <claim> | <source> |
| 2 | ... | ... |

## Entities Investigated

- Users: <list>
- IPs: <list>
- Hosts: <list>
- Hashes: <list>
- Domains: <list>

## KQL Queries Run

| # | Source | Rows |
|---|--------|------|
| 1 | <queries/path.kql or ad-hoc> | <n> |

## Deep-Dive Plan

1. <step>
2. <step>

## Recommended Actions (advisory — for human execution)

- <action>
- <action>

---
*Handoff state: awaiting_decision. The agent did not take any response action.*
```

## When you cannot produce a verdict

If a critical tool failed (e.g., the SP can't authenticate, the workspace
is unreachable), do not produce a verdict. Instead:

1. Tell the user which tool failed and the error message.
2. Suggest concrete remediation (e.g., "check `AZURE_CLIENT_SECRET`
   hasn't expired", "verify SP has `Log Analytics Reader` on the workspace").
3. Do not write a partial report. Do not invent evidence to fill gaps.
