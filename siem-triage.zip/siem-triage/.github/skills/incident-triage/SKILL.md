---
description: Tier-1 triage for Sentinel and Defender XDR incidents — pull, enrich, hunt, verdict.
triggers: ["triage incident", "investigate incident", "analyze incident", incident ID or GUID]
---

# Incident Triage

Use this skill when the user gives you an incident ID (Sentinel or Defender
XDR) and wants a verdict.

## Workflow

### 1. Pull the incident
Call `get_incident` with the ID. Read the alerts and entities. Note:
- Incident **severity** and **status**
- Number of **alerts** and their **products** (Sentinel vs Defender XDR)
- Entity types present (users, hosts, IPs, hashes, files, processes, URLs)
- Incident **createdDateTime** — anchor for all hunt time windows

State to the user in one line what kind of incident this is and how many
entities you'll investigate. Example:
> "Sentinel incident with 2 alerts and 4 entities: 1 user, 1 host, 2 IPs.
> Starting enrichment."

### 2. Enrich entities
For each entity, dispatch to the right enrichment tool:

| Entity | Tools to call |
|---|---|
| User (UPN) | `get_risky_user`, `get_user_auth_methods` |
| IP address | `enrich_ip` (covers VT + AbuseIPDB + GreyNoise) |
| File hash | `enrich_hash` |
| Domain | `enrich_domain` |
| Host | (no enrichment; pivot via KQL in step 3) |

Skip enrichment that returns `{"skipped": "no key"}` and note the gap.

### 3. Run targeted KQL hunts
Pivot on the incident's entities and time window. **Search `queries/` first**
with grep before authoring new KQL — see the KQL pre-flight checklist in
`.github/copilot-instructions.md`.

Typical hunts for a triage:
- **Sign-in pattern for the user**: was the success preceded by failures?
  did MFA fire? from where? (`queries/identity/`)
- **IP activity across the tenant**: is this IP touching other users? other
  hosts? (`queries/network/`)
- **Host process activity around the alert time**: parent/child chains,
  network callouts, file writes. (`queries/endpoint/`)
- **Cross-product correlation**: any other alerts in the last 24h
  referencing the same entities?

Use the incident `createdDateTime` ± 2 hours as the default hunt window
unless the alert's own timestamp suggests otherwise.

### 4. Decide classification
Map evidence to one of:

| Classification | When |
|---|---|
| **TruePositive** | Confirmed malicious activity. Evidence is consistent with the alert and rules out benign explanations. |
| **FalsePositive** | The triggering condition occurred but the cause is benign and proven (e.g., self-service password reset between failed sign-ins). |
| **Benign** | Expected behavior misclassified by the rule (e.g., a sanctioned admin running PowerShell flagged as suspicious). |
| **Inconclusive** | Evidence is incomplete or contradictory. Set confidence < 0.85. List missing data in `deepDivePlan`. |

Confidence is your honest read on the evidence:
- **0.95–0.99**: multiple independent signals all aligned
- **0.85–0.94**: one strong signal, no contradicting evidence
- **< 0.85**: must be `Inconclusive`

### 5. Produce the verdict
Hand off to the `verdict-generation` skill. It owns the JSON shape and the
file output to `reports/incident-triage/<id>.md`.

## Worked example (false positive)

User says: "Triage incident inc-001-failed-signins."

1. `get_incident("inc-001-failed-signins")` → 1 alert "Multiple failed
   sign-ins followed by success", 1 user entity `alice@contoso.com`, 1 IP
   `203.0.113.42`.
2. `get_risky_user("alice@contoso.com")` → riskLevel=low, no active risk.
   `get_user_auth_methods` → 3 methods (Authenticator, SMS, password).
3. `enrich_ip("203.0.113.42")` → VT clean, AbuseIPDB score 0, GreyNoise
   benign (known corporate VPN egress).
4. Grep `queries/identity/` → find `signin-failures-then-success.kql`. Run
   it with `targetUPN=alice@contoso.com`, window 2h.
5. Result: 8 failures 14:28–14:30 UTC, success at 14:30:08. **Also** find
   an `AuditLogs` row at 14:29:45: "Self-service password reset completed"
   for the same user.
6. Classification: `FalsePositive`, confidence 0.96. The failures were
   pre-reset, the success was post-reset, same legitimate user, same VPN
   IP, MFA on file.

## Common false-positive patterns to recognize

- Failed sign-ins resolved by a self-service password reset (`AuditLogs`)
- Failed sign-ins from a known corporate VPN egress IP
- "Impossible travel" alerts where one leg is a mobile carrier NAT
- Process anomalies from a sanctioned admin in a maintenance window

## Common true-positive escalation triggers

- Successful sign-in from a known-bad IP (VT/AbuseIPDB/GreyNoise positive)
- Password spray pattern: many users, one source IP, low failure rate per user
- Successful auth to a no-MFA account followed by data access
- Post-compromise behavior: new inbox rule, OAuth grant, mass download
