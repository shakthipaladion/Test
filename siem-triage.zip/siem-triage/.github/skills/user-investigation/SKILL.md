---
description: Entra ID user security investigation — sign-ins, MFA, risk, anomalies.
triggers: ["investigate user", "check user activity", UPN or email address, "user behavioral"]
---

# User Investigation

Use this skill when the user wants to investigate a specific user account
(by UPN, email, or display name) — either standalone or as a pivot from an
incident.

## Workflow

### 1. Resolve the user
If you have a UPN/email, proceed. If you have only a display name, use
`run_kql` against `SigninLogs` to confirm the UPN:

```kql
SigninLogs
| where TimeGenerated > ago(7d)
| where UserDisplayName has "{{name}}"
| summarize by UserPrincipalName, UserId
| take 5
```

### 2. Identity posture snapshot
- `get_risky_user(userId)` — current Entra ID Identity Protection state
- `get_user_auth_methods(userId)` — which MFA methods are registered

Note any of: `riskLevel=high`, `riskState=atRisk`, only-password (no MFA).

### 3. Sign-in pattern
- `get_user_signins(userId, days=7)` for interactive + non-interactive
- Look for:
  - Geographic anomalies (sign-ins from unusual countries)
  - Multiple failed sign-ins followed by success
  - Non-interactive sign-ins from new IPs (token replay signature)
  - Conditional Access policy failures
  - Sign-ins to risky applications

### 4. Audit log review
Run `run_kql` on `AuditLogs`:

```kql
AuditLogs
| where TimeGenerated > ago({{window}})
| where TargetResources has "{{upn}}" or InitiatedBy.user.userPrincipalName == "{{upn}}"
| project TimeGenerated, OperationName, Result, InitiatedBy, TargetResources
| order by TimeGenerated desc
| take 100
```

Watch for:
- Self-service password resets (often resolve FP sign-in incidents)
- MFA method changes (especially additions of new methods from new IPs)
- OAuth consent grants
- Inbox rule creations
- Privileged role assignments

### 5. Open incidents touching this user
```kql
SecurityIncident
| where TimeGenerated > ago(30d)
| where AlertIds has_any (
    (SecurityAlert
    | where Entities has "{{upn}}"
    | project SystemAlertId)
)
| project TimeGenerated, IncidentNumber, Title, Severity, Status
```

### 6. Produce verdict (if standalone)
Hand off to `verdict-generation`. If this is a pivot from an incident
triage, fold the findings back into the parent verdict's evidence chain
instead of producing a separate one.

## Risk signals to call out explicitly

- **No MFA registered** on a user with any privileged role
- **MFA method added** within hours of a suspicious sign-in
- **Risky sign-in** (Entra Identity Protection) with `riskState=atRisk` not
  yet remediated
- **Cross-tenant sign-ins** to unexpected tenants
- **OAuth grants** to unverified publishers

## Output

Write to `reports/user-investigation/<upn-or-userid>-<timestamp>.md`.
