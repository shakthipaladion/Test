---
description: Author and validate KQL queries against the Sentinel workspace schema.
triggers: ["write KQL", "KQL for", "query for", "help with KQL", "hunt for"]
---

# KQL Query Authoring

Use this skill when the user asks for a new KQL query, or when the
incident-triage / ioc-investigation skills need a hunt that isn't in the
`queries/` library.

## Pre-flight: check the library first

Before writing anything, grep `queries/` for keywords from the user's
request. Every file has a metadata header you can search:

```bash
grep -ri "password spray" queries/
grep -ri "T1110.003" queries/        # MITRE technique ID
grep -ri "SigninLogs" queries/       # table name
```

If you find a match, use it. Only author new KQL when the library has no
suitable query.

## Authoring rules

1. **One table per file or `union`** — don't sprawl across 6 tables to find
   one signal. Pick the most specific table and pivot from there.
2. **Time-bound everything** — every query starts with `| where
   TimeGenerated > ago(...)` or an explicit `between()`.
3. **Project before joining** — `| project` to the columns you actually
   need before any `join`. Reduces shuffle cost dramatically.
4. **Cap the result** — `| take 100` ceiling unless the user explicitly
   asks for more. Use `| top N by ...` when you need the most-something
   rows.
5. **Parameterize for reuse** — if the query will go into `queries/`, use
   `let target = "{{paramName}}";` so substitution is mechanical.

## Validate before running

For a new query, sanity-check with `take 1` first to verify the schema
references resolve:

```kql
SigninLogs | where TimeGenerated > ago(1h) | take 1
```

If `run_kql` returns a schema error, fix and retry. Don't iterate more
than 3 times — if it's still failing, ask the user whether the table is
licensed/enabled in this workspace.

## Common Sentinel + Defender XDR tables

| Table | Contents |
|---|---|
| `SigninLogs` | Entra ID interactive sign-ins |
| `AADNonInteractiveUserSignInLogs` | Service-to-service, token refresh |
| `AuditLogs` | Entra ID admin / self-service operations |
| `SecurityAlert` | Alerts from all connected products |
| `SecurityIncident` | Sentinel incidents (envelope) |
| `SecurityEvent` | Windows Event Log (via MMA/AMA agent) |
| `CommonSecurityLog` | CEF — firewalls, proxies |
| `DeviceProcessEvents` | Defender for Endpoint process telemetry |
| `DeviceNetworkEvents` | Defender for Endpoint network telemetry |
| `DeviceFileEvents` | Defender for Endpoint file operations |
| `DeviceLogonEvents` | Defender for Endpoint logon activity |
| `IdentityLogonEvents` | MDI identity-layer logons |
| `EmailEvents` | Defender for Office 365 mail flow |
| `CloudAppEvents` | Defender for Cloud Apps activity |

## Saving a new query to the library

After a new query proves useful, write it to the matching `queries/<domain>/`
folder with this header:

```kql
// Title: <one-line description>
// Tables: <comma-separated KQL table names>
// Keywords: <searchable terms — TTPs, scenarios, field names>
// MITRE: <ATT&CK technique IDs>
// Parameters: <name (type, default)>
//
let <param> = "{{<param>}}";
...
```

`<domain>` is one of: `identity`, `endpoint`, `network`, `cloud`. Use
`identity` for `SigninLogs`/`AuditLogs`/`IdentityLogonEvents`; `endpoint`
for `Device*` and `SecurityEvent`; `network` for `CommonSecurityLog` and
`DeviceNetworkEvents`; `cloud` for `CloudAppEvents`/`EmailEvents`.
