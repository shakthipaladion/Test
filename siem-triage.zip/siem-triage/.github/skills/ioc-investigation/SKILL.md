---
description: Indicator of Compromise analysis — IPs, domains, URLs, file hashes.
triggers: ["investigate IP", "investigate hash", "investigate domain", "is this malicious", "IoC", IP/hash/domain values]
---

# IoC Investigation

Use this skill when the user gives you an IoC (IP, hash, domain, URL) and
asks whether it's malicious and whether you've seen it in the environment.

## Workflow

### 1. Identify the IoC type
- IPv4/IPv6 address → IP path
- 32/40/64-character hex string → file hash (MD5/SHA1/SHA256)
- FQDN → domain path
- Full URL → domain path on the host portion + URL path

### 2. External threat intelligence
Call the matching enrichment tool:

| IoC | Tool |
|---|---|
| IP | `enrich_ip` |
| Hash | `enrich_hash` |
| Domain | `enrich_domain` |

For each TI source that returns data, record:
- The verdict (clean / malicious / suspicious)
- The score and last-seen timestamp
- Any associated threat family or campaign labels

Skipped sources (no API key) → note the gap, do not fabricate.

### 3. Tenant exposure — has this IoC been seen?

**For an IP:**
```kql
union
  (SigninLogs       | where IPAddress == "{{ip}}"),
  (CommonSecurityLog | where SourceIP == "{{ip}}" or DestinationIP == "{{ip}}"),
  (DeviceNetworkEvents | where RemoteIP == "{{ip}}")
| where TimeGenerated > ago(30d)
| summarize hits=count(), firstSeen=min(TimeGenerated), lastSeen=max(TimeGenerated) by Type=$table
```

**For a hash:**
```kql
union
  (DeviceFileEvents   | where SHA256 == "{{hash}}" or SHA1 == "{{hash}}" or MD5 == "{{hash}}"),
  (DeviceProcessEvents| where SHA256 == "{{hash}}" or SHA1 == "{{hash}}" or MD5 == "{{hash}}"),
  (DeviceImageLoadEvents | where SHA256 == "{{hash}}")
| where TimeGenerated > ago(30d)
| summarize hits=count(), devices=dcount(DeviceName), firstSeen=min(TimeGenerated), lastSeen=max(TimeGenerated) by Type=$table
```

**For a domain:**
```kql
union
  (DeviceNetworkEvents | where RemoteUrl has "{{domain}}"),
  (CommonSecurityLog   | where RequestURL has "{{domain}}" or DestinationHostName has "{{domain}}")
| where TimeGenerated > ago(30d)
| summarize hits=count(), firstSeen=min(TimeGenerated), lastSeen=max(TimeGenerated) by Type=$table
```

### 4. Existing detections / incidents
Check whether this IoC already triggered alerts:
```kql
SecurityAlert
| where TimeGenerated > ago(30d)
| where Entities has "{{ioc}}"
| project TimeGenerated, AlertName, AlertSeverity, ProductName, SystemAlertId
```

### 5. Classification
- **Malicious + seen in tenant** → high priority. Recommend host isolation
  (advisory only, human executes), full investigation of affected entities.
- **Malicious + not seen** → block at perimeter (advisory). Suggest threat
  hunt for related TTPs.
- **Clean + seen in tenant** → likely benign but document the visibility.
- **Clean + not seen** → noise. Note and close.

### 6. Produce verdict
Hand off to `verdict-generation`. For IoC verdicts, the `entitiesInvestigated`
section should list every internal entity (user, host) that touched the IoC,
so a follow-up user/host investigation can be chained.

## Output

Write to `reports/ioc-investigation/<ioc-type>-<value>-<timestamp>.md`.
Sanitize the IoC in the filename (replace `.` and `/` with `_`).
