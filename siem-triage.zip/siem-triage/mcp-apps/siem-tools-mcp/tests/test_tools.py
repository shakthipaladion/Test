"""Smoke tests — verify tool metadata and dispatch are wired correctly.

These do NOT call live APIs. For integration tests against a real
Sentinel workspace, see docs/setup.md.
"""
from __future__ import annotations

import asyncio
import json

from siem_tools.tools import HANDLERS, TOOLS


def test_every_tool_has_a_handler() -> None:
    declared = {t["name"] for t in TOOLS}
    handled = set(HANDLERS.keys())
    assert declared == handled, f"Mismatch: declared={declared} handled={handled}"


def test_tool_schemas_are_valid_json_schema_shape() -> None:
    for t in TOOLS:
        assert "name" in t
        assert "description" in t
        s = t["inputSchema"]
        assert s["type"] == "object"
        assert "properties" in s


def test_call_tool_returns_json_string() -> None:
    # Use enrich_ip with no API keys — returns {skipped: ...} without network
    async def _go() -> str:
        from siem_tools.tools import call_tool
        return await call_tool("enrich_ip", {"ip": "192.0.2.1"})

    out = asyncio.run(_go())
    parsed = json.loads(out)
    assert parsed["ip"] == "192.0.2.1"
    assert "virustotal" in parsed
    assert "abuseipdb" in parsed
    assert "greynoise" in parsed
