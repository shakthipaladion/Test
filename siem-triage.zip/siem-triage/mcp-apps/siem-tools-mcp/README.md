# siem-tools-mcp

Local stdio MCP server exposing Microsoft Sentinel and Defender XDR triage
tools to GitHub Copilot. Authenticates as a Service Principal (client ID +
secret).

## Tools exposed

| Tool | API | Token audience |
|---|---|---|
| `list_recent_incidents` | Graph Security | `graph.microsoft.com` |
| `get_incident` | Graph Security | `graph.microsoft.com` |
| `get_alert` | Graph Security | `graph.microsoft.com` |
| `run_kql` | Log Analytics Query | `api.loganalytics.io` |
| `get_risky_user` | Graph IdentityProtection | `graph.microsoft.com` |
| `get_user_auth_methods` | Graph Authentication | `graph.microsoft.com` |
| `get_user_signins` | Graph AuditLogs | `graph.microsoft.com` |
| `enrich_ip` | VT + AbuseIPDB + GreyNoise | n/a |
| `enrich_hash` | VirusTotal | n/a |
| `enrich_domain` | VirusTotal | n/a |

## Install

```bash
cd mcp-apps/siem-tools-mcp
pip install -e .
```

## Run standalone (for testing)

```bash
python -m siem_tools.server
```

It speaks MCP over stdio; pair with `mcp-cli` or VS Code Copilot to interact.

## Required Service Principal permissions

**Microsoft Graph (application permissions, admin consent required):**
- `SecurityIncident.Read.All`
- `SecurityAlert.Read.All`
- `User.Read.All`
- `IdentityRiskyUser.Read.All`
- `UserAuthenticationMethod.Read.All`
- `AuditLog.Read.All`

**Azure RBAC (on the Sentinel workspace or its resource group):**
- `Microsoft Sentinel Reader` (for ARM incident endpoints, if used)
- `Log Analytics Reader` (for KQL via `api.loganalytics.io`)
