"""Log Analytics Query API client — KQL execution via api.loganalytics.io."""
from __future__ import annotations

import os
from typing import Any

import httpx

from .auth import la_token

LA_BASE = "https://api.loganalytics.io/v1"


async def run_kql(query: str, timespan: str = "P7D") -> dict[str, Any]:
    """Run a KQL query against the configured Log Analytics workspace.

    Args:
        query: The KQL query string.
        timespan: ISO 8601 duration (e.g. P7D, PT24H, PT1H) or an explicit
            interval (start/end ISO 8601 separated by '/').

    Returns the Log Analytics tabular response. On error, raises with the
    response body included so the caller can see the Kusto error.
    """
    workspace_id = os.environ["AZURE_LOG_ANALYTICS_WORKSPACE_ID"]
    url = f"{LA_BASE}/workspaces/{workspace_id}/query"
    headers = {
        "Authorization": f"Bearer {la_token()}",
        "Content-Type": "application/json",
    }
    body = {"query": query, "timespan": timespan}
    async with httpx.AsyncClient(timeout=120) as c:
        r = await c.post(url, headers=headers, json=body)
        if r.status_code >= 400:
            raise RuntimeError(
                f"Log Analytics error {r.status_code}: {r.text[:1000]}"
            )
        return _flatten_tables(r.json())


def _flatten_tables(la_response: dict[str, Any]) -> dict[str, Any]:
    """Convert the columnar Log Analytics response into row-of-dicts form.

    The native shape is awkward to feed to an LLM:
        {"tables": [{"name": "PrimaryResult",
                     "columns": [{"name": "X", "type": "string"}, ...],
                     "rows": [[...], [...]]}]}

    We flatten to:
        {"tables": [{"name": "PrimaryResult",
                     "rows": [{"X": ..., ...}, ...],
                     "rowCount": N}]}
    """
    out_tables = []
    for t in la_response.get("tables", []):
        cols = [c["name"] for c in t.get("columns", [])]
        rows = [dict(zip(cols, r)) for r in t.get("rows", [])]
        out_tables.append(
            {"name": t.get("name"), "rowCount": len(rows), "rows": rows}
        )
    return {"tables": out_tables}
