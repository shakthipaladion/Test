"""MCP tool definitions and dispatch table.

Each tool has a JSON Schema for its inputs (consumed by the MCP protocol)
and a handler that the server invokes. Handlers are async.
"""
from __future__ import annotations

import json
from typing import Any, Awaitable, Callable

from . import enrichment, graph_client, loganalytics

Handler = Callable[[dict[str, Any]], Awaitable[Any]]


TOOLS: list[dict[str, Any]] = [
    {
        "name": "list_recent_incidents",
        "description": (
            "List recent Microsoft Sentinel / Defender XDR incidents from the "
            "Graph Security API. Use to discover what's open before diving "
            "into a specific incident."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "top": {"type": "integer", "default": 25, "minimum": 1, "maximum": 100},
                "status": {
                    "type": "string",
                    "enum": ["active", "resolved", "inProgress", "redirected"],
                    "description": "Optional status filter.",
                },
            },
        },
    },
    {
        "name": "get_incident",
        "description": (
            "Fetch a Sentinel/Defender XDR incident by ID, with its alerts "
            "expanded. Returns entities, severity, status, createdDateTime, "
            "and the alert payloads."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"incident_id": {"type": "string"}},
            "required": ["incident_id"],
        },
    },
    {
        "name": "get_alert",
        "description": "Fetch a single alert with full detail by alert ID.",
        "inputSchema": {
            "type": "object",
            "properties": {"alert_id": {"type": "string"}},
            "required": ["alert_id"],
        },
    },
    {
        "name": "run_kql",
        "description": (
            "Execute a KQL query against the Sentinel Log Analytics workspace. "
            "Use ISO 8601 duration for timespan (P7D, PT24H, PT1H). Results "
            "come back as rows of column-keyed dicts. Cap results with `take`."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "timespan": {"type": "string", "default": "P7D"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_risky_user",
        "description": (
            "Get Entra ID Identity Protection risk state for a user. Pass the "
            "user's object ID (preferred) or UPN. Returns riskLevel, "
            "riskState, riskDetail, lastUpdatedDateTime."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"user_id": {"type": "string"}},
            "required": ["user_id"],
        },
    },
    {
        "name": "get_user_auth_methods",
        "description": (
            "List MFA / authentication methods registered for a user. Use to "
            "determine MFA posture during sign-in investigations."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"user_id": {"type": "string"}},
            "required": ["user_id"],
        },
    },
    {
        "name": "get_user_signins",
        "description": (
            "Recent interactive sign-ins for a user via the Graph auditLogs "
            "endpoint. For non-interactive sign-ins, query "
            "AADNonInteractiveUserSignInLogs via run_kql."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "user_id": {"type": "string"},
                "days": {"type": "integer", "default": 7, "minimum": 1, "maximum": 30},
            },
            "required": ["user_id"],
        },
    },
    {
        "name": "enrich_ip",
        "description": (
            "Aggregate threat intelligence for an IP across VirusTotal, "
            "AbuseIPDB, and GreyNoise. Sources without API keys return "
            "{skipped: ...}; do not fabricate enrichment from missing sources."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"ip": {"type": "string"}},
            "required": ["ip"],
        },
    },
    {
        "name": "enrich_hash",
        "description": "VirusTotal lookup for a file hash (MD5, SHA1, or SHA256).",
        "inputSchema": {
            "type": "object",
            "properties": {"file_hash": {"type": "string"}},
            "required": ["file_hash"],
        },
    },
    {
        "name": "enrich_domain",
        "description": "VirusTotal lookup for a domain (FQDN).",
        "inputSchema": {
            "type": "object",
            "properties": {"domain": {"type": "string"}},
            "required": ["domain"],
        },
    },
]


HANDLERS: dict[str, Handler] = {
    "list_recent_incidents": lambda a: graph_client.list_recent_incidents(
        top=a.get("top", 25), status=a.get("status")
    ),
    "get_incident": lambda a: graph_client.get_incident(a["incident_id"]),
    "get_alert": lambda a: graph_client.get_alert(a["alert_id"]),
    "run_kql": lambda a: loganalytics.run_kql(
        a["query"], timespan=a.get("timespan", "P7D")
    ),
    "get_risky_user": lambda a: graph_client.get_risky_user(a["user_id"]),
    "get_user_auth_methods": lambda a: graph_client.get_user_auth_methods(
        a["user_id"]
    ),
    "get_user_signins": lambda a: graph_client.get_user_signins(
        a["user_id"], days=a.get("days", 7)
    ),
    "enrich_ip": lambda a: enrichment.enrich_ip(a["ip"]),
    "enrich_hash": lambda a: enrichment.enrich_hash(a["file_hash"]),
    "enrich_domain": lambda a: enrichment.enrich_domain(a["domain"]),
}


async def call_tool(name: str, arguments: dict[str, Any]) -> str:
    """Dispatch a tool call. Returns a JSON string for the MCP text content."""
    if name not in HANDLERS:
        raise ValueError(f"Unknown tool: {name}")
    result = await HANDLERS[name](arguments or {})
    return json.dumps(result, indent=2, default=str)
