"""Microsoft Graph clients — Security incidents/alerts + user identity data."""
from __future__ import annotations

from typing import Any

import httpx

from .auth import graph_token

GRAPH_BASE = "https://graph.microsoft.com/v1.0"
GRAPH_BETA = "https://graph.microsoft.com/beta"


def _headers() -> dict[str, str]:
    return {"Authorization": f"Bearer {graph_token()}"}


async def list_recent_incidents(
    top: int = 25, status: str | None = None
) -> dict[str, Any]:
    """List recent Sentinel/Defender XDR incidents from the unified Graph endpoint."""
    params: dict[str, Any] = {"$top": top, "$orderby": "createdDateTime desc"}
    if status:
        params["$filter"] = f"status eq '{status}'"
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{GRAPH_BASE}/security/incidents", headers=_headers(), params=params
        )
        r.raise_for_status()
        return r.json()


async def get_incident(incident_id: str) -> dict[str, Any]:
    """Fetch an incident with its alerts expanded."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{GRAPH_BASE}/security/incidents/{incident_id}",
            headers=_headers(),
            params={"$expand": "alerts"},
        )
        r.raise_for_status()
        return r.json()


async def get_alert(alert_id: str) -> dict[str, Any]:
    """Fetch a single alert with full detail (entities, evidence, MITRE)."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{GRAPH_BASE}/security/alerts_v2/{alert_id}",
            headers=_headers(),
        )
        r.raise_for_status()
        return r.json()


async def get_risky_user(user_id: str) -> dict[str, Any]:
    """Return Entra ID Identity Protection state for a user. 404 → notFound."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{GRAPH_BASE}/identityProtection/riskyUsers/{user_id}",
            headers=_headers(),
        )
        if r.status_code == 404:
            return {"notFound": True, "userId": user_id}
        r.raise_for_status()
        return r.json()


async def get_user_auth_methods(user_id: str) -> dict[str, Any]:
    """List MFA / authentication methods registered for a user."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{GRAPH_BASE}/users/{user_id}/authentication/methods",
            headers=_headers(),
        )
        r.raise_for_status()
        return r.json()


async def get_user_signins(user_id: str, days: int = 7) -> dict[str, Any]:
    """Recent interactive sign-ins for a user via Graph AuditLogs.

    Note: non-interactive sign-ins live in AADNonInteractiveUserSignInLogs
    in Log Analytics, queried via run_kql.
    """
    filt = (
        f"userId eq '{user_id}' and "
        f"createdDateTime ge {_iso_days_ago(days)}"
    )
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{GRAPH_BASE}/auditLogs/signIns",
            headers=_headers(),
            params={"$filter": filt, "$top": 100},
        )
        r.raise_for_status()
        return r.json()


def _iso_days_ago(days: int) -> str:
    from datetime import datetime, timedelta, timezone

    return (datetime.now(timezone.utc) - timedelta(days=days)).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )
