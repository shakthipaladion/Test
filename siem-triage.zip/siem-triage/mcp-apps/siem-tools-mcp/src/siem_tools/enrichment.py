"""Third-party threat intelligence enrichment.

Each provider degrades gracefully — if its API key isn't set, the function
returns {"skipped": "no <provider> key"} rather than failing. This lets
the agent always call enrich_* and decide based on whatever did return.
"""
from __future__ import annotations

import os
from typing import Any

import httpx


def _vt_key() -> str | None:
    k = os.environ.get("VIRUSTOTAL_API_KEY", "").strip()
    return k or None


def _abuseipdb_key() -> str | None:
    k = os.environ.get("ABUSEIPDB_API_KEY", "").strip()
    return k or None


def _greynoise_key() -> str | None:
    k = os.environ.get("GREYNOISE_API_KEY", "").strip()
    return k or None


async def enrich_ip(ip: str) -> dict[str, Any]:
    """Aggregate VT + AbuseIPDB + GreyNoise verdicts for an IP."""
    return {
        "ip": ip,
        "virustotal": await _vt_ip(ip),
        "abuseipdb": await _abuseipdb_ip(ip),
        "greynoise": await _greynoise_ip(ip),
    }


async def enrich_hash(file_hash: str) -> dict[str, Any]:
    return {"hash": file_hash, "virustotal": await _vt_file(file_hash)}


async def enrich_domain(domain: str) -> dict[str, Any]:
    return {"domain": domain, "virustotal": await _vt_domain(domain)}


# --------------------------------------------------------------------------- #
# VirusTotal v3
# --------------------------------------------------------------------------- #

VT_BASE = "https://www.virustotal.com/api/v3"


async def _vt_request(path: str) -> dict[str, Any]:
    key = _vt_key()
    if not key:
        return {"skipped": "no VirusTotal key"}
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(f"{VT_BASE}/{path}", headers={"x-apikey": key})
        if r.status_code == 404:
            return {"notFound": True}
        if r.status_code >= 400:
            return {"error": f"VT {r.status_code}", "detail": r.text[:500]}
        body = r.json().get("data", {}).get("attributes", {})
        return {
            "lastAnalysisStats": body.get("last_analysis_stats"),
            "reputation": body.get("reputation"),
            "lastAnalysisDate": body.get("last_analysis_date"),
            "asOwner": body.get("as_owner"),
            "country": body.get("country"),
            "categories": body.get("categories"),
            "popularRanks": body.get("popular_ranks"),
        }


async def _vt_ip(ip: str) -> dict[str, Any]:
    return await _vt_request(f"ip_addresses/{ip}")


async def _vt_file(file_hash: str) -> dict[str, Any]:
    return await _vt_request(f"files/{file_hash}")


async def _vt_domain(domain: str) -> dict[str, Any]:
    return await _vt_request(f"domains/{domain}")


# --------------------------------------------------------------------------- #
# AbuseIPDB
# --------------------------------------------------------------------------- #


async def _abuseipdb_ip(ip: str) -> dict[str, Any]:
    key = _abuseipdb_key()
    if not key:
        return {"skipped": "no AbuseIPDB key"}
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            "https://api.abuseipdb.com/api/v2/check",
            headers={"Key": key, "Accept": "application/json"},
            params={"ipAddress": ip, "maxAgeInDays": 90},
        )
        if r.status_code >= 400:
            return {"error": f"AbuseIPDB {r.status_code}", "detail": r.text[:500]}
        data = r.json().get("data", {})
        return {
            "abuseConfidenceScore": data.get("abuseConfidenceScore"),
            "totalReports": data.get("totalReports"),
            "lastReportedAt": data.get("lastReportedAt"),
            "countryCode": data.get("countryCode"),
            "isp": data.get("isp"),
            "usageType": data.get("usageType"),
        }


# --------------------------------------------------------------------------- #
# GreyNoise (community endpoint works without a key; richer data with one)
# --------------------------------------------------------------------------- #


async def _greynoise_ip(ip: str) -> dict[str, Any]:
    key = _greynoise_key()
    headers = {"Accept": "application/json"}
    if key:
        headers["key"] = key
        url = f"https://api.greynoise.io/v3/community/{ip}"
    else:
        url = f"https://api.greynoise.io/v3/community/{ip}"
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(url, headers=headers)
        if r.status_code == 404:
            return {"seen": False}
        if r.status_code >= 400:
            return {"error": f"GreyNoise {r.status_code}", "detail": r.text[:500]}
        return r.json()
