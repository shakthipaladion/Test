"""Service Principal authentication with per-audience token caching.

Both Microsoft Graph and the Log Analytics Query API require different
token audiences. azure-identity caches tokens per (credential, scope) so
calling getToken repeatedly is cheap.
"""
from __future__ import annotations

import os
from functools import lru_cache

from azure.identity import ClientSecretCredential

GRAPH_SCOPE = "https://graph.microsoft.com/.default"
LOG_ANALYTICS_SCOPE = "https://api.loganalytics.io/.default"
ARM_SCOPE = "https://management.azure.com/.default"


@lru_cache(maxsize=1)
def credential() -> ClientSecretCredential:
    tenant = os.environ["AZURE_TENANT_ID"]
    client_id = os.environ["AZURE_CLIENT_ID"]
    secret = os.environ["AZURE_CLIENT_SECRET"]
    return ClientSecretCredential(tenant, client_id, secret)


def get_token(scope: str) -> str:
    """Return a bearer token for the requested scope."""
    token = credential().get_token(scope)
    return token.token


def graph_token() -> str:
    return get_token(GRAPH_SCOPE)


def la_token() -> str:
    return get_token(LOG_ANALYTICS_SCOPE)


def arm_token() -> str:
    return get_token(ARM_SCOPE)
