"""siem-tools-mcp — stdio MCP server for Sentinel + Defender XDR triage."""
__version__ = "0.1.0"
