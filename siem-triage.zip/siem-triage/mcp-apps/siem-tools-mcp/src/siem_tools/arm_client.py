"""Azure Resource Manager client — Sentinel incident endpoints via ARM.

Most triage data is best fetched via the Graph Security API (unified across
Sentinel + Defender XDR), but some Sentinel-specific resources (analytic
rules, watchlists, automation rules) only live on the ARM provider
`Microsoft.SecurityInsights`. Kept here for future expansion.
"""
from __future__ import annotations

import os
from typing import Any

import httpx

from .auth import arm_token

ARM_BASE = "https://management.azure.com"
SENTINEL_API_VERSION = "2024-09-01"


def _workspace_scope() -> str:
    sub = os.environ["AZURE_SUBSCRIPTION_ID"]
    rg = os.environ.get("AZURE_RESOURCE_GROUP", "")
    ws = os.environ.get("AZURE_WORKSPACE_NAME", "")
    return (
        f"/subscriptions/{sub}/resourceGroups/{rg}/providers/"
        f"Microsoft.OperationalInsights/workspaces/{ws}/providers/"
        f"Microsoft.SecurityInsights"
    )


async def list_sentinel_incidents(top: int = 25) -> dict[str, Any]:
    """List Sentinel incidents via the ARM Microsoft.SecurityInsights provider.

    Prefer get_incident from graph_client for unified Sentinel/Defender data.
    Use this when you specifically need Sentinel-side fields like
    `labels` or `relatedAnalyticRuleIds`.
    """
    url = f"{ARM_BASE}{_workspace_scope()}/incidents"
    params = {
        "api-version": SENTINEL_API_VERSION,
        "$top": top,
        "$orderby": "properties/createdTimeUtc desc",
    }
    headers = {"Authorization": f"Bearer {arm_token()}"}
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(url, headers=headers, params=params)
        r.raise_for_status()
        return r.json()
