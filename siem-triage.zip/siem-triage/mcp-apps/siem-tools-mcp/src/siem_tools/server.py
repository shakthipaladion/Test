"""MCP stdio server entry point.

Run with: python -m siem_tools.server

Speaks the Model Context Protocol over stdin/stdout, exposing the tools
defined in siem_tools.tools.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys

from dotenv import load_dotenv
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .tools import HANDLERS, TOOLS, call_tool

# Load .env from the repo root if present (mcp.json env injection takes precedence)
load_dotenv()

logging.basicConfig(
    level=os.environ.get("SIEM_TOOLS_LOG_LEVEL", "INFO"),
    stream=sys.stderr,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("siem-tools-mcp")

server: Server = Server("siem-tools")


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name=t["name"],
            description=t["description"],
            inputSchema=t["inputSchema"],
        )
        for t in TOOLS
    ]


@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[TextContent]:
    log.info("call_tool: %s args=%s", name, list((arguments or {}).keys()))
    try:
        text = await call_tool(name, arguments or {})
    except Exception as e:  # noqa: BLE001 — surface every error to the client
        log.exception("tool %s failed", name)
        text = f'{{"error": "{type(e).__name__}: {e}"}}'
    return [TextContent(type="text", text=text)]


async def _run() -> None:
    _check_env()
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def _check_env() -> None:
    required = [
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
        "AZURE_LOG_ANALYTICS_WORKSPACE_ID",
    ]
    missing = [k for k in required if not os.environ.get(k)]
    if missing:
        log.error("Missing required env vars: %s", ", ".join(missing))
        sys.exit(1)
    # Reference HANDLERS so static checkers don't drop the import
    log.info("Loaded %d tools", len(HANDLERS))


def main() -> None:
    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
