# Service Principal Setup

Step-by-step creation of the Entra ID app registration and RBAC assignments
needed by the triage agent.

## 1. Create the app registration

Entra ID → **App registrations** → **New registration**

| Field | Value |
|---|---|
| Name | `siem-triage-mcp` |
| Supported account types | Single tenant |
| Redirect URI | (leave blank — no interactive flow) |

Copy these from the Overview blade:
- **Application (client) ID** → `AZURE_CLIENT_ID`
- **Directory (tenant) ID** → `AZURE_TENANT_ID`

## 2. Create a client secret

App registration → **Certificates & secrets** → **Client secrets** → **New
client secret**

| Field | Value |
|---|---|
| Description | `siem-triage-mcp-2026` |
| Expires | 12 months (set a reminder!) |

Copy the **Value** immediately — it is shown only once. This is your
`AZURE_CLIENT_SECRET`.

> **Production:** prefer a certificate or federated credential. Client
> secrets are convenient for local dev but rotate annually.

## 3. Grant Microsoft Graph permissions

App registration → **API permissions** → **Add a permission** →
**Microsoft Graph** → **Application permissions**

Add all of these:

| Permission | Why |
|---|---|
| `SecurityIncident.Read.All` | Read incidents via Graph Security API |
| `SecurityAlert.Read.All` | Read alerts inside incidents |
| `User.Read.All` | Resolve user objects for enrichment |
| `IdentityRiskyUser.Read.All` | Entra Identity Protection state |
| `UserAuthenticationMethod.Read.All` | MFA method enumeration |
| `AuditLog.Read.All` | Sign-in and audit log reads via Graph |

After adding, click **Grant admin consent for `<tenant>`**. You need
**Global Administrator** or **Privileged Role Administrator** for this
step.

Verify each row shows `Granted for <tenant>` ✅.

## 4. Grant Azure RBAC on the Sentinel workspace

Azure portal → your Sentinel workspace → **Access control (IAM)** → **Add
role assignment**.

Add two role assignments — both targeting the same SP:

| Role | Why |
|---|---|
| `Log Analytics Reader` | KQL queries via `api.loganalytics.io` |
| `Microsoft Sentinel Reader` | Sentinel ARM provider (for future ARM-based tools) |

For each:
1. Select role
2. **Members** → **User, group, or service principal** → search for
   `siem-triage-mcp` (the app reg name) → select it
3. Save

You can scope these at the workspace level (least privilege) or at the
resource group / subscription level if you want the SP to cover multiple
workspaces.

## 5. Verify

From the repo root with your `.env` populated:

```bash
python -c "
import asyncio, sys
sys.path.insert(0, 'mcp-apps/siem-tools-mcp/src')
from dotenv import load_dotenv; load_dotenv()
from siem_tools.auth import graph_token, la_token
print('graph token len:', len(graph_token()))
print('la token len:', len(la_token()))
"
```

Both should print integers around 1500–2500. If you get an error from
`ClientSecretCredential`, your `.env` values are wrong or the secret has
already expired.

Then test an actual call:

```bash
python -c "
import asyncio, sys
sys.path.insert(0, 'mcp-apps/siem-tools-mcp/src')
from dotenv import load_dotenv; load_dotenv()
from siem_tools.graph_client import list_recent_incidents
print(asyncio.run(list_recent_incidents(top=3)))
"
```

If this returns incidents, you're done. If it returns 401, admin consent
wasn't granted. If it returns 403, the permission is consented but
something else is wrong — check the Audit log in Entra for the call.

## Rotation

When the secret expires:

1. Create a new secret (step 2)
2. Update `AZURE_CLIENT_SECRET` in your `.env` (and the keychain entry
   for `${input:clientSecret}` in VS Code if it's cached)
3. Delete the old secret in the portal once you've confirmed the new one
   works
