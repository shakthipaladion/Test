# Setup Guide

End-to-end walkthrough for getting the SIEM Triage Agent running.

## Prerequisites

| Requirement | Version | Why |
|---|---|---|
| **VS Code** | 1.99+ | Agent mode + MCP support |
| **GitHub Copilot** | Active subscription | Pro+, Business, or Enterprise; Agent Mode enabled |
| **Python** | 3.10+ | MCP server runtime |
| **Microsoft Sentinel** | Workspace deployed | Log Analytics workspace with SecurityIncident table |
| **Entra ID app registration** | — | Service Principal for non-interactive auth |

## 1. Service Principal

Follow `docs/service-principal-setup.md` to:
- Create the app registration
- Generate a client secret
- Grant Microsoft Graph application permissions (with admin consent)
- Grant Azure RBAC roles on the Sentinel workspace

You will need at the end:
- Tenant ID
- Client ID
- Client secret (one-time view)
- Workspace GUID
- Subscription ID

## 2. Clone and install

```bash
git clone <your-repo-url> siem-triage
cd siem-triage

python -m venv .venv
source .venv/bin/activate              # Linux/macOS
# .venv\Scripts\Activate.ps1            # Windows

pip install -r requirements.txt
pip install -e mcp-apps/siem-tools-mcp
```

The `pip install -e` makes the MCP server importable as `siem_tools` so
VS Code can spawn it.

## 3. Configure

```bash
cp .env.template .env
cp config.json.template config.json
cp .vscode/mcp.json.template .vscode/mcp.json
```

Edit `.env` with the values from step 1. Edit `config.json` with your
Sentinel workspace details. The `.vscode/mcp.json` template prompts for
secrets at first use, so you don't need to edit it directly.

## 4. Smoke-test the MCP server

```bash
# Verify env + tool dispatch (no network)
cd mcp-apps/siem-tools-mcp
pytest -q
cd ../..

# Verify enrichment APIs (hits VT/AbuseIPDB/GreyNoise if keys set)
python scripts/enrich_ips.py 8.8.8.8
```

If `enrich_ips.py` returns `{"skipped": "..."}` for every source, your TI
keys aren't set or aren't valid. That's fine for now — Microsoft data
sources work without them.

## 5. Verify Azure connectivity

```bash
python -c "
import asyncio, os
from dotenv import load_dotenv
load_dotenv()
import sys; sys.path.insert(0, 'mcp-apps/siem-tools-mcp/src')
from siem_tools.loganalytics import run_kql
print(asyncio.run(run_kql('SigninLogs | take 1', timespan='PT1H')))
"
```

A successful response confirms:
- SP can authenticate against `api.loganalytics.io`
- SP has `Log Analytics Reader` on the workspace
- Workspace GUID in `.env` is correct

Common errors:
- `401`: secret expired or wrong audience — check `AZURE_CLIENT_SECRET`
- `403`: SP missing `Log Analytics Reader` role on the workspace
- `404`: workspace GUID is wrong

## 6. Wire up VS Code

1. Open the repo in VS Code: `code .`
2. Open Copilot Chat: `Ctrl+Shift+I`
3. Switch to **Agent Mode** (dropdown above the chat input)
4. Click the tool/wrench icon — you should see `siem-tools` listed with all
   10 tools. If you don't, check the MCP Servers panel for errors.
5. On first tool call, VS Code prompts for each `${input:...}` value from
   `.vscode/mcp.json` — these are cached in your OS keychain after that.

## 7. First triage

In Copilot Chat:

```
List my 5 most recent active incidents.
```

Then pick one:

```
Triage incident <id-from-list>. Produce a verdict.
```

The agent will load `incident-triage/SKILL.md`, call `get_incident`,
enrich entities, run KQL hunts, and write the verdict to
`reports/incident-triage/<id>.md`.

## Troubleshooting

| Symptom | Fix |
|---|---|
| MCP server doesn't appear in VS Code | Check the MCP Servers panel (bottom status bar `{}` icon) for stderr from the Python process. Most common: import error from `pip install -e` not done. |
| "Missing required env vars" on server start | The `.vscode/mcp.json` `inputs` weren't filled in. Delete the cached values from the keychain and reload the window. |
| `run_kql` returns 403 | SP missing `Log Analytics Reader` on the workspace. See `docs/service-principal-setup.md`. |
| `get_incident` returns 401 | Graph application permissions not consented. An admin must consent in Entra → App registrations → API permissions → Grant admin consent. |
| `get_incident` returns 404 | Incident ID format mismatch — Defender XDR incident IDs are numeric strings; some workflows pass the GUID. Try `list_recent_incidents` first to see the canonical IDs. |
| Verdict has no evidence | The agent is following the rules in `verdict-generation/SKILL.md`. Look at the chat transcript for which tool calls failed silently. |
