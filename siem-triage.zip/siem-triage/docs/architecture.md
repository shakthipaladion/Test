# Architecture

## Component diagram

```
┌────────────────────────────────────────────────────────────────┐
│                     VS Code (your machine)                     │
│                                                                │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  GitHub Copilot Chat — Agent Mode                        │  │
│  │  • Loads .github/copilot-instructions.md                  │  │
│  │  • Loads .github/skills/<name>/SKILL.md on keyword match  │  │
│  │  • Sonnet (or whichever Copilot model you've selected)    │  │
│  └────────────────────┬─────────────────────────────────────┘  │
│                       │ stdio (JSON-RPC, MCP)                   │
│                       ▼                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  siem-tools-mcp  (Python, spawned by VS Code)             │  │
│  │                                                            │  │
│  │  server.py           — MCP stdio loop                      │  │
│  │  tools.py            — tool definitions + dispatch         │  │
│  │  auth.py             — ClientSecretCredential, token cache │  │
│  │  graph_client.py     — Graph Security API                  │  │
│  │  loganalytics.py     — Log Analytics Query API             │  │
│  │  arm_client.py       — Azure ARM (Sentinel provider)       │  │
│  │  enrichment.py       — VirusTotal / AbuseIPDB / GreyNoise  │  │
│  └────────────────────┬─────────────────────────────────────┘  │
└─────────────────────────│──────────────────────────────────────┘
                          │ HTTPS
                          ▼
   ┌─────────────────────────────────────────────────────────┐
   │  Microsoft + third-party APIs                            │
   │  • graph.microsoft.com/v1.0/security/incidents           │
   │  • graph.microsoft.com/v1.0/identityProtection/...       │
   │  • api.loganalytics.io/v1/workspaces/{id}/query (KQL)    │
   │  • management.azure.com (ARM, optional)                  │
   │  • virustotal.com / abuseipdb.com / greynoise.io         │
   └─────────────────────────────────────────────────────────┘
```

## Authentication flow

The MCP server uses `azure-identity.ClientSecretCredential` to obtain
tokens for three audiences:

| Audience | API | Required for |
|---|---|---|
| `https://graph.microsoft.com/.default` | Microsoft Graph | Incidents, alerts, users, MFA, risk |
| `https://api.loganalytics.io/.default` | Log Analytics Query | All KQL queries |
| `https://management.azure.com/.default` | Azure ARM | Sentinel ARM provider endpoints |

Tokens are cached by `azure-identity` per `(credential, scope)` and
refreshed automatically before expiry. The credential itself is memoized
with `lru_cache(maxsize=1)` so it's instantiated once per server lifetime.

## Request lifecycle

A typical "triage incident" request:

1. **User** types `Triage incident inc-123` in Copilot Chat.
2. **Copilot** matches the keyword, loads `incident-triage/SKILL.md`,
   constructs an LLM prompt that includes the skill's workflow.
3. **Sonnet** decides to call `get_incident` with the ID. Copilot sends
   the MCP `tools/call` request over stdio.
4. **MCP server** dispatches to `graph_client.get_incident`, which calls
   Graph with a cached bearer token.
5. **Graph** returns the incident envelope with alerts and entities.
6. **MCP server** serializes the response as JSON text and returns it.
7. **Copilot** shows the tool result to the user (for approval if
   first-time), then the model continues — calling enrichment tools and
   `run_kql` as the skill prescribes.
8. **Model** produces the final verdict JSON, instructs Copilot to write
   it to `temp/triage-inc-123.json` and `reports/incident-triage/inc-123.md`.
9. **User** sees the chat transcript + the markdown report in the editor
   and decides what to do next.

## What this architecture deliberately does *not* do

- **No background processing.** The agent runs only while a chat is
  active. No queue, no worker, no scheduler.
- **No persistent state.** Each chat is independent. Continuity comes from
  the human reading prior reports in `reports/`.
- **No write APIs.** The SP has read-only permissions. Even if the model
  asked, there's no tool that can close an incident or isolate a host.
- **No multi-tenant.** One SP, one tenant. To triage another tenant,
  open a different workspace with a different `.env`.

## Trade-offs vs. a full SOC platform

| Concern | This design | Full platform (e.g. SIEMTriage) |
|---|---|---|
| Setup time | Minutes | Hours/days |
| Cost | Copilot subscription only | Postgres + Redis + worker hosting + Copilot/Anthropic |
| Concurrency | One analyst at a time | Multiple, queued |
| Automated ingestion | None | Logic App → webhook → queue |
| Audit trail | Git-committed reports | DB rows with full event stream |
| Eval harness | Manual replay | Built-in accuracy metrics |
| Multi-analyst handoff | Reports in repo | Web UI with decision panel |

Choose this design when you're 1–3 analysts using the agent
interactively. Outgrow it when you need to triage hundreds of incidents
per day unattended.
