"""Clean up temp/ investigation files older than N days.

Usage:
    python scripts/cleanup_temp.py
    python scripts/cleanup_temp.py --days 7 --dry-run
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=3, help="Retention days (default: 3)")
    ap.add_argument("--temp-dir", type=Path, default=Path("temp"))
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if not args.temp_dir.exists():
        print(f"No temp dir at {args.temp_dir}")
        return

    cutoff = time.time() - args.days * 86400
    removed = 0
    for f in args.temp_dir.iterdir():
        if not f.is_file() or f.name == ".gitkeep":
            continue
        if f.stat().st_mtime < cutoff:
            print(("[dry-run] " if args.dry_run else "") + f"rm {f}")
            if not args.dry_run:
                f.unlink()
            removed += 1
    print(f"{'Would remove' if args.dry_run else 'Removed'} {removed} files older than {args.days}d")


if __name__ == "__main__":
    main()
