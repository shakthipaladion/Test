"""Generate a markdown report from a verdict JSON file.

Usage:
    python scripts/generate_report.py temp/triage-<id>.json
    python scripts/generate_report.py temp/triage-<id>.json --format html

Writes to reports/<skill>/<incidentId>.md (or .html).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def render_markdown(verdict: dict[str, Any]) -> str:
    inc = verdict.get("incidentId", "unknown")
    cls = verdict.get("classification", "?")
    conf = verdict.get("confidence", 0.0)
    skill = verdict.get("skill", "incident-triage")
    ts = verdict.get("timestamp", "?")
    summary = verdict.get("summary", "")

    lines: list[str] = []
    lines.append(f"# Triage Verdict — {inc}\n")
    lines.append(f"**Classification:** {cls} · **Confidence:** {conf:.2f}")
    lines.append(f"**Skill:** {skill} · **Timestamp:** {ts}\n")
    lines.append("## Summary\n")
    lines.append(f"{summary}\n")

    evidence = verdict.get("evidence") or []
    lines.append("## Evidence\n")
    if evidence:
        lines.append("| # | Claim | Source |")
        lines.append("|---|-------|--------|")
        for i, e in enumerate(evidence, 1):
            claim = (e.get("claim") or "").replace("|", "\\|")
            source = (e.get("source") or "").replace("|", "\\|")
            lines.append(f"| {i} | {claim} | `{source}` |")
        lines.append("")
    else:
        lines.append("_No evidence recorded._\n")

    ents = verdict.get("entitiesInvestigated") or {}
    lines.append("## Entities Investigated\n")
    for k in ("users", "ips", "hosts", "hashes", "domains"):
        vals = ents.get(k) or []
        lines.append(f"- **{k.title()}:** " + (", ".join(f"`{v}`" for v in vals) or "_none_"))
    lines.append("")

    kql = verdict.get("kqlRun") or []
    lines.append("## KQL Queries Run\n")
    if kql:
        lines.append("| # | Source | Rows |")
        lines.append("|---|--------|------|")
        for i, q in enumerate(kql, 1):
            src = (q.get("source") or "ad-hoc").replace("|", "\\|")
            lines.append(f"| {i} | `{src}` | {q.get('rowCount', '?')} |")
        lines.append("")
    else:
        lines.append("_No KQL queries recorded._\n")

    plan = verdict.get("deepDivePlan") or []
    lines.append("## Deep-Dive Plan\n")
    if plan:
        for i, step in enumerate(plan, 1):
            lines.append(f"{i}. {step}")
        lines.append("")
    else:
        lines.append("_None._\n")

    actions = verdict.get("recommendedActions") or []
    lines.append("## Recommended Actions (advisory — for human execution)\n")
    if actions:
        for a in actions:
            lines.append(f"- {a}")
        lines.append("")
    else:
        lines.append("_None._\n")

    lines.append("---")
    lines.append(
        "_Handoff state: "
        f"`{verdict.get('handoffState', 'awaiting_decision')}`. "
        "The agent did not take any response action._"
    )
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("verdict_json", type=Path)
    ap.add_argument("--reports-dir", type=Path, default=Path("reports"))
    args = ap.parse_args()

    verdict = json.loads(args.verdict_json.read_text(encoding="utf-8"))
    inc = verdict.get("incidentId", "unknown").replace("/", "_")
    skill = verdict.get("skill", "incident-triage")
    out_dir = args.reports_dir / skill
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{inc}.md"
    out.write_text(render_markdown(verdict), encoding="utf-8")
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
