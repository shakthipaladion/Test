"""Standalone IP enrichment CLI — useful for testing TI API keys.

Usage:
    python scripts/enrich_ips.py 8.8.8.8 1.1.1.1
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

# Make the package importable when run from repo root
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "mcp-apps" / "siem-tools-mcp" / "src"))

from dotenv import load_dotenv  # noqa: E402

load_dotenv()

from siem_tools.enrichment import enrich_ip  # noqa: E402


async def _run(ips: list[str]) -> None:
    results = await asyncio.gather(*(enrich_ip(ip) for ip in ips))
    print(json.dumps(results, indent=2, default=str))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("ips", nargs="+")
    args = ap.parse_args()
    asyncio.run(_run(args.ips))


if __name__ == "__main__":
    main()
