# Verified KQL Query Library

Battle-tested KQL queries organized by data domain. The triage agent
greps this folder **before** authoring ad-hoc KQL (see the pre-flight
checklist in `.github/copilot-instructions.md`).

## Folder layout

- `identity/` — Entra ID and identity layer (`SigninLogs`, `AuditLogs`,
  `AADNonInteractiveUserSignInLogs`, `IdentityLogonEvents`)
- `endpoint/` — Defender for Endpoint device telemetry (`Device*`,
  `SecurityEvent`)
- `network/` — Network telemetry (`CommonSecurityLog`,
  `DeviceNetworkEvents`)
- `cloud/` — Cloud app and email (`CloudAppEvents`, `EmailEvents`)

## Metadata header

Every `.kql` file starts with this header so `grep -ri` can find queries
by keyword, MITRE ID, or table name:

```kql
// Title: <one-line description>
// Tables: <comma-separated KQL table names>
// Keywords: <searchable terms — TTPs, scenarios, field names>
// MITRE: <ATT&CK technique IDs, e.g., T1110.003>
// Parameters: <name (type, default)>
//
let <param> = "{{<param>}}";
<query>
```

## Discovery

```bash
# By keyword
grep -ri "password spray" queries/

# By MITRE technique
grep -ri "T1110" queries/

# By table
grep -ri "Tables:.*SigninLogs" queries/
```

## Adding a query

After authoring useful new KQL during an investigation, save it to the
matching folder with the metadata header above. Parameterize with
`{{paramName}}` placeholders so the agent can substitute mechanically.
