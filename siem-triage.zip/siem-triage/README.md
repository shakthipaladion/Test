# SIEM Triage Agent

A Tier-1 SOC triage agent for **Microsoft Sentinel** and **Microsoft Defender XDR**, built on **GitHub Copilot Agent Mode** with a custom Python MCP server. Authenticates to Microsoft Graph and Log Analytics with a Service Principal (client ID + secret) — no Sentinel data lake, no managed identity, no Anthropic SDK required.

The agent **never closes incidents or takes response actions**. It produces a verdict with evidence and hands off to a human analyst.

## What it does

Given a Sentinel or Defender XDR incident ID, the agent:

1. Pulls the incident envelope, alerts, and entities (Microsoft Graph Security API).
2. Enriches entities — IPs/hashes/domains through VirusTotal, GreyNoise, AbuseIPDB; users through Entra ID risky-user score and MFA state.
3. Runs targeted KQL hunts against the Sentinel Log Analytics workspace.
4. Returns a verdict (classification, confidence, evidence chain, deep-dive plan, recommended actions).
5. Writes the verdict to `reports/incident-triage/<incident-id>.md` for a durable trail.

## Architecture

```
┌──────────────────────────────────┐
│ VS Code + GitHub Copilot Chat    │
│  (Agent Mode, Sonnet)            │
└────────────┬─────────────────────┘
             │ MCP stdio
             ▼
┌──────────────────────────────────┐
│ siem-tools-mcp  (Python)         │
│  • ClientSecretCredential        │
│  • Graph Security API tools      │
│  • Log Analytics KQL tools       │
│  • Azure ARM tools (Sentinel)    │
│  • TI enrichment (VT/AIPDB/GN)   │
└────────────┬─────────────────────┘
             │ HTTPS
             ▼
   graph.microsoft.com (Security API)
   api.loganalytics.io/v1 (KQL)
   management.azure.com (ARM)
```

## Quick start

```bash
# 1. Clone and open in VS Code
git clone <your-repo-url> siem-triage
code siem-triage

# 2. Python environment for the MCP server
python -m venv .venv
source .venv/bin/activate                  # Linux/macOS
# .venv\Scripts\Activate.ps1                # Windows
pip install -r requirements.txt

# 3. Configure
cp config.json.template config.json        # edit workspace + tenant + sub IDs
cp .env.template .env                      # edit SP creds + TI keys
cp .vscode/mcp.json.template .vscode/mcp.json

# 4. Open Copilot Chat (Ctrl+Shift+I), switch to Agent Mode, then try:
#    "Triage incident <incident-id>"
#    "Investigate user user@domain.com for the last 7 days"
#    "Is this IP malicious? 203.0.113.42"
```

See `docs/setup.md` for the full walk-through and `docs/service-principal-setup.md` for the Entra app registration + RBAC steps.

## Project structure

```
siem-triage/
├── .github/
│   ├── copilot-instructions.md   # universal routing + verdict rules
│   └── skills/                   # 5 specialized triage workflows
├── .vscode/
│   └── mcp.json.template         # registers the local Python MCP server
├── mcp-apps/
│   └── siem-tools-mcp/           # custom MCP server (Python, stdio)
├── queries/                      # verified KQL library, by data domain
├── reports/                      # generated verdicts, by skill
├── temp/                         # working JSON, auto-cleaned
├── scripts/                      # Python utilities (report gen, cleanup)
└── docs/                         # setup, architecture, SP RBAC
```

## License

MIT
