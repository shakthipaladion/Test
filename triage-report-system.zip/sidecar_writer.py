"""Sidecar file writer for KQL and enrichment results.

Used by the MCP server (siem-tools-mcp) to persist full result sets next
to triage reports. The verdict JSON references these files by path; the
HTML report links to them.

Layout:
    reports/<incidentId>-evidence/
        query-01-<slug>.csv
        query-01-<slug>.json
        query-02-<slug>.csv
        query-02-<slug>.json
        enrichment-01-<slug>.json
        ...
        index.json     # manifest of all files in this directory

Usage:
    from sidecar_writer import EvidenceWriter

    writer = EvidenceWriter(incident_id="inc-2026-05-19-0042",
                            reports_dir="reports")

    csv_path, json_path = writer.write_kql_result(
        title="Failed sign-ins followed by success",
        source="queries/identity/signin-failures-then-success.kql",
        rows=[{"TimeGenerated": "...", "IPAddress": "..."}, ...],
    )
    # csv_path  = reports/inc-.../query-01-failed-signins-followed-by-success.csv
    # json_path = reports/inc-.../query-01-failed-signins-followed-by-success.json

    enrich_path = writer.write_enrichment(
        target="203.0.113.42",
        source="virustotal",
        result={"last_analysis_stats": {...}, ...},
    )

    writer.finalize()  # writes index.json
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _slug(s: str, max_len: int = 60) -> str:
    """Convert arbitrary text to a filename-safe slug."""
    s = s.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = s.strip("-")
    return s[:max_len] or "result"


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class EvidenceWriter:
    """Writes KQL and enrichment sidecar files for a single triage."""

    def __init__(self, incident_id: str, reports_dir: str | Path = "reports") -> None:
        safe_id = incident_id.replace("/", "_").replace("\\", "_")
        self.incident_id = safe_id
        self.reports_dir = Path(reports_dir)
        self.evidence_dir = self.reports_dir / f"{safe_id}-evidence"
        self.evidence_dir.mkdir(parents=True, exist_ok=True)
        self._kql_count = 0
        self._enrich_count = 0
        self._files: list[dict[str, Any]] = []

    # ------------------------------------------------------------------ #
    # KQL results — written as both CSV and JSON
    # ------------------------------------------------------------------ #

    def write_kql_result(
        self,
        title: str,
        source: str,
        rows: list[dict[str, Any]],
        query: str | None = None,
    ) -> dict[str, Any]:
        """Write a KQL result set as paired CSV + JSON files.

        Returns a dict suitable to merge into the verdict's kqlRun[] item:
            {
              "resultsCsvPath": "...",
              "resultsJsonPath": "...",
              "resultsSizeBytes": int,
              "resultsSha256": "..."
            }
        """
        self._kql_count += 1
        idx = self._kql_count
        slug = _slug(title)
        base = f"query-{idx:02d}-{slug}"
        csv_path = self.evidence_dir / f"{base}.csv"
        json_path = self.evidence_dir / f"{base}.json"

        # JSON — full fidelity, preserves nested structures
        json_payload = {
            "title": title,
            "source": source,
            "query": query,
            "executedAt": _now_iso(),
            "rowCount": len(rows),
            "rows": rows,
        }
        json_bytes = json.dumps(json_payload, indent=2, default=str).encode("utf-8")
        json_path.write_bytes(json_bytes)

        # CSV — flat columnar view for Excel/grep
        if rows:
            # Union of all keys across rows; preserves first-seen order
            cols: list[str] = []
            seen = set()
            for row in rows:
                for k in row.keys():
                    if k not in seen:
                        seen.add(k)
                        cols.append(k)
            csv_buf = io.StringIO()
            writer = csv.DictWriter(csv_buf, fieldnames=cols, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                # Stringify any non-scalar value for CSV
                writer.writerow(
                    {
                        k: (
                            json.dumps(v, default=str)
                            if isinstance(v, (dict, list))
                            else v
                        )
                        for k, v in row.items()
                    }
                )
            csv_bytes = csv_buf.getvalue().encode("utf-8")
        else:
            csv_bytes = b"(no rows)\n"
        csv_path.write_bytes(csv_bytes)

        sha = hashlib.sha256(json_bytes).hexdigest()
        size = json_path.stat().st_size + csv_path.stat().st_size

        record = {
            "queryIndex": idx,
            "title": title,
            "source": source,
            "rowCount": len(rows),
            "resultsCsvPath": str(csv_path.as_posix()),
            "resultsJsonPath": str(json_path.as_posix()),
            "resultsSizeBytes": size,
            "resultsSha256": sha,
        }
        self._files.append({"kind": "kql", **record})
        return record

    # ------------------------------------------------------------------ #
    # Enrichment results — JSON only (these are already structured)
    # ------------------------------------------------------------------ #

    def write_enrichment(
        self,
        target: str,
        source: str,
        result: dict[str, Any],
    ) -> dict[str, Any]:
        """Write an enrichment result as a JSON file.

        Returns a dict suitable to merge into enrichmentResults[]:
            {
              "resultsJsonPath": "...",
              "resultsSizeBytes": int,
              "resultsSha256": "..."
            }
        """
        self._enrich_count += 1
        idx = self._enrich_count
        slug = _slug(f"{source}-{target}")
        json_path = self.evidence_dir / f"enrichment-{idx:02d}-{slug}.json"

        payload = {
            "target": target,
            "source": source,
            "executedAt": _now_iso(),
            "result": result,
        }
        body = json.dumps(payload, indent=2, default=str).encode("utf-8")
        json_path.write_bytes(body)

        sha = hashlib.sha256(body).hexdigest()
        record = {
            "enrichmentIndex": idx,
            "target": target,
            "source": source,
            "resultsJsonPath": str(json_path.as_posix()),
            "resultsSizeBytes": json_path.stat().st_size,
            "resultsSha256": sha,
        }
        self._files.append({"kind": "enrichment", **record})
        return record

    # ------------------------------------------------------------------ #
    # Finalize — write the manifest
    # ------------------------------------------------------------------ #

    def finalize(self) -> Path:
        """Write an index.json manifest of all sidecar files. Returns its path."""
        manifest_path = self.evidence_dir / "index.json"
        manifest = {
            "incidentId": self.incident_id,
            "generatedAt": _now_iso(),
            "fileCount": len(self._files),
            "files": self._files,
        }
        manifest_path.write_text(
            json.dumps(manifest, indent=2, default=str), encoding="utf-8"
        )
        return manifest_path


# ---------------------------------------------------------------------- #
# CLI for ad-hoc use / testing
# ---------------------------------------------------------------------- #

if __name__ == "__main__":
    # Demo: build a fake evidence directory for the sample verdict
    writer = EvidenceWriter(
        incident_id="inc-2026-05-19-0042", reports_dir="reports-demo"
    )

    writer.write_kql_result(
        title="Failed sign-ins followed by successful auth for a user",
        source="queries/identity/signin-failures-then-success.kql",
        rows=[
            {"TimeGenerated": "2026-05-19T14:28:11Z", "IPAddress": "203.0.113.42",
             "UserPrincipalName": "alice@contoso.com", "ResultType": 50126,
             "ResultDescription": "Invalid username or password"},
            {"TimeGenerated": "2026-05-19T14:28:34Z", "IPAddress": "203.0.113.42",
             "UserPrincipalName": "alice@contoso.com", "ResultType": 50126,
             "ResultDescription": "Invalid username or password"},
            {"TimeGenerated": "2026-05-19T14:29:45Z",
             "OperationName": "Reset password (self-service)", "Result": "success",
             "TargetResources": "alice@contoso.com"},
            {"TimeGenerated": "2026-05-19T14:30:08Z", "IPAddress": "203.0.113.42",
             "UserPrincipalName": "alice@contoso.com", "ResultType": 0,
             "ResultDescription": "Success"},
        ],
        query="let target = \"alice@contoso.com\"; ...",
    )

    writer.write_enrichment(
        target="203.0.113.42",
        source="virustotal",
        result={
            "last_analysis_stats": {"malicious": 0, "harmless": 70, "suspicious": 0, "undetected": 24},
            "reputation": 0,
            "as_owner": "Contoso EMEA",
            "country": "GB",
        },
    )

    manifest = writer.finalize()
    print(f"Wrote manifest: {manifest}")
