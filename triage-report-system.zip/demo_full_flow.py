"""End-to-end demo: write sidecar files, then generate the HTML report.

This script simulates what the agent's verdict-generation skill will do
after a triage completes. In production, the MCP server's run_kql and
enrichment tools call EvidenceWriter as they execute, then the skill
runs generate_html_report.py at the end.

Run:
    python3 demo_full_flow.py
    # → outputs/demo/inc-2026-05-19-0042.html  (the report)
    # → outputs/demo/inc-2026-05-19-0042-evidence/  (sidecar files)
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from sidecar_writer import EvidenceWriter


def main() -> None:
    out_root = Path("outputs/demo")
    out_root.mkdir(parents=True, exist_ok=True)
    inc_id = "inc-2026-05-19-0042"

    # 1. Write sidecar files (simulating tool calls during a triage)
    writer = EvidenceWriter(incident_id=inc_id, reports_dir=out_root)

    # First KQL: the failed-signins-then-success hunt
    kql_record_1 = writer.write_kql_result(
        title="Failed sign-ins followed by successful auth for a user",
        source="queries/identity/signin-failures-then-success.kql",
        query=(
            'let target = "alice@contoso.com";\n'
            'let window = 4h;\n'
            'let failures = SigninLogs\n'
            '    | where TimeGenerated > ago(window)\n'
            '    | where UserPrincipalName =~ target\n'
            '    | where ResultType != 0;\n'
            'let firstSuccess = SigninLogs\n'
            '    | where TimeGenerated > ago(window)\n'
            '    | where UserPrincipalName =~ target\n'
            '    | where ResultType == 0\n'
            '    | top 1 by TimeGenerated asc;\n'
            'let resets = AuditLogs\n'
            '    | where TimeGenerated > ago(window)\n'
            '    | where OperationName has "Reset password"\n'
            '    | where TargetResources has target;\n'
            'union failures, firstSuccess, resets\n'
            '| order by TimeGenerated asc'
        ),
        rows=[
            {"TimeGenerated": f"2026-05-19T14:28:{11 + i*7:02d}Z",
             "IPAddress": "203.0.113.42",
             "UserPrincipalName": "alice@contoso.com",
             "Location": "GB",
             "AppDisplayName": "Office 365",
             "ResultType": 50126,
             "ResultDescription": "Invalid username or password"}
            for i in range(8)
        ] + [
            {"TimeGenerated": "2026-05-19T14:29:45Z",
             "OperationName": "Reset password (self-service)",
             "Result": "success",
             "InitiatedBy": "alice@contoso.com",
             "TargetResources": "alice@contoso.com",
             "IPAddress": "203.0.113.42"},
            {"TimeGenerated": "2026-05-19T14:30:08Z",
             "IPAddress": "203.0.113.42",
             "UserPrincipalName": "alice@contoso.com",
             "Location": "GB",
             "AppDisplayName": "Office 365",
             "ResultType": 0,
             "ResultDescription": "Success",
             "AuthenticationDetails": {"authenticationStepResultDetail": "Authenticator app notification"}},
        ],
    )

    # Second KQL: tenant-wide activity from the source IP (this is the "487 rows" one)
    kql_record_2 = writer.write_kql_result(
        title="Tenant-wide activity from source IP",
        source="ad-hoc",
        query=(
            'SigninLogs\n'
            '| where TimeGenerated > ago(7d)\n'
            '| where IPAddress == "203.0.113.42"\n'
            '| project TimeGenerated, UserPrincipalName, AppDisplayName, ResultType, Location\n'
            '| order by TimeGenerated desc\n'
            '| take 1000'
        ),
        rows=[
            {"TimeGenerated": f"2026-05-{12 + (i % 7):02d}T{6 + (i % 12):02d}:{(i * 7) % 60:02d}:00Z",
             "UserPrincipalName": f"user{(i % 43) + 1:02d}@contoso.com",
             "AppDisplayName": ["Office 365", "Teams", "SharePoint", "Outlook"][i % 4],
             "ResultType": 0,
             "Location": "GB"}
            for i in range(487)
        ],
    )

    # Enrichment calls
    writer.write_enrichment(
        target="alice@contoso.com",
        source="get_risky_user",
        result={"riskLevel": "none", "riskState": "none",
                "riskDetail": "none",
                "lastUpdatedDateTime": "2026-05-15T08:21:00Z",
                "userPrincipalName": "alice@contoso.com"},
    )
    writer.write_enrichment(
        target="alice@contoso.com",
        source="get_user_auth_methods",
        result={"value": [
            {"@odata.type": "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod",
             "displayName": "iPhone 15", "isDefault": True},
            {"@odata.type": "#microsoft.graph.phoneAuthenticationMethod",
             "phoneNumber": "+44 7700 ***123", "phoneType": "mobile"},
            {"@odata.type": "#microsoft.graph.passwordAuthenticationMethod",
             "createdDateTime": "2024-08-12T10:14:00Z"},
        ]},
    )
    writer.write_enrichment(
        target="203.0.113.42",
        source="virustotal",
        result={
            "last_analysis_stats": {"malicious": 0, "suspicious": 0, "harmless": 70,
                                    "undetected": 24, "timeout": 0},
            "reputation": 0,
            "as_owner": "Contoso EMEA",
            "country": "GB",
            "asn": 64500,
            "last_analysis_date": 1747641600,
        },
    )
    writer.write_enrichment(
        target="203.0.113.42",
        source="abuseipdb",
        result={"abuseConfidenceScore": 0, "countryCode": "GB",
                "usageType": "Business / VPN",
                "isp": "Contoso Internet Services",
                "totalReports": 0, "lastReportedAt": None},
    )
    writer.write_enrichment(
        target="203.0.113.42",
        source="greynoise",
        result={"ip": "203.0.113.42", "noise": False, "riot": True,
                "classification": "benign", "name": "Contoso VPN",
                "link": "https://viz.greynoise.io/riot/203.0.113.42",
                "last_seen": "2026-05-19", "message": "Contoso corporate VPN egress"},
    )

    manifest_path = writer.finalize()
    print(f"✓ Wrote {len(list(writer.evidence_dir.glob('*')))} evidence files in {writer.evidence_dir}")
    print(f"  Manifest: {manifest_path}")

    # 2. Now generate the report — pointing the verdict at the evidence we just wrote
    verdict = json.loads(Path("sample-verdict.json").read_text())
    # Patch paths to match where we actually wrote files
    verdict["evidenceDirectory"] = str(writer.evidence_dir.as_posix()) + "/"
    verdict["metadata"]["evidenceDirectory"] = verdict["evidenceDirectory"]
    verdict["metadata"]["evidenceFileCount"] = len(list(writer.evidence_dir.glob("*")))
    verdict["kqlRun"][0]["resultsCsvPath"] = kql_record_1["resultsCsvPath"]
    verdict["kqlRun"][0]["resultsJsonPath"] = kql_record_1["resultsJsonPath"]
    verdict["kqlRun"][0]["resultsSizeBytes"] = kql_record_1["resultsSizeBytes"]
    verdict["kqlRun"][0]["resultsSha256"] = kql_record_1["resultsSha256"]
    verdict["kqlRun"][1]["resultsCsvPath"] = kql_record_2["resultsCsvPath"]
    verdict["kqlRun"][1]["resultsJsonPath"] = kql_record_2["resultsJsonPath"]
    verdict["kqlRun"][1]["resultsSizeBytes"] = kql_record_2["resultsSizeBytes"]
    verdict["kqlRun"][1]["resultsSha256"] = kql_record_2["resultsSha256"]

    # Match enrichment paths back
    for i, e in enumerate(verdict["enrichmentResults"]):
        e["resultsJsonPath"] = f"{writer.evidence_dir.as_posix()}/enrichment-{i+1:02d}-{_slug_local(e['source'] + '-' + e['target'])}.json"

    # Write patched verdict and generate report
    temp_verdict_path = out_root / "patched-verdict.json"
    temp_verdict_path.write_text(json.dumps(verdict, indent=2))

    result = subprocess.run(
        [sys.executable, "generate_html_report.py", str(temp_verdict_path),
         "--reports-dir", str(out_root)],
        capture_output=True, text=True,
    )
    print(result.stdout, end="")
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

    print()
    print("Final outputs:")
    for f in sorted(out_root.rglob("*")):
        if f.is_file():
            size = f.stat().st_size
            size_str = f"{size:>8,} B" if size < 10000 else f"{size/1024:>6.1f} KB"
            print(f"  {size_str}  {f}")


def _slug_local(s: str, max_len: int = 60) -> str:
    import re
    s = s.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = s.strip("-")
    return s[:max_len] or "result"


if __name__ == "__main__":
    main()
