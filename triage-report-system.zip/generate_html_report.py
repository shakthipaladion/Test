"""Generate a two-tab HTML triage report from a verdict JSON file.

Tab 1 — Summary & Verdict: verdict, evidence chain, reasoning, recommendations
Tab 2 — Evidence Repository: KQL queries + links to full result files

The report references sidecar files in reports/<incidentId>-evidence/
rather than embedding result rows. This keeps the report small,
PII-light, and shareable, while preserving full auditability via
the linked CSV/JSON files.

Usage:
    python scripts/generate_html_report.py temp/triage-<incidentId>.json
    python scripts/generate_html_report.py temp/triage-<incidentId>.json --reports-dir reports
"""
from __future__ import annotations

import argparse
import html
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def esc(s: Any) -> str:
    """HTML-escape, treating None as empty string."""
    if s is None:
        return ""
    return html.escape(str(s), quote=True)


def fmt_ts(iso: str) -> str:
    if not iso:
        return "—"
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    except (ValueError, AttributeError):
        return esc(iso)


def fmt_duration(seconds: int | float | None) -> str:
    if seconds is None:
        return "—"
    seconds = int(seconds)
    m, s = divmod(seconds, 60)
    if m:
        return f"{m}m {s}s"
    return f"{s}s"


def fmt_bytes(n: int | None) -> str:
    if n is None:
        return "—"
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n / (1024 * 1024):.1f} MB"


def classification_class(c: str) -> str:
    return {
        "TruePositive": "tp",
        "FalsePositive": "fp",
        "Benign": "benign",
        "Inconclusive": "inconclusive",
    }.get(c, "inconclusive")


def confidence_descriptor(conf: float) -> str:
    if conf >= 0.95:
        return "Multiple aligned signals"
    if conf >= 0.85:
        return "Strong signal, no contradictions"
    return "Below confidence floor — must be Inconclusive"


def enrichment_pill_class(verdict: str) -> str:
    return {
        "clean": "ok",
        "benign": "ok",
        "informational": "info",
        "suspicious": "warn",
        "malicious": "bad",
    }.get((verdict or "").lower(), "info")


def role_pill_class(role: str) -> str:
    return {"subject": "subject", "source": "source", "target": "target"}.get(
        (role or "").lower(), ""
    )


def rel_path(report_html_path: Path, target_path_str: str) -> str:
    """Make target_path relative to the report's directory so the <a href> works
    regardless of where someone moves the report folder."""
    if not target_path_str:
        return ""
    try:
        report_dir = report_html_path.parent
        target = Path(target_path_str)
        # If target is already a sibling/child of report_dir, posix-style rel path
        return os.path.relpath(target, report_dir).replace(os.sep, "/")
    except (ValueError, OSError):
        return target_path_str


# --------------------------------------------------------------------------- #
# Tab 1 — Summary & Verdict
# --------------------------------------------------------------------------- #

def render_summary_tab(v: dict[str, Any]) -> str:
    cls = v.get("classification", "Inconclusive")
    cls_class = classification_class(cls)
    conf = float(v.get("confidence") or 0.0)
    conf_desc = confidence_descriptor(conf)

    parts: list[str] = []

    parts.append(f"""
    <section class="verdict-banner verdict-{cls_class}">
      <div class="verdict-banner-main">
        <div class="verdict-pill verdict-pill-{cls_class}">{esc(cls)}</div>
        <div class="verdict-confidence">
          <div class="verdict-confidence-num">{conf:.2f}</div>
          <div class="verdict-confidence-label">Confidence</div>
        </div>
      </div>
      <div class="verdict-summary">{esc(v.get("summary") or "")}</div>
      <div class="verdict-confidence-desc">{esc(conf_desc)}</div>
      <div class="verdict-action">
        <span class="verdict-action-label">Recommended next action</span>
        <strong>{esc(v.get("recommendedNextAction") or "Review")}</strong>
      </div>
    </section>""")

    parts.append(f"""
    <section class="card">
      <h3>Incident</h3>
      <table class="meta-table">
        <tr><th>ID</th><td><code>{esc(v.get("incidentId"))}</code></td></tr>
        <tr><th>Title</th><td>{esc(v.get("incidentTitle"))}</td></tr>
        <tr><th>Severity</th><td>{esc(v.get("incidentSeverity"))}</td></tr>
        <tr><th>Product</th><td>{esc(v.get("incidentProduct"))}</td></tr>
        <tr><th>Created</th><td>{esc(fmt_ts(v.get("incidentCreatedDateTime") or ""))}</td></tr>
        <tr><th>Triaged by</th><td>{esc(v.get("triagedBy"))}</td></tr>
        <tr><th>Triage completed</th><td>{esc(fmt_ts(v.get("triageCompletedAt") or ""))}</td></tr>
        <tr><th>Duration</th><td>{esc(fmt_duration(v.get("metadata", {}).get("totalDurationSeconds")))}</td></tr>
      </table>
    </section>""")

    entities = v.get("entitiesInvestigated") or {}
    ent_rows: list[str] = []
    for kind, items in entities.items():
        for e in items or []:
            ent_rows.append(f"""
              <tr>
                <td><span class="kind-pill">{esc(kind.rstrip('s').upper())}</span></td>
                <td><code>{esc(e.get("value"))}</code></td>
                <td><span class="role-pill role-{role_pill_class(e.get("role", ""))}">{esc(e.get("role", ""))}</span></td>
                <td><span class="enrich-pill enrich-{enrichment_pill_class(e.get("enrichmentStatus", ""))}">{esc(e.get("enrichmentStatus", ""))}</span></td>
              </tr>""")
    if not ent_rows:
        ent_rows.append('<tr><td colspan="4" class="empty">No entities</td></tr>')

    parts.append(f"""
    <section class="card">
      <h3>Entities investigated</h3>
      <table class="entities-table">
        <thead>
          <tr><th>Type</th><th>Value</th><th>Role</th><th>Enrichment</th></tr>
        </thead>
        <tbody>{"".join(ent_rows)}</tbody>
      </table>
    </section>""")

    evidence = v.get("evidence") or []
    ev_rows: list[str] = []
    for i, e in enumerate(evidence, 1):
        ev_rows.append(f"""
          <tr>
            <td class="num">{i}</td>
            <td>{esc(e.get("claim"))}</td>
            <td><code class="source">{esc(e.get("source"))}</code></td>
          </tr>""")
    if not ev_rows:
        ev_rows.append('<tr><td colspan="3" class="empty">No evidence recorded — verdict is unsupported.</td></tr>')

    parts.append(f"""
    <section class="card">
      <h3>Evidence chain</h3>
      <p class="card-deck">Every claim cites the tool call or KQL query that produced it. Full data is on the Evidence Repository tab.</p>
      <table class="evidence-table">
        <thead><tr><th class="num">#</th><th>Claim</th><th>Source</th></tr></thead>
        <tbody>{"".join(ev_rows)}</tbody>
      </table>
    </section>""")

    reasoning = v.get("reasoning") or ""
    if reasoning:
        paras = "".join(f"<p>{esc(p)}</p>" for p in reasoning.split("\n\n") if p.strip())
        parts.append(f"""
    <section class="card">
      <h3>Reasoning</h3>
      {paras}
    </section>""")

    actions = v.get("recommendedActions") or []
    act_rows: list[str] = []
    for a in actions:
        cat = (a.get("category") or "").lower()
        cat_cls = {"immediate": "immediate", "short-term": "shortterm", "preventative": "preventative"}.get(cat, "")
        support = a.get("supportingEvidence") or []
        support_str = ", ".join(f"#{n}" for n in support) if support else "—"
        act_rows.append(f"""
          <tr>
            <td><span class="cat-pill cat-{cat_cls}">{esc(a.get("category", ""))}</span></td>
            <td>{esc(a.get("action"))}</td>
            <td class="num">{esc(support_str)}</td>
          </tr>""")
    if not act_rows:
        act_rows.append('<tr><td colspan="3" class="empty">No actions recommended.</td></tr>')

    parts.append(f"""
    <section class="card">
      <h3>Recommended actions</h3>
      <p class="card-deck">Advisory only. The agent does not execute response actions. Each recommendation links to the evidence claims that support it.</p>
      <table class="actions-table">
        <thead><tr><th>Category</th><th>Recommendation</th><th>Supports</th></tr></thead>
        <tbody>{"".join(act_rows)}</tbody>
      </table>
    </section>""")

    plan = v.get("deepDivePlan") or []
    if plan:
        plan_rows: list[str] = []
        for i, p in enumerate(plan, 1):
            owner = p.get("owner") or "—"
            plan_rows.append(f"""
              <tr>
                <td class="num">{i}</td>
                <td>{esc(p.get("step"))}</td>
                <td><span class="owner-pill">{esc(owner)}</span></td>
                <td class="rationale">{esc(p.get("rationale", ""))}</td>
              </tr>""")
        parts.append(f"""
    <section class="card">
      <h3>Deep-dive plan</h3>
      <table class="plan-table">
        <thead><tr><th class="num">#</th><th>Step</th><th>Owner</th><th>Rationale</th></tr></thead>
        <tbody>{"".join(plan_rows)}</tbody>
      </table>
    </section>""")

    dp = v.get("decisionPanel") or {}
    parts.append(f"""
    <section class="card decision-card">
      <h3>Decision</h3>
      <p class="card-deck">Recorded by the human analyst after reviewing the verdict. The agent does not populate this section.</p>
      <table class="meta-table">
        <tr><th>Decision</th><td>{esc(dp.get("decided") or "<em class='pending'>Awaiting human decision</em>")}</td></tr>
        <tr><th>Decided by</th><td>{esc(dp.get("decidedBy") or "—")}</td></tr>
        <tr><th>Decided at</th><td>{esc(fmt_ts(dp.get("decidedAt") or ""))}</td></tr>
        <tr><th>Deviation from recommendation</th><td>{esc(dp.get("deviationFromRecommendation") or "—")}</td></tr>
        <tr><th>Tracked in</th><td>{esc(dp.get("trackedIn") or "—")}</td></tr>
      </table>
    </section>""")

    return "\n".join(parts)


# --------------------------------------------------------------------------- #
# Tab 2 — Evidence Repository (references sidecar files)
# --------------------------------------------------------------------------- #

def render_evidence_tab(v: dict[str, Any], report_path: Path) -> str:
    parts: list[str] = []

    # Banner explaining what's on this tab and where the files are
    evidence_dir = v.get("evidenceDirectory") or v.get("metadata", {}).get("evidenceDirectory") or ""
    rel_evidence_dir = rel_path(report_path, evidence_dir) if evidence_dir else ""
    file_count = v.get("metadata", {}).get("evidenceFileCount", "—")

    parts.append(f"""
    <section class="card evidence-banner-card">
      <h3>About this tab</h3>
      <p class="card-deck">This page references the full evidence files that back the verdict on Tab 1. KQL results are <strong>not embedded</strong> in this report — they live as CSV and JSON sidecar files next to this HTML, preserving the complete result set without enlarging the report or concentrating PII.</p>
      <table class="meta-table">
        <tr><th>Evidence directory</th><td><code><a href="{esc(rel_evidence_dir)}" target="_blank">{esc(rel_evidence_dir or "—")}</a></code></td></tr>
        <tr><th>Files in directory</th><td>{esc(file_count)}</td></tr>
        <tr><th>Manifest</th><td>{f'<code><a href="{esc(rel_evidence_dir)}index.json" target="_blank">{esc(rel_evidence_dir)}index.json</a></code>' if rel_evidence_dir else "—"}</td></tr>
      </table>
      <p class="evidence-hint">Open CSV files in Excel for review, JSON files for downstream tooling. Each file has a SHA-256 hash for tamper detection.</p>
    </section>""")

    # Enrichment results — table with links per row
    enrichments = v.get("enrichmentResults") or []
    er_rows: list[str] = []
    for e in enrichments:
        json_link = rel_path(report_path, e.get("resultsJsonPath", ""))
        link_html = (
            f'<a href="{esc(json_link)}" target="_blank">JSON</a>'
            if json_link
            else "—"
        )
        er_rows.append(f"""
          <tr>
            <td><code>{esc(e.get("target"))}</code></td>
            <td><code class="source">{esc(e.get("source"))}</code></td>
            <td><span class="enrich-pill enrich-{enrichment_pill_class(e.get("verdict", ""))}">{esc(e.get("verdict", ""))}</span></td>
            <td>{esc(e.get("details", ""))}</td>
            <td class="file-link">{link_html}</td>
          </tr>""")
    if not er_rows:
        er_rows.append('<tr><td colspan="5" class="empty">No enrichment performed.</td></tr>')

    parts.append(f"""
    <section class="card">
      <h3>Enrichment results</h3>
      <p class="card-deck">Threat intelligence and identity enrichment for every entity. Click the file link to open the full raw response from each source.</p>
      <table class="enrichments-table">
        <thead><tr><th>Target</th><th>Source</th><th>Verdict</th><th>Details</th><th>Full response</th></tr></thead>
        <tbody>{"".join(er_rows)}</tbody>
      </table>
    </section>""")

    # KQL queries — query text embedded, results linked
    kql = v.get("kqlRun") or []
    if not kql:
        parts.append("""
    <section class="card">
      <h3>KQL queries executed</h3>
      <p class="empty">No KQL queries were executed during this triage.</p>
    </section>""")
    else:
        kql_blocks: list[str] = []
        for q in kql:
            source = q.get("source") or "ad-hoc"
            is_library = source != "ad-hoc" and source.startswith("queries/")
            badge = "Library" if is_library else "Ad-hoc"
            badge_cls = "lib" if is_library else "adhoc"
            idx = q.get("queryIndex", 0)
            csv_link = rel_path(report_path, q.get("resultsCsvPath", ""))
            json_link = rel_path(report_path, q.get("resultsJsonPath", ""))
            size_str = fmt_bytes(q.get("resultsSizeBytes"))
            sha = q.get("resultsSha256") or ""
            sha_short = f"{sha[:8]}…{sha[-8:]}" if sha else "—"

            kql_blocks.append(f"""
        <details class="kql-block" open>
          <summary>
            <span class="kql-num">#{idx}</span>
            <span class="kql-title">{esc(q.get("title") or "Untitled query")}</span>
            <span class="kql-badge kql-badge-{badge_cls}">{badge}</span>
            <span class="kql-rows">{q.get("rowCount", 0)} rows</span>
          </summary>
          <div class="kql-body">
            <div class="kql-meta">
              <span><strong>Source:</strong> <code>{esc(source)}</code></span>
              <span><strong>Timespan:</strong> <code>{esc(q.get("timespan", "—"))}</code></span>
              <span><strong>Executed:</strong> {esc(fmt_ts(q.get("executedAt", "")))}</span>
            </div>

            <h5>Query</h5>
            <pre class="kql"><code>{esc(q.get("query", ""))}</code></pre>

            <h5>Full results</h5>
            <div class="result-files">
              <div class="result-file">
                <div class="result-file-label">CSV <span class="result-file-hint">— Excel, grep, awk</span></div>
                <div class="result-file-link">
                  {f'<a href="{esc(csv_link)}" target="_blank" class="dl-btn">⬇ Download CSV</a>' if csv_link else '<em>Not generated</em>'}
                </div>
                <div class="result-file-path"><code>{esc(csv_link or "—")}</code></div>
              </div>
              <div class="result-file">
                <div class="result-file-label">JSON <span class="result-file-hint">— full fidelity, nested structures preserved</span></div>
                <div class="result-file-link">
                  {f'<a href="{esc(json_link)}" target="_blank" class="dl-btn">⬇ Download JSON</a>' if json_link else '<em>Not generated</em>'}
                </div>
                <div class="result-file-path"><code>{esc(json_link or "—")}</code></div>
              </div>
            </div>

            <div class="kql-integrity">
              <span><strong>Size:</strong> {esc(size_str)}</span>
              <span><strong>SHA-256:</strong> <code title="{esc(sha)}">{esc(sha_short)}</code></span>
            </div>
          </div>
        </details>""")

        parts.append(f"""
    <section class="card">
      <h3>KQL queries executed</h3>
      <p class="card-deck">Every KQL hunt run during this triage, in execution order. The query text is shown inline; the full result set is in the linked sidecar files. <strong>Library</strong> queries are reusable hunts from the verified library; <strong>Ad-hoc</strong> queries were authored on the spot. Click each row to expand.</p>
      {"".join(kql_blocks)}
    </section>""")

    # Audit footer
    md = v.get("metadata") or {}
    skills = ", ".join(md.get("skillsLoaded") or []) or "—"
    tool_calls = md.get("toolCallsMade") or []
    tool_calls_html = "".join(f"<li><code>{esc(t)}</code></li>" for t in tool_calls) if tool_calls else "<li>—</li>"

    parts.append(f"""
    <section class="card audit-footer">
      <h3>Audit metadata</h3>
      <table class="meta-table">
        <tr><th>Agent version</th><td><code>{esc(v.get("agentVersion"))}</code></td></tr>
        <tr><th>LLM model</th><td><code>{esc(v.get("llmModel"))}</code></td></tr>
        <tr><th>Skills loaded</th><td>{esc(skills)}</td></tr>
        <tr><th>Triage started</th><td>{esc(fmt_ts(v.get("triageStartedAt") or ""))}</td></tr>
        <tr><th>Triage completed</th><td>{esc(fmt_ts(v.get("triageCompletedAt") or ""))}</td></tr>
        <tr><th>Duration</th><td>{esc(fmt_duration(md.get("totalDurationSeconds")))}</td></tr>
        <tr><th>Tool calls made</th><td><ul class="tool-calls">{tool_calls_html}</ul></td></tr>
        <tr><th>Verdict JSON</th><td><code>{esc(md.get("verdictJsonPath") or "—")}</code></td></tr>
        <tr><th>Evidence directory</th><td><code>{esc(rel_evidence_dir or "—")}</code></td></tr>
      </table>
    </section>""")

    return "\n".join(parts)


# --------------------------------------------------------------------------- #
# Styling and runtime JS
# --------------------------------------------------------------------------- #

CSS = """
:root {
  --blue-700: #1d4ed8;
  --blue-600: #2563eb;
  --blue-500: #3b82f6;
  --blue-100: #dbeafe;
  --blue-50:  #eff6ff;
  --slate-900: #0f172a;
  --slate-800: #1e293b;
  --slate-700: #334155;
  --slate-600: #475569;
  --slate-500: #64748b;
  --slate-400: #94a3b8;
  --slate-300: #cbd5e1;
  --slate-200: #e2e8f0;
  --slate-100: #f1f5f9;
  --slate-50:  #f8fafc;
  --red-600: #dc2626;
  --red-100: #fee2e2;
  --red-50:  #fef2f2;
  --amber-600: #d97706;
  --amber-100: #fef3c7;
  --amber-50:  #fffbeb;
  --green-600: #059669;
  --green-100: #d1fae5;
  --green-50:  #ecfdf5;
  --purple-600: #7c3aed;
  --purple-50:  #faf5ff;
  --sans: 'IBM Plex Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
  --mono: 'IBM Plex Mono', 'SF Mono', 'Consolas', monospace;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body {
  font-family: var(--sans);
  font-size: 14px;
  line-height: 1.6;
  color: var(--slate-800);
  background: var(--slate-50);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.wrap { max-width: 1100px; margin: 0 auto; padding: 32px 24px 64px; }

.report-header {
  background: var(--slate-900);
  color: white;
  border-radius: 8px;
  padding: 28px 32px;
  margin-bottom: 24px;
  border-left: 6px solid var(--blue-500);
}
.report-header .eyebrow {
  font-family: var(--mono);
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--blue-500);
  margin-bottom: 10px;
}
.report-header h1 { font-size: 22px; font-weight: 600; letter-spacing: -0.01em; margin-bottom: 6px; }
.report-header .subtitle { color: var(--slate-300); font-size: 14px; }

.tabs { display: flex; gap: 4px; margin-bottom: 0; border-bottom: 2px solid var(--slate-200); }
.tab {
  background: none; border: none; padding: 12px 22px;
  font-family: var(--sans); font-size: 14px; font-weight: 500;
  color: var(--slate-600); cursor: pointer;
  border-bottom: 2px solid transparent; margin-bottom: -2px;
  display: flex; align-items: center; gap: 8px;
  transition: color 0.15s ease, border-color 0.15s ease;
}
.tab:hover { color: var(--slate-900); }
.tab.active { color: var(--blue-700); border-bottom-color: var(--blue-600); font-weight: 600; }
.tab .tab-num {
  font-family: var(--mono); font-size: 10.5px; font-weight: 600;
  color: var(--slate-400); background: var(--slate-100);
  padding: 2px 6px; border-radius: 3px;
}
.tab.active .tab-num { color: var(--blue-700); background: var(--blue-100); }
.tab-panel { display: none; padding-top: 24px; }
.tab-panel.active { display: block; }

.card {
  background: white; border: 1px solid var(--slate-200); border-radius: 8px;
  padding: 22px 26px; margin-bottom: 18px;
}
.card h3 { font-size: 16px; font-weight: 600; color: var(--slate-900); margin-bottom: 4px; }
.card-deck { color: var(--slate-500); font-size: 13px; margin-bottom: 16px; line-height: 1.5; }
.card h5 {
  font-family: var(--mono); font-size: 11px; font-weight: 600;
  letter-spacing: 0.08em; text-transform: uppercase;
  color: var(--slate-500); margin: 18px 0 8px;
}

.verdict-banner {
  background: white; border-radius: 8px; padding: 24px 28px; margin-bottom: 18px;
  border-left: 6px solid var(--slate-400);
  display: grid; grid-template-columns: auto 1fr; gap: 24px; align-items: center;
}
@media (max-width: 700px) { .verdict-banner { grid-template-columns: 1fr; gap: 16px; } }
.verdict-banner.verdict-tp { border-left-color: var(--red-600); background: linear-gradient(to right, var(--red-50), white 40%); }
.verdict-banner.verdict-fp { border-left-color: var(--green-600); background: linear-gradient(to right, var(--green-50), white 40%); }
.verdict-banner.verdict-benign { border-left-color: var(--blue-600); background: linear-gradient(to right, var(--blue-50), white 40%); }
.verdict-banner.verdict-inconclusive { border-left-color: var(--amber-600); background: linear-gradient(to right, var(--amber-50), white 40%); }
.verdict-banner-main { display: flex; flex-direction: column; align-items: flex-start; gap: 12px; }
.verdict-pill {
  display: inline-block; padding: 6px 14px; border-radius: 4px;
  font-family: var(--mono); font-size: 12px; font-weight: 600;
  letter-spacing: 0.05em; text-transform: uppercase; border: 1px solid;
}
.verdict-pill-tp { background: var(--red-100); color: var(--red-600); border-color: #fca5a5; }
.verdict-pill-fp { background: var(--green-100); color: var(--green-600); border-color: #6ee7b7; }
.verdict-pill-benign { background: var(--blue-100); color: var(--blue-700); border-color: #93c5fd; }
.verdict-pill-inconclusive { background: var(--amber-100); color: var(--amber-600); border-color: #fcd34d; }
.verdict-confidence { text-align: center; }
.verdict-confidence-num { font-size: 28px; font-weight: 700; color: var(--slate-900); letter-spacing: -0.02em; line-height: 1; }
.verdict-confidence-label {
  font-family: var(--mono); font-size: 10px; font-weight: 600;
  letter-spacing: 0.1em; text-transform: uppercase; color: var(--slate-500); margin-top: 2px;
}
.verdict-summary { font-size: 16px; color: var(--slate-800); line-height: 1.5; font-weight: 500; grid-column: 1 / -1; }
.verdict-confidence-desc { font-size: 13px; color: var(--slate-500); font-style: italic; grid-column: 1 / -1; }
.verdict-action {
  grid-column: 1 / -1; padding-top: 14px; border-top: 1px solid var(--slate-200);
  display: flex; justify-content: space-between; align-items: center; font-size: 14px;
}
.verdict-action-label {
  font-family: var(--mono); font-size: 11px; font-weight: 600;
  letter-spacing: 0.08em; text-transform: uppercase; color: var(--slate-500);
}
.verdict-action strong { color: var(--slate-900); font-size: 15px; font-weight: 600; }

table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
th {
  text-align: left; font-family: var(--mono); font-size: 10.5px; font-weight: 600;
  letter-spacing: 0.08em; text-transform: uppercase; color: var(--slate-500);
  padding: 8px 12px; background: var(--slate-50);
  border-bottom: 1px solid var(--slate-200); vertical-align: top;
}
td {
  padding: 10px 12px; border-bottom: 1px solid var(--slate-100);
  color: var(--slate-700); vertical-align: top; line-height: 1.5;
}
tr:last-child td { border-bottom: none; }
td code { font-size: 12px; }
td.num { font-family: var(--mono); font-size: 12px; color: var(--slate-500); width: 1%; white-space: nowrap; }
td.empty, .empty { color: var(--slate-400); font-style: italic; text-align: center; padding: 14px; }
td.rationale { color: var(--slate-500); font-size: 12.5px; }
td.file-link { width: 1%; white-space: nowrap; }
td.file-link a { font-family: var(--mono); font-size: 12px; }

.meta-table th {
  background: transparent; border-bottom: none; padding: 6px 12px 6px 0; width: 200px;
  text-transform: none; font-family: var(--sans); font-size: 13px; font-weight: 500;
  color: var(--slate-500); letter-spacing: 0;
}
.meta-table td { padding: 6px 0; border-bottom: 1px dashed var(--slate-100); color: var(--slate-800); }
.meta-table tr:last-child td { border-bottom: none; }

code {
  font-family: var(--mono); font-size: 12px;
  background: var(--slate-100); border: 1px solid var(--slate-200);
  border-radius: 3px; padding: 1px 5px; color: var(--slate-900);
}
code.source { color: var(--blue-700); background: var(--blue-50); border-color: #bfdbfe; }

a { color: var(--blue-600); text-decoration: underline; text-decoration-thickness: 1px; text-underline-offset: 2px; }
a:hover { color: var(--blue-700); }

.kind-pill {
  display: inline-block; font-family: var(--mono); font-size: 10px; font-weight: 700;
  letter-spacing: 0.06em; padding: 2px 7px; border-radius: 3px;
  background: var(--slate-100); color: var(--slate-700);
}
.role-pill, .enrich-pill, .cat-pill, .owner-pill {
  display: inline-block; font-family: var(--mono); font-size: 10px; font-weight: 600;
  letter-spacing: 0.05em; text-transform: uppercase;
  padding: 2px 7px; border-radius: 3px; border: 1px solid;
}
.role-pill { background: var(--slate-50); color: var(--slate-600); border-color: var(--slate-200); }
.role-pill.role-subject { background: var(--purple-50); color: var(--purple-600); border-color: #ddd6fe; }
.role-pill.role-source  { background: var(--amber-50);  color: var(--amber-600); border-color: #fcd34d; }
.role-pill.role-target  { background: var(--red-50);    color: var(--red-600);   border-color: #fca5a5; }

.enrich-ok    { background: var(--green-50); color: var(--green-600); border-color: #6ee7b7; }
.enrich-info  { background: var(--blue-50); color: var(--blue-700); border-color: #93c5fd; }
.enrich-warn  { background: var(--amber-50); color: var(--amber-600); border-color: #fcd34d; }
.enrich-bad   { background: var(--red-50); color: var(--red-600); border-color: #fca5a5; }

.cat-pill { background: var(--slate-50); color: var(--slate-600); border-color: var(--slate-200); }
.cat-immediate    { background: var(--red-50); color: var(--red-600); border-color: #fca5a5; }
.cat-shortterm    { background: var(--amber-50); color: var(--amber-600); border-color: #fcd34d; }
.cat-preventative { background: var(--blue-50); color: var(--blue-700); border-color: #93c5fd; }

.owner-pill { background: var(--slate-100); color: var(--slate-700); border-color: var(--slate-200); }

.evidence-table td:first-child { color: var(--blue-700); font-family: var(--mono); font-weight: 600; }

.decision-card { border-left: 4px solid var(--purple-600); }
.pending { color: var(--amber-600); font-style: italic; }

/* Evidence tab banner */
.evidence-banner-card { border-left: 4px solid var(--blue-600); background: var(--blue-50); }
.evidence-hint {
  margin-top: 12px; font-size: 12.5px; color: var(--slate-600);
  font-style: italic; padding-top: 10px; border-top: 1px dashed var(--blue-100);
}

/* KQL blocks */
.kql-block {
  border: 1px solid var(--slate-200); border-radius: 6px; margin-bottom: 12px;
  overflow: hidden; background: var(--slate-50);
}
.kql-block summary {
  list-style: none; cursor: pointer;
  padding: 12px 16px; background: white;
  border-bottom: 1px solid var(--slate-200);
  display: flex; align-items: center; gap: 14px; font-size: 14px;
  transition: background 0.15s ease;
}
.kql-block summary::-webkit-details-marker { display: none; }
.kql-block summary::before {
  content: '▸'; color: var(--slate-400); font-size: 12px; transition: transform 0.15s ease;
}
.kql-block[open] summary::before { transform: rotate(90deg); }
.kql-block summary:hover { background: var(--slate-50); }
.kql-num { font-family: var(--mono); font-size: 12px; font-weight: 600; color: var(--blue-700); }
.kql-title { flex: 1; font-weight: 500; color: var(--slate-900); }
.kql-badge {
  font-family: var(--mono); font-size: 10px; font-weight: 600;
  letter-spacing: 0.05em; padding: 2px 7px; border-radius: 3px; border: 1px solid;
}
.kql-badge-lib   { background: var(--green-50); color: var(--green-600); border-color: #6ee7b7; }
.kql-badge-adhoc { background: var(--amber-50); color: var(--amber-600); border-color: #fcd34d; }
.kql-rows { font-family: var(--mono); font-size: 11.5px; color: var(--slate-500); white-space: nowrap; }
.kql-body { padding: 16px; }
.kql-meta { display: flex; flex-wrap: wrap; gap: 24px; font-size: 13px; color: var(--slate-600); margin-bottom: 8px; }
.kql-meta strong { color: var(--slate-700); font-weight: 500; }

pre {
  background: var(--slate-900); color: #e2e8f0; border-radius: 6px;
  padding: 14px 18px; overflow-x: auto; font-family: var(--mono);
  font-size: 12.5px; line-height: 1.55; margin: 6px 0;
}
pre code { background: transparent; border: none; color: inherit; padding: 0; font-size: inherit; }
pre.kql { border-left: 3px solid var(--blue-500); }

/* Result file links (the new approach — no embedded rows) */
.result-files {
  display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 8px;
}
@media (max-width: 700px) { .result-files { grid-template-columns: 1fr; } }
.result-file {
  background: white; border: 1px solid var(--slate-200);
  border-radius: 6px; padding: 14px 16px;
}
.result-file-label {
  font-family: var(--mono); font-size: 11px; font-weight: 600;
  letter-spacing: 0.06em; text-transform: uppercase;
  color: var(--slate-900); margin-bottom: 8px;
}
.result-file-hint {
  font-family: var(--sans); font-size: 11px; color: var(--slate-500);
  font-weight: 400; letter-spacing: 0; text-transform: none; margin-left: 4px;
}
.result-file-link { margin-bottom: 6px; }
.dl-btn {
  display: inline-flex; align-items: center; gap: 6px;
  background: var(--blue-600); color: white !important;
  padding: 6px 14px; border-radius: 4px;
  font-family: var(--mono); font-size: 12px; font-weight: 600;
  text-decoration: none; letter-spacing: 0.02em;
  transition: background 0.15s ease;
}
.dl-btn:hover { background: var(--blue-700); }
.result-file-path { font-size: 11.5px; color: var(--slate-500); }
.result-file-path code { font-size: 11px; background: transparent; border: none; padding: 0; color: var(--slate-500); }

.kql-integrity {
  display: flex; flex-wrap: wrap; gap: 24px;
  font-size: 12px; color: var(--slate-500);
  margin-top: 14px; padding-top: 12px; border-top: 1px dashed var(--slate-200);
}
.kql-integrity strong { color: var(--slate-700); font-weight: 500; }
.kql-integrity code { font-size: 11px; }

.audit-footer { background: var(--slate-50); border-style: dashed; }
.tool-calls { list-style: none; padding: 0; }
.tool-calls li { padding: 2px 0; }
.tool-calls code { font-size: 12px; }

@media print {
  body { background: white; font-size: 11pt; }
  .wrap { padding: 0; max-width: 100%; }
  .tabs { display: none; }
  .tab-panel { display: block !important; padding-top: 0; page-break-before: always; }
  .tab-panel:first-of-type { page-break-before: auto; }
  .tab-panel::before {
    content: attr(data-print-label); display: block;
    font-family: var(--mono); font-size: 10pt; letter-spacing: 0.1em;
    text-transform: uppercase; color: var(--slate-600);
    border-bottom: 1px solid var(--slate-200);
    padding-bottom: 6px; margin-bottom: 16px;
  }
  .card { page-break-inside: avoid; box-shadow: none; }
  .kql-block { page-break-inside: avoid; }
  details { display: block; }
  details[open] summary::before, details summary::before { display: none; }
  pre { background: var(--slate-50); color: var(--slate-900); border: 1px solid var(--slate-200); }
  .dl-btn { background: var(--slate-100); color: var(--slate-900) !important; border: 1px solid var(--slate-300); }
}
"""

JS = """
function activateTab(idx) {
  document.querySelectorAll('.tab').forEach((t, i) => t.classList.toggle('active', i === idx));
  document.querySelectorAll('.tab-panel').forEach((p, i) => p.classList.toggle('active', i === idx));
  history.replaceState(null, '', '#' + (idx === 0 ? 'summary' : 'evidence'));
}
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.tab').forEach((t, i) => {
    t.addEventListener('click', () => activateTab(i));
  });
  if (location.hash === '#evidence') activateTab(1);
});
"""


def render_html(v: dict[str, Any], report_path: Path) -> str:
    inc_id = esc(v.get("incidentId", "unknown"))
    title = f"Triage Report — {inc_id}"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(title)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>{CSS}</style>
</head>
<body>
<div class="wrap">

  <header class="report-header">
    <div class="eyebrow">SIEM Triage Report · {esc(v.get("skill", "incident-triage"))}</div>
    <h1>{esc(title)}</h1>
    <div class="subtitle">{esc(v.get("incidentTitle") or "")}</div>
  </header>

  <nav class="tabs" role="tablist">
    <button class="tab active" role="tab" aria-selected="true">
      <span class="tab-num">01</span> Summary &amp; Verdict
    </button>
    <button class="tab" role="tab" aria-selected="false">
      <span class="tab-num">02</span> Evidence Repository
    </button>
  </nav>

  <div class="tab-panel active" data-print-label="Tab 01 — Summary &amp; Verdict">
    {render_summary_tab(v)}
  </div>

  <div class="tab-panel" data-print-label="Tab 02 — Evidence Repository">
    {render_evidence_tab(v, report_path)}
  </div>

</div>
<script>{JS}</script>
</body>
</html>
"""


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate a two-tab HTML triage report from a verdict JSON.")
    ap.add_argument("verdict_json", type=Path, help="Path to verdict JSON (typically in temp/)")
    ap.add_argument("--reports-dir", type=Path, default=Path("reports"))
    args = ap.parse_args()

    verdict = json.loads(args.verdict_json.read_text(encoding="utf-8"))
    inc_id = (verdict.get("incidentId") or "unknown").replace("/", "_").replace("\\", "_")

    args.reports_dir.mkdir(parents=True, exist_ok=True)
    out = args.reports_dir / f"{inc_id}.html"
    out.write_text(render_html(verdict, out), encoding="utf-8")
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
