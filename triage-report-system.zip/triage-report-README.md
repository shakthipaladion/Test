# HTML Triage Report with Sidecar Evidence

Produces a two-tab HTML report from a verdict JSON file. The report
**references** full query results stored as sidecar CSV and JSON files
next to it, rather than embedding result rows in the HTML.

## Why this architecture

| Concern | How this design addresses it |
|---|---|
| Report file size | HTML stays small (typically 30–40 KB) — emailable, embeddable, fast to load |
| PII exposure | Full result data (which often contains PII) lives in separate files that follow your team's existing data-handling policies |
| Full auditability | Every KQL row and every TI lookup is preserved 1:1 — the sample-vs-full question doesn't arise |
| Tamper detection | Each sidecar file has a SHA-256 hash recorded in the verdict and the manifest |
| Tool flexibility | CSV opens in Excel for analyst review; JSON works for downstream automation |
| Long-term retention | The report stays human-readable years later; the sidecars stay machine-parseable |

## File layout produced

```
reports/
├── inc-2026-05-19-0042.html                              ← the report (30–40 KB)
└── inc-2026-05-19-0042-evidence/                         ← sidecar files
    ├── index.json                                        ← manifest of all files
    ├── query-01-failed-sign-ins-followed-by-success.csv  ← CSV for humans
    ├── query-01-failed-sign-ins-followed-by-success.json ← JSON for tooling
    ├── query-02-tenant-wide-ip-activity.csv
    ├── query-02-tenant-wide-ip-activity.json
    ├── enrichment-01-risky-user-alice.json
    ├── enrichment-02-auth-methods-alice.json
    ├── enrichment-03-virustotal-ip.json
    ├── enrichment-04-abuseipdb-ip.json
    └── enrichment-05-greynoise-ip.json
```

The report links to all of these with relative paths, so the bundle is
portable — you can move `reports/inc-.../` to a different location and
the links keep working as long as the directory stays together.

## Files in this delivery

| File | Purpose |
|---|---|
| `generate_html_report.py` | Generates the HTML report from a verdict JSON |
| `sidecar_writer.py` | Writes CSV/JSON sidecar files; called by the MCP server during a triage |
| `sample-verdict.json` | Full-featured example verdict showing the schema |
| `demo_full_flow.py` | End-to-end demo that runs the sidecar writer and report generator together |
| `outputs/demo/` | Pre-generated example output — open the HTML to see what an analyst sees |

## Usage

### 1. The MCP server writes evidence files as it works

The MCP server's `run_kql` and enrichment tools call `EvidenceWriter`:

```python
from sidecar_writer import EvidenceWriter

# Create once per triage at the start
writer = EvidenceWriter(incident_id="inc-2026-05-19-0042",
                        reports_dir="reports")

# Called every time the agent runs KQL
record = writer.write_kql_result(
    title="Failed sign-ins followed by successful auth",
    source="queries/identity/signin-failures-then-success.kql",
    query="<the KQL text>",
    rows=full_result_rows,  # all rows, not a sample
)
# record now contains: queryIndex, resultsCsvPath, resultsJsonPath,
# resultsSizeBytes, resultsSha256 — to embed in the verdict's kqlRun[]

# Called every time the agent does enrichment
record = writer.write_enrichment(
    target="203.0.113.42",
    source="virustotal",
    result=virustotal_api_response,
)

# Called once at the end
writer.finalize()  # writes index.json manifest
```

### 2. The agent assembles the verdict JSON

The `verdict-generation` skill (`.github/skills/verdict-generation/SKILL.md`)
collects the records returned by `EvidenceWriter` and assembles them into the
verdict JSON's `kqlRun[]` and `enrichmentResults[]` arrays.

### 3. The skill ends by generating the report

```bash
python scripts/generate_html_report.py temp/triage-<incidentId>.json
# → reports/<incidentId>.html
```

## Verdict JSON schema — what's new

The schema is mostly unchanged from the previous version. The differences
are in `kqlRun[]` and `enrichmentResults[]` and a few top-level fields.

### Top-level — new fields

```json
{
  "evidenceDirectory": "reports/inc-2026-05-19-0042-evidence/",
  "metadata": {
    "evidenceDirectory": "reports/inc-2026-05-19-0042-evidence/",
    "evidenceFileCount": 12
  }
}
```

### `kqlRun[]` — replaced `resultSample` with file references

**Old:**
```json
{
  "title": "...",
  "source": "...",
  "query": "...",
  "rowCount": 487,
  "resultSample": [{"col": "value", ...}]   // up to ~10 rows
}
```

**New:**
```json
{
  "queryIndex": 1,
  "title": "...",
  "source": "...",
  "timespan": "P7D",
  "executedAt": "2026-05-19T14:35:48Z",
  "rowCount": 487,
  "query": "...",
  "resultsCsvPath": "reports/inc-.../query-01-<slug>.csv",
  "resultsJsonPath": "reports/inc-.../query-01-<slug>.json",
  "resultsSizeBytes": 89432,
  "resultsSha256": "b7e3d2a8f1c9b4e6d5..."
}
```

### `enrichmentResults[]` — added file reference

**New:**
```json
{
  "target": "203.0.113.42",
  "source": "virustotal",
  "verdict": "clean",
  "details": "0/94 malicious detections, harmless score 70",
  "resultsJsonPath": "reports/inc-.../enrichment-03-virustotal-ip.json"
}
```

The `details` field is the short one-line summary; the full API response
lives in the JSON file.

## Tab 2 in detail

The Evidence Repository tab shows:

1. **Banner** explaining the sidecar architecture, with a link to the
   evidence directory and the `index.json` manifest.
2. **Enrichment results table** — one row per TI lookup, with a "JSON"
   link column to open the full raw response.
3. **KQL queries** — one collapsible block per query, containing:
   - The full query text (inline `<pre>` block, syntax highlighted)
   - Execution metadata (source, timespan, executed-at)
   - Two prominent download buttons: CSV and JSON
   - SHA-256 hash (truncated for display, full value in `title` attribute)
   - File size in human-readable units
4. **Audit metadata footer** — agent version, model, skills, tool calls,
   timing, paths to verdict JSON and evidence directory.

## Sidecar file formats

### CSV (`query-NN-<slug>.csv`)
- Excel-compatible UTF-8 CSV
- Header row with all columns seen across the result set
- Nested values (dicts, lists) are stringified as JSON in their cell
- Suitable for review in Excel, grep, awk, jq → tsv, etc.

### JSON (`query-NN-<slug>.json`)
```json
{
  "title": "...",
  "source": "...",
  "query": "...",
  "executedAt": "ISO 8601",
  "rowCount": 487,
  "rows": [
    {"col1": "...", "col2": {"nested": "value"}},
    ...
  ]
}
```

### Enrichment JSON (`enrichment-NN-<slug>.json`)
```json
{
  "target": "203.0.113.42",
  "source": "virustotal",
  "executedAt": "ISO 8601",
  "result": { /* full raw API response */ }
}
```

### Manifest (`index.json`)
```json
{
  "incidentId": "inc-2026-05-19-0042",
  "generatedAt": "ISO 8601",
  "fileCount": 12,
  "files": [
    {"kind": "kql", "queryIndex": 1, "title": "...", "source": "...",
     "rowCount": 12, "resultsCsvPath": "...", "resultsJsonPath": "...",
     "resultsSizeBytes": 4827, "resultsSha256": "..."},
    {"kind": "enrichment", "enrichmentIndex": 1, "target": "...",
     "source": "...", "resultsJsonPath": "...",
     "resultsSizeBytes": 296, "resultsSha256": "..."}
  ]
}
```

## Integrity verification

Any reviewer can verify a sidecar file matches the hash recorded in the
verdict:

```bash
sha256sum reports/inc-2026-05-19-0042-evidence/query-01-*.json
# Compare to verdict.kqlRun[0].resultsSha256
```

If a sidecar is missing or tampered with, the hash mismatch is detectable.

## Wiring into the agent

In `.github/skills/verdict-generation/SKILL.md`, the workflow gains two
steps:

1. **During triage:** the MCP server tools (`run_kql`, `enrich_ip`, etc.)
   call `EvidenceWriter` to persist their full results. The tool's return
   value to the agent includes the `resultsCsvPath` / `resultsJsonPath`
   fields, which the agent embeds in the verdict's `kqlRun[]` and
   `enrichmentResults[]` arrays.
2. **After verdict JSON is written:** run
   `python scripts/generate_html_report.py temp/triage-<id>.json` to
   produce the HTML report next to the sidecar evidence directory.

## Why both CSV and JSON

Analysts open CSV in Excel. Detection engineers and downstream automation
work with JSON. Producing both doubles the disk footprint of each result
set but eliminates a class of "I can't open this" friction. The CSV is
~30–40% of the JSON's size for typical KQL output, so the storage cost is
modest.

## Print-to-PDF behaviour

The print stylesheet treats Tab 2 the same as Tab 1, on a new page. The
download buttons render as outlined buttons (since they're useless on
paper). The full result data is not embedded in the printed PDF — the
file paths are what gets printed, which is correct: print is for the
summary record, not the bulk evidence.
