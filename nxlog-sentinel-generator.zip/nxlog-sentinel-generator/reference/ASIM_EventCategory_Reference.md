# ASIM Event Category Reference

Microsoft's **Advanced Security Information Model (ASIM)** is a normalised schema layer that lets you write queries that work across vendors. Every parser in this repo applies ASIM normalisation in its final phase.

## ASIM schemas (pick one per parser)

| Schema name | Use for | Example sources |
|---|---|---|
| `NetworkSession` | Firewall, IPS/IDS, proxy traffic | Palo Alto, Fortinet, Check Point, Cisco ASA |
| `AuthenticationEvent` | Logon/logoff events | Windows Security, Linux PAM, Okta, Azure AD |
| `ProcessEvent` | Process creation/termination | Sysmon, Defender for Endpoint, EDR |
| `FileEvent` | File create/modify/delete | Sysmon, DLP, EDR |
| `RegistryEvent` | Windows registry changes | Sysmon, Defender |
| `DnsActivity` | DNS query/response | DNS servers, network DNS sensors |
| `WebSession` | HTTP/HTTPS web traffic | Web proxies, WAFs, Zscaler |
| `AuditEvent` | Configuration changes | Azure AD audit, AWS CloudTrail, GCP audit |
| `UserManagement` | User/group creation, role changes | Azure AD, AD, Okta |

## Required ASIM fields (every parser sets these)

```kql
| extend
    EventVendor          = '<Vendor>',           // Always required
    EventProduct         = '<Product>',          // Always required
    EventSchema          = '<SchemaName>',       // From the table above
    EventSchemaVersion   = '0.2.6',              // Current version as of 2026
    EventCategory        = '<SchemaName>',       // Usually same as EventSchema
    EventResult          = case(...),            // Success | Failure | Partial | NA
    EventResultDetails   = '...'                 // Free-text reason
```

## Optional but useful ASIM fields

| Field | Set when |
|---|---|
| `EventStartTime` | Source provides session start (CEF `start`) |
| `EventEndTime` | Source provides session end (CEF `end`) |
| `EventOriginalUid` | Source has its own event ID (CEF `externalId`) |
| `EventOriginalSeverity` | Source has a severity field (CEF `Severity`) |
| `EventSeverity` | Mapped to ASIM scale: `Informational | Low | Medium | High` |
| `DvcAction` | Same as `DeviceAction` but ASIM-normalised |

## ASIM EventResult mapping

`EventResult` must be one of: `Success`, `Failure`, `Partial`, `NA`.

For network sessions (firewalls):

```kql
EventResult = case(
    Action in ('allow', 'permit', 'pass'), 'Success',
    Action in ('deny', 'drop', 'block', 'reject', 'reset'), 'Failure',
    'NA'
)
```

For authentication events:

```kql
EventResult = case(
    LogonType == 'success' or ResultType == '0', 'Success',
    LogonType == 'failure' or ResultType != '0', 'Failure',
    'NA'
)
```

For process events:

```kql
EventResult = case(
    ProcessExitCode == 0, 'Success',
    isnotnull(ProcessExitCode), 'Failure',
    'NA'
)
```

## Why this matters

Microsoft ships built-in analytic rules that target ASIM-normalised data (`_Im_NetworkSession()`, `_Im_AuthenticationEvent()`, etc.). When your parser applies ASIM, those rules light up automatically. When it doesn't, you have to write per-vendor versions of every detection.

Reference: https://learn.microsoft.com/en-us/azure/sentinel/normalization
