# NXLog Enterprise Edition Configuration Patterns

Reusable configuration blocks for NXLog EE. All examples assume **Enterprise Edition** — Community Edition does not support `xm_cef`, `xm_json`, or `om_azuremonitor`.

## File structure

A standard NXLog EE configuration is organised into four block types, each with a `Module` directive:

| Block type | Purpose | Common modules |
|---|---|---|
| `<Extension>` | Parsers, encoders, character set converters — invoked by other blocks | `xm_cef`, `xm_json`, `xm_syslog`, `xm_charconv` |
| `<Input>` | Source of log events | `im_tcp`, `im_udp`, `im_ssl`, `im_file`, `im_msvistalog`, `im_http` |
| `<Processor>` / `<Filter>` | Transform events between input and output | `pm_null`, `pm_filter`, `pm_transformer` |
| `<Output>` | Destination | `om_azuremonitor`, `om_file`, `om_tcp`, `om_ssl` |

Blocks are tied together with a `<Route>`:

```
<Route firewall_to_sentinel>
    Path firewall_input => parse_cef_logs => azure_monitor
</Route>
```

## Pattern 1 — CEF over TCP (no TLS)

```
<Extension cef_parser>
    Module xm_cef
</Extension>

<Input firewall_input>
    Module im_tcp
    ListenAddr [collector-ip]
    Port 514
    InputType LineBased
</Input>

<Processor parse_cef_logs>
    Module pm_null
    Exec parse_cef();
</Processor>

<Output azure_monitor>
    Module om_azuremonitor
    DcrEndpoint [dce-endpoint]
    DcrId [dcr-immutable-id]
    Stream Custom-CommonSecurityLog
    Table CommonSecurityLog
</Output>

<Route firewall_to_sentinel>
    Path firewall_input => parse_cef_logs => azure_monitor
</Route>
```

## Pattern 2 — CEF over TCP with mutual TLS

Use this when the source device supports client certificates (most modern firewalls do).

```
<Extension cef_parser>
    Module xm_cef
</Extension>

<Input firewall_input_tls>
    Module im_ssl
    ListenAddr [collector-ip]
    Port 6514
    CertFile %CERTDIR%/nxlog-server.crt
    CertKeyFile %CERTDIR%/nxlog-server.key
    CAFile %CERTDIR%/ca-bundle.crt
    RequireCert TRUE
    AllowUntrusted FALSE
    InputType LineBased
</Input>

<Processor parse_cef_logs>
    Module pm_null
    Exec parse_cef();
</Processor>

<Output azure_monitor>
    Module om_azuremonitor
    DcrEndpoint [dce-endpoint]
    DcrId [dcr-immutable-id]
    Stream Custom-CommonSecurityLog
    Table CommonSecurityLog
</Output>

<Route firewall_to_sentinel_tls>
    Path firewall_input_tls => parse_cef_logs => azure_monitor
</Route>
```

**Critical TLS notes:**
- `RequireCert TRUE` enforces mutual TLS — every client must present a cert signed by the CA in `CAFile`.
- `AllowUntrusted FALSE` rejects self-signed device certs unless they're in `CAFile` directly.
- `%CERTDIR%` is an NXLog macro pointing to `cert/` under the install root. On Linux: `/opt/nxlog/var/lib/nxlog/cert/`. On Windows: `C:\Program Files\nxlog\cert\`.
- Use port `6514` (RFC 5425 syslog-over-TLS) by convention; `514` is reserved for plain syslog.

## Pattern 3 — CEF over UDP

UDP is fire-and-forget and lossy. Use only when:
- The source device doesn't support TCP syslog.
- Network conditions are reliable (LAN, no packet loss).
- Event loss is acceptable for the data type.

```
<Input firewall_input_udp>
    Module im_udp
    ListenAddr [collector-ip]
    Port 514
    InputType LineBased
</Input>

# Parser, output, and route same as Pattern 1
```

UDP has **no TLS option**. If TLS is required, switch to Pattern 2.

## Pattern 4 — Plain syslog (RFC 3164/5424) — non-CEF

For network devices that emit plain syslog, not CEF:

```
<Extension syslog_parser>
    Module xm_syslog
</Extension>

<Input switch_input>
    Module im_udp
    ListenAddr [collector-ip]
    Port 514
    InputType LineBased
</Input>

<Processor parse_syslog>
    Module pm_null
    Exec parse_syslog();
</Processor>

<Output azure_monitor>
    Module om_azuremonitor
    DcrEndpoint [dce-endpoint]
    DcrId [dcr-immutable-id]
    Stream Custom-CiscoSwitchSyslog_CL
    Table CiscoSwitchSyslog_CL
</Output>

<Route switch_to_sentinel>
    Path switch_input => parse_syslog => azure_monitor
</Route>
```

`parse_syslog()` auto-detects RFC 3164 vs RFC 5424.

## Pattern 5 — JSON over HTTP API

For vendors that expose a REST API or push JSON over HTTPS:

```
<Extension json_parser>
    Module xm_json
</Extension>

<Input api_input>
    Module im_http
    ListenAddr [collector-ip]
    Port 8443
    HTTPSCertFile %CERTDIR%/nxlog-api.crt
    HTTPSCertKeyFile %CERTDIR%/nxlog-api.key
    HTTPSAllowUntrusted FALSE
</Input>

<Processor parse_json>
    Module pm_null
    Exec parse_json();
    Exec to_json();   # Re-serialise to canonical form before sending
</Processor>

<Output azure_monitor>
    Module om_azuremonitor
    DcrEndpoint [dce-endpoint]
    DcrId [dcr-immutable-id]
    Stream Custom-VendorAPI_CL
    Table VendorAPI_CL
</Output>

<Route api_to_sentinel>
    Path api_input => parse_json => azure_monitor
</Route>
```

## Pattern 6 — Windows Event Log

Windows-specific input — uses native Event Log API, not file-tail.

```
<Extension json_encoder>
    Module xm_json
</Extension>

<Input windows_eventlog>
    Module im_msvistalog
    Channel Security
    Query <QueryList>\
              <Query Id="0">\
                  <Select Path="Security">*</Select>\
              </Query>\
          </QueryList>
    Exec to_json();
</Input>

<Output azure_monitor>
    Module om_azuremonitor
    DcrEndpoint [dce-endpoint]
    DcrId [dcr-immutable-id]
    Stream Microsoft-SecurityEvent
    Table SecurityEvent
</Output>

<Route windows_to_sentinel>
    Path windows_eventlog => azure_monitor
</Route>
```

For multi-channel collection (Security + System + Application), expand the `<QueryList>` with multiple `<Select>` elements or use multiple `<Input>` blocks with different `Channel` values.

## Pattern 7 — Linux file tail with audit

```
<Extension json_encoder>
    Module xm_json
</Extension>

<Input linux_authlog>
    Module im_file
    File "/var/log/auth.log"
    SavePos TRUE
    ReadFromLast TRUE
    Recursive FALSE
    Exec to_json();
</Input>

<Input linux_auditlog>
    Module im_linuxaudit
    LoadConfig "/etc/audit/auditd.conf"
</Input>

<Output azure_monitor_syslog>
    Module om_azuremonitor
    DcrEndpoint [dce-endpoint]
    DcrId [dcr-immutable-id-syslog]
    Stream Microsoft-Syslog
    Table Syslog
</Output>

<Output azure_monitor_audit>
    Module om_azuremonitor
    DcrEndpoint [dce-endpoint]
    DcrId [dcr-immutable-id-audit]
    Stream Custom-LinuxAudit_CL
    Table LinuxAudit_CL
</Output>

<Route authlog_to_sentinel>
    Path linux_authlog => azure_monitor_syslog
</Route>

<Route auditlog_to_sentinel>
    Path linux_auditlog => azure_monitor_audit
</Route>
```

## `om_azuremonitor` — required parameters

Every output block targeting Azure Monitor needs all of these:

| Parameter | Purpose | Where to find it |
|---|---|---|
| `DcrEndpoint` | Data Collection Endpoint URL | Azure portal → Data Collection Endpoints → your DCE → Logs Ingestion endpoint |
| `DcrId` | Immutable ID of the DCR | Azure portal → Data Collection Rules → your DCR → JSON view → `properties.immutableId` |
| `Stream` | Stream declaration name | Must match `streamDeclarations` key in DCR ARM template exactly |
| `Table` | Target table | Friendly name; informational |

**Authentication:** `om_azuremonitor` uses Microsoft Entra app-only auth (client credentials flow). Configure once via:

```
om_azuremonitor.exe -t <tenant-id> -c <client-id> -s <client-secret>
```

This stores credentials in NXLog's secure store. The DCR endpoint must grant the **Monitoring Metrics Publisher** role to the app's service principal.

## Common configuration errors

1. **Module declaration missing.** Every `<Extension>`, `<Input>`, `<Processor>`, `<Output>` block must have a `Module` directive on the first line. Without it, NXLog skips the block silently.

2. **Stream name mismatch between NXLog and DCR.** The `Stream` parameter in `om_azuremonitor` must equal a key in `streamDeclarations` of the DCR. Mismatch = silent data loss.

3. **Wrong `om_azuremonitor` auth state.** If the app's secret expires or the role assignment is removed, NXLog logs `401 Unauthorized` to its own log, but the running process keeps trying. Monitor NXLog's internal log file.

4. **`InputType LineBased` missing on `im_tcp`/`im_udp`/`im_ssl`.** Without it, NXLog treats the stream as a single binary blob. Always set explicitly.

5. **`SavePos TRUE` missing on `im_file`.** Without it, NXLog re-reads the entire file on restart, double-ingesting events.

6. **Forward slashes in Windows paths.** NXLog requires backslashes on Windows config blocks: `C:\Program Files\nxlog\cert\server.crt`, not `C:/Program Files/...`.

7. **Sourcing certs from network share.** NXLog runs as `LocalSystem` on Windows and `nxlog` user on Linux. Network shares often aren't mounted for these accounts. Always copy certs to local disk.

## Validation

After deploying a config:

```bash
# Linux
sudo nxlog -t -c /opt/nxlog/etc/nxlog.conf

# Windows (PowerShell as Administrator)
& "C:\Program Files\nxlog\nxlog.exe" -t -c "C:\Program Files\nxlog\conf\nxlog.conf"
```

The `-t` flag does syntax validation only — no startup, no network connections. Always run before reloading the service.

For runtime checks, tail the NXLog internal log:
- Linux: `/opt/nxlog/var/log/nxlog/nxlog.log`
- Windows: `C:\Program Files\nxlog\data\nxlog.log`

Look for entries from `om_azuremonitor` confirming successful auth and ingestion.
