# Document Design Standards

The HTML integration guide template (`templates/html/starter.html`) implements all of these standards. This file documents the rules so they're enforced consistently when skills modify or extend the template.

## Typography

- **Font stack:** IBM Plex Sans (UI) and IBM Plex Mono (code), with system fallbacks.
- **Base size:** 16px on body; 13px in code blocks; 14px in tables and metadata.
- **Headings:** 32px / 22px / 18px for h1 / h2 / h3, with h2 having a bottom border.

## Colours (light mode)

| Variable | Value | Use |
|---|---|---|
| `--color-bg` | `#fafafa` | Page background |
| `--color-surface` | `#ffffff` | Content surface |
| `--color-border` | `#e0e0e0` | Dividers and borders |
| `--color-text` | `#161616` | Primary text |
| `--color-text-secondary` | `#525252` | Metadata, captions |
| `--color-accent` | `#0f62fe` | Primary action, links |
| `--color-success` | `#198038` | Success badges, validated callouts |
| `--color-warning` | `#f1c21b` | Warning callouts |
| `--color-danger` | `#da1e28` | Error callouts |
| `--color-code-bg` | `#f4f4f4` | Code block background |

## Code syntax-highlight spans

Use these CSS classes inside `<pre><code>` blocks:

| Class | Colour | Use for |
|---|---|---|
| `.cm` | `#6f6f6f` italic | Comments |
| `.kw` | `#0f62fe` 500 weight | Keywords (`az`, `where`, `extend`, etc.) |
| `.st` | `#198038` | String literals |
| `.vr` | `#8a3ffc` | Variables and parameters |
| `.fn` | `#da1e28` | Function names |
| `.nm` | `#525252` | Identifiers |
| `.tp` | `#d2a106` | Type annotations |

Example:
```html
<pre><code><span class="kw">az</span> deployment group create \
  --resource-group <span class="vr">[resource-group]</span> \
  --template-file <span class="st">"dcr.json"</span></code></pre>
```

## Floating toolbar

Every guide includes a fixed top-right toolbar with three buttons:

```html
<div class="toolbar">
  <button>Edit</button>
  <button class="primary">Save</button>
  <button>Cancel</button>
</div>
```

Buttons are placeholders for future per-doc edit functionality. The `.primary` button uses the accent colour.

## Placeholder convention

Every value that must be substituted at deploy time is wrapped in square brackets and styled with `.placeholder`:

```html
<span class="placeholder">[dcr-immutable-id]</span>
```

Standard placeholder names (always use these exact strings):

| Placeholder | Value |
|---|---|
| `[tenant-id]` | Microsoft Entra tenant ID |
| `[subscription-id]` | Azure subscription |
| `[workspace-id]` | Sentinel workspace GUID |
| `[workspace-resource-id]` | Full workspace resource ID |
| `[resource-group]` | Azure resource group |
| `[dce-endpoint]` | Data Collection Endpoint URL |
| `[dcr-immutable-id]` | DCR immutable ID |
| `[collector-ip]` | NXLog host IP |
| `[collector-port]` | NXLog listening port |
| `[device-ip]` | Source device IP (sample only) |
| `[device-hostname]` | Source device hostname (sample only) |
| `[sample-user]` | Sample user identifier |
| `[api-token]` | Generic API key/token placeholder |

## Callouts

Three callout types for inline notes:

```html
<div class="callout">…info…</div>
<div class="callout warning">…warning…</div>
<div class="callout danger">…critical…</div>
```

Use sparingly. The default integration guide has 0–3 callouts per section.

## Section structure

Every integration guide has exactly 9 sections in this order:

1. Overview (`#overview`)
2. Device-side configuration (`#device-config`)
3. NXLog EE configuration (`#nxlog-config`)
4. DCR ARM template (`#dcr-template`)
5. Field mapping (`#field-mapping`)
6. Sample logs (`#sample-logs`)
7. KQL parser function (`#parser`)
8. Validation queries (`#validation`)
9. Troubleshooting (`#troubleshooting`)

Section IDs are stable so you can deep-link from other docs.

## Tables

Standard table styling — full-width, alternating rows not used (single-line dividers only):

```html
<table>
  <thead><tr><th>Field</th><th>Type</th><th>Description</th></tr></thead>
  <tbody>
    <tr><td>...</td><td>...</td><td>...</td></tr>
  </tbody>
</table>
```

Do not nest tables. For complex data, use multiple side-by-side tables under h3 subheadings.

## Print-friendliness

The template intentionally avoids fixed heights, hover-only content, and JavaScript-required interactions, so the document prints well to PDF without modification. The toolbar uses `position: fixed` and is acceptable on print (most browsers omit it on print stylesheets via `@media print` — add this if needed).

## Accessibility

- All interactive elements have visible focus states (browser default sufficient).
- Colour is never the only signal — callouts use icons or labels alongside colour.
- Section IDs match heading text in kebab-case for predictable deep linking.
- Colour contrast meets WCAG AA on the chosen palette.
