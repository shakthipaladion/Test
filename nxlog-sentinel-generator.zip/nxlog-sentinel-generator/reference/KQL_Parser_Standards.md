# KQL Parser Function Standards

Every integration produces a KQL parser function in `outputs/<vendor>-<product>/parser.kql`. This document defines the structure and quality bar.

## Why parser functions matter

Sentinel's `CommonSecurityLog` and other shared tables are multi-tenant — every CEF source writes to the same table. Without a parser function:

- Analysts must write `where DeviceVendor == '...' and DeviceProduct == '...'` in every query.
- Vendor-specific extension fields stay buried in `AdditionalExtensions`, requiring `extract()` chains.
- ASIM normalisation isn't applied, breaking cross-product queries.

A parser function solves all three by exposing a clean, vendor-specific view that downstream queries call by name.

## Function signature

Every parser is a saved KQL function created at the **workspace** level:

```kql
.create-or-alter function with (
    folder = 'IntegrationParsers',
    docstring = '<Vendor> <Product> parser — extracts fields and applies ASIM',
    view = true,
    skipvalidation = false
) <Vendor><Product>_CL() {
    // Body here
}
```

Naming convention: `<Vendor><Product>_CL` — concatenated PascalCase, suffixed with `_CL` to mirror the custom-log convention.

Examples:
- `PaloAltoPanOS_CL()`
- `FortinetFortiGate_CL()`
- `CheckPointFirewall_CL()`
- `CiscoASA_CL()`

## Body structure (4 phases)

### Phase 1 — Filter to vendor/product

```kql
CommonSecurityLog
| where DeviceVendor == '<Vendor>'
| where DeviceProduct == '<Product>'
```

For custom `_CL` tables that aren't multi-tenant, this filter is omitted — the table itself is the filter.

### Phase 2 — Extract from AdditionalExtensions

For each vendor-specific field that downstream queries need:

```kql
| extend
    PolicyName = extract(@'PolicyName=([^;]+)', 1, AdditionalExtensions),
    RuleId = toint(extract(@'RuleId=([0-9]+)', 1, AdditionalExtensions)),
    ThreatCategory = extract(@'category=([^;]+)', 1, AdditionalExtensions)
```

**Rules:**
- Always anchor with the literal key name and `=`.
- Always cast to the correct type (`toint`, `tolong`, `todatetime`, `tobool`).
- For multi-word keys, escape special regex chars (`.`, `[`, `]`).
- Limit to 20 extractions per parser. Beyond that, performance degrades — promote to DCR `transformKql` instead.

### Phase 3 — Project-rename to consistent column names

```kql
| project-rename
    SrcIP = SourceIP,
    SrcPort = SourcePort,
    DstIP = DestinationIP,
    DstPort = DestinationPort,
    User = SourceUserName,
    Action = DeviceAction
```

This makes downstream queries portable across vendors. A junior analyst can write `<Vendor><Product>_CL() | summarize by SrcIP, User` without knowing the vendor's specific column naming.

### Phase 4 — Apply ASIM normalisation

```kql
| extend
    EventVendor = '<Vendor>',
    EventProduct = '<Product>',
    EventSchema = 'NetworkSession',          // Pick from ASIM_EventCategory_Reference.md
    EventSchemaVersion = '0.2.6',
    EventCategory = case(
        Action == 'allow', 'NetworkSession',
        Action == 'deny', 'NetworkSession',
        Action == 'block', 'NetworkSession',
        'NetworkSession'
    ),
    EventResult = case(
        Action == 'allow', 'Success',
        Action == 'deny', 'Failure',
        Action == 'block', 'Failure',
        'NA'
    ),
    EventResultDetails = Reason
```

ASIM normalisation enables Sentinel's built-in cross-product analytic rules. Always apply it.

## Worked example — Palo Alto

```kql
.create-or-alter function with (
    folder = 'IntegrationParsers',
    docstring = 'Palo Alto Networks PAN-OS parser — CommonSecurityLog → ASIM NetworkSession',
    view = true
) PaloAltoPanOS_CL() {
    CommonSecurityLog
    | where DeviceVendor == 'Palo Alto Networks'
    | where DeviceProduct == 'PAN-OS'
    | extend
        PolicyName = extract(@'PanOSRuleName=([^;]+)', 1, AdditionalExtensions),
        ThreatID = toint(extract(@'PanOSThreatID=([0-9]+)', 1, AdditionalExtensions)),
        ThreatCategory = extract(@'PanOSThreatCategory=([^;]+)', 1, AdditionalExtensions),
        VirtualSystem = extract(@'PanOSVsys=([^;]+)', 1, AdditionalExtensions),
        SessionID = tolong(extract(@'PanOSSessionID=([0-9]+)', 1, AdditionalExtensions))
    | project-rename
        SrcIP = SourceIP,
        SrcPort = SourcePort,
        DstIP = DestinationIP,
        DstPort = DestinationPort,
        User = SourceUserName,
        Action = DeviceAction,
        Application = ApplicationProtocol,
        BytesIn = ReceivedBytes,
        BytesOut = SentBytes
    | extend
        EventVendor = 'Palo Alto Networks',
        EventProduct = 'PAN-OS',
        EventSchema = 'NetworkSession',
        EventSchemaVersion = '0.2.6',
        EventCategory = 'NetworkSession',
        EventResult = case(
            Action == 'allow', 'Success',
            Action in ('deny', 'drop', 'reset-both'), 'Failure',
            'NA'
        ),
        EventResultDetails = iff(isnotempty(ThreatCategory), ThreatCategory, ''),
        DvcAction = Action
}
```

After deployment, an analyst queries:

```kql
PaloAltoPanOS_CL()
| where TimeGenerated > ago(1h)
| where Action == 'allow' and DstPort == 22
| summarize Connections = count() by SrcIP, DstIP
```

— vendor-specific knowledge encoded once in the parser, reused everywhere downstream.

## Performance considerations

### Performance rule 1 — Filter early

The first three lines of the parser must be the vendor filter. Never put `extend` before the `where` clauses; you'll process every row in `CommonSecurityLog` (potentially billions) before filtering.

### Performance rule 2 — Use `has` not `contains`

```kql
// Slow — full string scan
| where AdditionalExtensions contains 'PolicyName='

// Fast — indexed token search
| where AdditionalExtensions has 'PolicyName'
```

`has` uses Sentinel's term index; `contains` doesn't.

### Performance rule 3 — Limit `extract()` calls

Each `extract()` is a regex evaluation per row. 20 extractions × 10M rows = 200M regex evaluations. If you need more than 20 fields:

1. Promote the most-used 10 to `DeviceCustomString*` slots via DCR `transformKql`.
2. Keep the long tail in `AdditionalExtensions` and extract on-demand in queries that actually need them.

### Performance rule 4 — Avoid `parse_json` on `AdditionalExtensions`

`AdditionalExtensions` is a serialised key-value string, not JSON. Don't try `parse_json(AdditionalExtensions)` — it will fail. Use `extract()` or build a parser using `parse` with anchors.

## Type discipline

The default type of `extract()` is `string`. Always cast:

```kql
// Wrong — string comparison; "10" < "9"
| extend Severity = extract(...)
| where Severity > 5

// Right
| extend Severity = toint(extract(...))
| where Severity > 5
```

Type conversion failures (e.g., `toint('abc')`) silently produce `null`. Validate after extraction:

```kql
| extend SeverityInt = toint(extract(...))
| extend SeverityValid = isnotnull(SeverityInt)
| where SeverityValid == true
```

## Validation gate

Before saving any parser to `outputs/<vendor>-<product>/parser.kql`:

1. **Syntax validation** — call Sentinel Triage MCP's `RunAdvancedHuntingQuery` with the parser body inlined plus `| take 10`.
2. **Completeness check** — confirm the rows returned have non-null values in the extracted custom fields. Some null values are expected (not every event has every field), but if 100% of rows show `null` for a custom extraction, the regex is wrong.
3. **ASIM check** — confirm `EventVendor`, `EventProduct`, `EventCategory`, `EventResult` are populated.

Annotate the file header:

```kql
// VALIDATED 2026-05-05 — query returned 10 rows, all custom fields populated, ASIM applied.
```

## Updating an existing parser

When the vendor changes their CEF schema (firmware update, new event types):

1. Capture new sample logs.
2. Diff the new `AdditionalExtensions` content against the existing extractions.
3. Add new extractions; do not remove old ones immediately (other queries may depend on them).
4. Bump the parser docstring with the new version: `'PAN-OS parser — supports versions 10.x, 11.x, 12.0'`.
5. Re-validate.
6. Promote the updated parser to `library/cef/<vendor>-parser.kql` if substantial changes were made.

## Anti-patterns

- **Hardcoding column names from one ingestion path.** A parser that hardcodes `Computer` will break when the same data arrives via Defender for Endpoint (which uses `DeviceName`). Always use the canonical column name for the table.
- **Combining filtering and detection logic in the parser.** The parser exposes data; it doesn't decide what's bad. Filtering by severity threshold or whitelisting belongs in the analytic rule, not the parser.
- **Hardcoding time ranges.** Never put `where TimeGenerated > ago(1h)` in the parser. The caller chooses the range.
- **Using `let` for vendor names.** Inlined string literals are clearer than `let v = '...'; ... where DeviceVendor == v`.
