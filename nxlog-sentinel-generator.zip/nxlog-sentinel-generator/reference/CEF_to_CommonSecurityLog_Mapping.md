# CEF → CommonSecurityLog Mapping Reference

Authoritative mapping from CEF header fields and standard extensions to Microsoft Sentinel's `CommonSecurityLog` table columns. Used by the CEF integration skill in Phase 4 (field mapping) and Phase 6 (parser function).

## Section A — CEF header → CommonSecurityLog

The CEF header has the form:

```
CEF:<Version>|<DeviceVendor>|<DeviceProduct>|<DeviceVersion>|<DeviceEventClassID>|<Name>|<Severity>|<Extension>
```

| CEF header field | CommonSecurityLog column | Notes |
|---|---|---|
| `Version` | (not stored) | Always `0` for CEF v0. |
| `DeviceVendor` | `DeviceVendor` | Direct match. Always populated. |
| `DeviceProduct` | `DeviceProduct` | Direct match. Always populated. |
| `DeviceVersion` | `DeviceVersion` | Vendor's product/firmware version. |
| `DeviceEventClassID` | `DeviceEventClassID` | Vendor-specific event identifier. |
| `Name` | `Activity` | Human-readable event name. |
| `Severity` | `LogSeverity` | Numeric (0-10) or text — preserve as-is. |

## Section B — Standard CEF extensions → CommonSecurityLog

The following CEF extension keys have first-class columns in `CommonSecurityLog`. Anything in this list is parsed automatically by the Sentinel CEF connector — never put it in `AdditionalExtensions`.

### Network — sources and destinations

| CEF key | CommonSecurityLog column | Type | Notes |
|---|---|---|---|
| `src` | `SourceIP` | string | IPv4/IPv6. |
| `spt` | `SourcePort` | int | |
| `smac` | `SourceMACAddress` | string | |
| `shost` | `SourceHostName` | string | |
| `suser` | `SourceUserName` | string | |
| `suid` | `SourceUserID` | string | |
| `spriv` | `SourceUserPrivileges` | string | |
| `sntdom` | `SourceNTDomain` | string | |
| `sproc` | `SourceProcessName` | string | |
| `spid` | `SourceProcessId` | int | |
| `dst` | `DestinationIP` | string | |
| `dpt` | `DestinationPort` | int | |
| `dmac` | `DestinationMACAddress` | string | |
| `dhost` | `DestinationHostName` | string | |
| `duser` | `DestinationUserName` | string | |
| `duid` | `DestinationUserID` | string | |
| `dpriv` | `DestinationUserPrivileges` | string | |
| `dntdom` | `DestinationNTDomain` | string | |
| `dproc` | `DestinationProcessName` | string | |
| `dpid` | `DestinationProcessId` | int | |
| `dlat` | `DestinationGeoLatitude` | real | |
| `dlong` | `DestinationGeoLongitude` | real | |

### Network — protocols and traffic

| CEF key | CommonSecurityLog column | Type | Notes |
|---|---|---|---|
| `proto` | `Protocol` | string | TCP/UDP/ICMP/etc. |
| `app` | `ApplicationProtocol` | string | HTTP/HTTPS/SSH/etc. |
| `in` | `ReceivedBytes` | long | Inbound byte count. |
| `out` | `SentBytes` | long | Outbound byte count. |
| `cs5Label`/`cs5` | `DeviceCustomString5` (etc.) | string | See custom strings below. |

### Action and outcome

| CEF key | CommonSecurityLog column | Type | Notes |
|---|---|---|---|
| `act` | `DeviceAction` | string | Allow/Block/Drop/etc. |
| `outcome` | `EventOutcome` | string | Success/Failure. |
| `reason` | `Reason` | string | |

### URL / file / resource

| CEF key | CommonSecurityLog column | Type | Notes |
|---|---|---|---|
| `request` | `RequestURL` | string | |
| `requestMethod` | `RequestMethod` | string | GET/POST/etc. |
| `requestContext` | `RequestContext` | string | |
| `requestCookies` | `RequestCookies` | string | |
| `requestClientApplication` | `RequestClientApplication` | string | User-Agent. |
| `fname` | `FileName` | string | |
| `fsize` | `FileSize` | long | Bytes. |
| `fileHash` | `FileHash` | string | |
| `filePath` | `FilePath` | string | |
| `fileType` | `FileType` | string | |
| `oldFileName` | `OldFileName` | string | For rename events. |
| `oldFileSize` | `OldFileSize` | long | |
| `oldFilePath` | `OldFilePath` | string | |
| `oldFileType` | `OldFileType` | string | |
| `oldFileHash` | `OldFileHash` | string | |

### Time fields

| CEF key | CommonSecurityLog column | Type | Notes |
|---|---|---|---|
| `rt` | `ReceiptTime` | datetime | Event receipt time at agent. **Use `transformKql` to project this into `TimeGenerated`** when meaningful. |
| `start` | `StartTime` | datetime | |
| `end` | `EndTime` | datetime | |
| `art` | `AgentReceiptTime` | datetime | Agent's local receipt time. |

### Device-side metadata

| CEF key | CommonSecurityLog column | Type | Notes |
|---|---|---|---|
| `dvc` | `DeviceAddress` | string | Device IP. |
| `dvchost` | `DeviceName` | string | Device hostname. |
| `dvcmac` | `DeviceMacAddress` | string | |
| `deviceFacility` | `DeviceFacility` | string | Syslog facility. |
| `deviceInboundInterface` | `DeviceInboundInterface` | string | |
| `deviceOutboundInterface` | `DeviceOutboundInterface` | string | |
| `deviceDirection` | `CommunicationDirection` | string | 0=in, 1=out. |
| `externalId` | `ExternalID` | int | |

### Device custom fields (vendor-extensible slots)

`CommonSecurityLog` reserves 6 string, 6 number, 4 IPv6, and 6 floating-point custom-field pairs that the vendor uses for arbitrary purposes. The **label** column documents what the vendor put in the **value** column.

| CEF value key | CEF label key | Sentinel value column | Sentinel label column |
|---|---|---|---|
| `cs1` | `cs1Label` | `DeviceCustomString1` | `DeviceCustomString1Label` |
| `cs2` | `cs2Label` | `DeviceCustomString2` | `DeviceCustomString2Label` |
| `cs3` | `cs3Label` | `DeviceCustomString3` | `DeviceCustomString3Label` |
| `cs4` | `cs4Label` | `DeviceCustomString4` | `DeviceCustomString4Label` |
| `cs5` | `cs5Label` | `DeviceCustomString5` | `DeviceCustomString5Label` |
| `cs6` | `cs6Label` | `DeviceCustomString6` | `DeviceCustomString6Label` |
| `cn1` | `cn1Label` | `DeviceCustomNumber1` | `DeviceCustomNumber1Label` |
| `cn2` | `cn2Label` | `DeviceCustomNumber2` | `DeviceCustomNumber2Label` |
| `cn3` | `cn3Label` | `DeviceCustomNumber3` | `DeviceCustomNumber3Label` |
| `cfp1` | `cfp1Label` | `DeviceCustomFloatingPoint1` | `DeviceCustomFloatingPoint1Label` |
| `cfp2` | `cfp2Label` | `DeviceCustomFloatingPoint2` | `DeviceCustomFloatingPoint2Label` |
| `cfp3` | `cfp3Label` | `DeviceCustomFloatingPoint3` | `DeviceCustomFloatingPoint3Label` |
| `cfp4` | `cfp4Label` | `DeviceCustomFloatingPoint4` | `DeviceCustomFloatingPoint4Label` |
| `c6a1` | `c6a1Label` | `DeviceCustomIPv6Address1` | `DeviceCustomIPv6Address1Label` |
| `c6a2` | `c6a2Label` | `DeviceCustomIPv6Address2` | `DeviceCustomIPv6Address2Label` |
| `c6a3` | `c6a3Label` | `DeviceCustomIPv6Address3` | `DeviceCustomIPv6Address3Label` |
| `c6a4` | `c6a4Label` | `DeviceCustomIPv6Address4` | `DeviceCustomIPv6Address4Label` |

In the parser function, always check the `Label` column to confirm what the vendor stored before relying on the value column.

## Section C — Vendor extensions → AdditionalExtensions

Anything that doesn't appear in Section B lands in `AdditionalExtensions` as a serialised key-value list:

```
AdditionalExtensions = "CustomKey1=value1;CustomKey2=value2;..."
```

To extract these in the parser function, use `extract()` with anchored patterns:

```kql
| extend
    CustomKey1 = extract(@'CustomKey1=([^;]+)', 1, AdditionalExtensions),
    CustomKey2 = extract(@'CustomKey2=([^;]+)', 1, AdditionalExtensions)
```

**When to promote a custom field out of AdditionalExtensions:** if a vendor consistently sends a field that's queried often (e.g., `RuleName` for a firewall rule), and `AdditionalExtensions` is becoming bloated, project it into a Device Custom field via the DCR `transformKql` and document the projection in `field-mapping.md`.

## Section D — Securonix → Sentinel migration crosswalk

For users migrating from Securonix SNYPR to Sentinel, the following crosswalk maps Securonix's normalised parser output to `CommonSecurityLog` columns. Use this in Phase 4 of the CEF skill.

| Securonix field | CommonSecurityLog column |
|---|---|
| `sourceaddress` | `SourceIP` |
| `sourceport` | `SourcePort` |
| `destinationaddress` | `DestinationIP` |
| `destinationport` | `DestinationPort` |
| `accountname` | `SourceUserName` |
| `useridentifier` | `SourceUserID` |
| `eventoutcome` | `EventOutcome` |
| `eventaction` | `DeviceAction` |
| `eventseverity` | `LogSeverity` |
| `bytesin` | `ReceivedBytes` |
| `bytesout` | `SentBytes` |
| `protocol` | `Protocol` |
| `applicationprotocol` | `ApplicationProtocol` |
| `requesturl` | `RequestURL` |
| `filename` | `FileName` |
| `filehash` | `FileHash` |
| `devicehostname` | `DeviceName` |
| `deviceaddress` | `DeviceAddress` |
| `transactionstring1`/`2`/`3` | `DeviceCustomString1`/`2`/`3` |

Vendor-specific Securonix fields (anything starting with `customstring`, `transactionnumber`, `additionalinfo`) map to `AdditionalExtensions` in Sentinel and require explicit extraction in the parser.

## Section E — Things that are NOT in CommonSecurityLog

These are common log fields that **don't** have a native column. Always go to `AdditionalExtensions` or a custom field:

- `policyName` / `ruleName` (firewall rule that matched)
- `category` (vendor's threat category — phishing, malware, etc.)
- `signatureID` (vendor IPS/IDS signature ID)
- `confidenceLevel` / `riskScore`
- `threatId` / `threatName`
- `userAgent` (often goes to `RequestClientApplication` instead)
- `referer`
- `httpStatus`
- `tlsVersion` / `cipherSuite`
- `clientCommonName` / `serverCommonName`

If any of these are queried frequently in your environment, promote them to a `DeviceCustomString` slot via DCR `transformKql`.
