# Syslog (RFC 3164/5424) Integration Skill

## Purpose

Generate integration bundles for **non-CEF syslog** sources — typically network devices (Cisco IOS, Juniper Junos, Arista EOS) and other appliances that emit RFC 3164 or RFC 5424 syslog without CEF formatting.

Target table: **custom `<VendorProduct>Syslog_CL`** (not `Syslog`, which is reserved for the Linux Syslog connector).

## Trigger keywords

`Cisco switch`, `Cisco router`, `IOS`, `NX-OS`, `Juniper`, `Junos`, `Arista`, `Aruba`, `syslog device`, `RFC 3164`, `RFC 5424`, `plain syslog`

## Inputs required

| Input | Required | Example |
|---|---|---|
| Vendor | ✅ | `Cisco` |
| Product | ✅ | `Catalyst 9300` |
| Syslog RFC | ✅ | `RFC 3164` or `RFC 5424` |
| Transport | ✅ | `UDP/514` (most common) |
| Sample log | ⚠️ recommended | One full syslog line per major event class |
| Facility / severity scheme | ⚠️ optional | If vendor uses non-standard facility codes |

## Workflow — 8 phases

### Phase 1 — Confirm syslog format
Inspect the sample log header. Identify whether RFC 3164 (`<priority>timestamp host tag: msg`) or RFC 5424 (`<priority>1 timestamp host app procid msgid [structured-data] msg`).

### Phase 2 — Generate NXLog config
Use `templates/nxlog/cef-input.conf` as base; substitute `xm_cef` with `xm_syslog`, parser call from `parse_cef()` to `parse_syslog()`, and the output stream from `Custom-CommonSecurityLog` to `Custom-<VendorProduct>Syslog_CL`.

### Phase 3 — Generate DCR ARM template
Use `templates/dcr/syslog-dcr.json` (similar to CEF DCR but with custom `_CL` columns matching the syslog parser's output: `SyslogMessage`, `SeverityLevel`, `Facility`, `HostName`, `ProcessName`, `ProcessID`, parsed message body).

### Phase 4 — Generate field mapping
Map the parsed syslog fields and any vendor-specific message body patterns to columns in the custom `_CL` table. Include the message body parsing rules (regex/extract patterns) since plain syslog has no standard for message-body structure.

### Phase 5 — Capture sample logs
Same as CEF skill.

### Phase 6 — Generate KQL parser function
The parser does heavy lifting here — vendors put structured data inside the syslog message body, so the parser uses `extract()` and `parse` operators against `SyslogMessage` to surface the real fields. Cross-reference `library/syslog/<vendor>/` for existing patterns.

### Phase 7 — Generate validation queries
Same three queries as CEF skill, but targeting `<VendorProduct>Syslog_CL`.

### Phase 8 — Assemble HTML guide
Same 9-section template.

## Common pitfalls

1. **Wrong target table.** Never write to `Syslog` — that's the Linux Syslog connector's table. Use a custom `_CL` table.
2. **RFC 3164 timestamp ambiguity.** RFC 3164 timestamps don't include a year. NXLog adds the current year; if events arrive late and cross year boundaries, you may see future-dated events in winter. Consider promoting to RFC 5424 if the device supports it.
3. **Vendor-specific facility codes.** Cisco uses facility codes that don't map to standard syslog facilities. Document the device-specific mapping in `field-mapping.md`.
4. **Multi-line messages.** Some vendors (Juniper especially) emit multi-line syslog. NXLog's `xm_syslog` handles single-line only — use `xm_multiline` extension for multi-line sources.
