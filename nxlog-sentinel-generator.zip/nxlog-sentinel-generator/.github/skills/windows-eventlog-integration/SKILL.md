# Windows Event Log Integration Skill

## Purpose

Generate integration bundles for **Windows Security/System/Application Event Log** collection via NXLog EE's `im_msvistalog` module, targeting Sentinel's `SecurityEvent` and `Event` tables (or custom `_CL` tables for application channels).

## Trigger keywords

`Windows`, `Active Directory`, `Domain Controller`, `DC logs`, `Event ID`, `Security log`, `im_msvistalog`, `Windows Event Log`, `WEC`, `Windows Event Collector`

## Inputs required

| Input | Required | Example |
|---|---|---|
| Source role | ✅ | `Domain Controller`, `Member Server`, `Workstation`, `IIS web server` |
| OS version | ✅ | `Windows Server 2022` |
| Channels | ✅ | `Security`, `System`, `Microsoft-Windows-Sysmon/Operational` |
| Event IDs of interest | ⚠️ recommended | Filter list to reduce volume |
| Target Sentinel table | ✅ | `SecurityEvent` (filtered Security log) or `Event` (other channels) or custom `_CL` |
| Transport | ✅ | Direct (NXLog on each host) or via WEC (centralised) |

## Workflow — 8 phases

### Phase 1 — Determine target table

| Channel | Recommended Sentinel table |
|---|---|
| Security | `SecurityEvent` (use the AMA-equivalent column set) |
| System / Application | `Event` |
| Microsoft-Windows-Sysmon/Operational | Custom `WinSysmon_CL` |
| Application/IIS | Custom `IIS_CL` (or `W3CIISLog` for IIS access logs) |
| PowerShell operational | Custom `WinPowerShell_CL` |

### Phase 2 — Generate NXLog config

Use `templates/nxlog/windows-eventlog.conf` (to be created). Key sections:

```
<Extension json_encoder>
    Module xm_json
</Extension>

<Input windows_security>
    Module     im_msvistalog
    Channel    Security
    Query     <QueryList>...</QueryList>
    Exec       to_json();
</Input>

<Output azure_monitor>
    Module       om_azuremonitor
    DcrEndpoint  [dce-endpoint]
    DcrId        [dcr-immutable-id]
    Stream       Microsoft-SecurityEvent
    Table        SecurityEvent
</Output>
```

When using Windows Event Collector (WEC), NXLog runs on the WEC server reading from `ForwardedEvents` channel instead of `Security` directly.

### Phase 3 — Generate DCR ARM template

For `SecurityEvent` and `Event` tables, use `Microsoft-SecurityEvent` and `Microsoft-Event` streams (built-in, no streamDeclarations needed). For custom channels, declare custom streams.

### Phase 4 — Generate Event ID filter list

Document which Event IDs are forwarded vs filtered. Provide the user with a recommended baseline based on source role:

- **Domain Controllers:** 4624, 4625, 4634, 4647, 4648, 4672, 4720, 4722, 4724, 4725, 4726, 4738, 4740, 4756, 4767, 4768, 4769, 4771, 4776, 4781, 5136, 5141 (auth + directory changes).
- **Member Servers:** 4624, 4625, 4634, 4648, 4672, 4688, 4697, 4698, 7045 (auth + service/process).
- **Workstations:** 4624, 4625, 4634, 4647, 4648, 4672, 4688, 4697, 7045, 1102 (Security log clear).

Include justification for each Event ID (what it detects + typical noise level).

### Phase 5 — Capture sample events

Use `wevtutil qe Security /c:5 /f:xml` to capture sample XML; convert to JSON for parser testing.

### Phase 6 — Generate KQL parser function

For `SecurityEvent`, use the built-in column set (`Account`, `LogonType`, `IpAddress`, etc.). For custom `_CL` tables holding `EventData` JSON, the parser extracts named fields with `parse_json(EventData) | extend ...`.

### Phase 7 — Validation queries

Same three (volume, parser coverage, field completeness) but with Windows-specific event types.

### Phase 8 — HTML guide

Same 9-section template.

## Common pitfalls

1. **Channel access permissions.** NXLog must run as `LocalSystem` or a member of `Event Log Readers` to read the Security channel. Service account workarounds frequently fail.
2. **Event ID 4688 process command line.** Off by default. Enable via Group Policy: *Audit Process Creation* + *Include command line in process creation events*.
3. **Sysmon channel name.** It's `Microsoft-Windows-Sysmon/Operational`, with the slash, exactly as written.
4. **WEC subscription scope.** If using Windows Event Collector, the subscription must explicitly forward the channels NXLog will read. WEC default subscriptions don't include Security.
5. **Volume blowout.** Unfiltered Security collection on a busy DC can produce 10K+ events/sec. Always filter at the source via the `<QueryList>` clause; don't rely on DCR `transformKql` alone.
6. **Time skew.** NXLog uses event-generated time, not received time. If a host has wrong local time, events show up in the wrong bucket. Validate NTP sync as part of onboarding.
