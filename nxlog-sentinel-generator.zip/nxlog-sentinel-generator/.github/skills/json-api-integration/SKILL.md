# JSON / REST API Integration Skill

## Purpose

Generate integration bundles for **vendor REST APIs** that expose JSON event feeds — CrowdStrike Falcon Streaming API, Zscaler ZIA Nanolog Streaming Service (NSS), Okta System Log API, and similar.

Target table: typically a custom `<VendorProduct>Events_CL` table with rich JSON-derived columns.

## Trigger keywords

`CrowdStrike`, `Falcon Streaming`, `Zscaler`, `ZIA`, `ZPA`, `NSS`, `Okta API`, `Okta System Log`, `REST API`, `JSON ingestion`, `im_http`, `webhook`

## Inputs required

| Input | Required | Example |
|---|---|---|
| Vendor | ✅ | `CrowdStrike` |
| API name | ✅ | `Falcon Streaming API` |
| Auth method | ✅ | `OAuth 2.0 client credentials` / `API key` / `mTLS` |
| Push or pull | ✅ | `Push (vendor → us)` or `Pull (us → vendor)` |
| Endpoint URL | ✅ | `https://firehose.crowdstrike.com/sensors/entities/datafeed/v2` |
| Sample event | ✅ | One full JSON document |
| Rate limit | ⚠️ optional | Vendor's documented event rate |

## Workflow — 8 phases

### Phase 1 — Determine push vs pull architecture

**Push (webhook):** vendor calls our endpoint. NXLog uses `im_http` to receive.

**Pull:** NXLog initiates HTTPS calls on a schedule. Use `im_pythonscript` or a sidecar collector (e.g., a small Python service that posts to NXLog's `im_http` listener).

Most modern SaaS vendors prefer push for high-volume feeds. Pull is reserved for vendors that don't support webhooks.

### Phase 2 — Generate NXLog config

For push:
```
<Extension json_parser>
    Module xm_json
</Extension>

<Input api_input>
    Module               im_http
    ListenAddr           [collector-ip]
    Port                 8443
    HTTPSCertFile        %CERTDIR%/api-receiver.crt
    HTTPSCertKeyFile     %CERTDIR%/api-receiver.key
    HTTPSAllowUntrusted  FALSE
</Input>

<Processor parse_json>
    Module pm_null
    Exec parse_json();
</Processor>

<Output azure_monitor>
    Module       om_azuremonitor
    DcrEndpoint  [dce-endpoint]
    DcrId        [dcr-immutable-id]
    Stream       Custom-VendorEvents_CL
    Table        VendorEvents_CL
</Output>
```

For pull, document a sidecar Python service (provide template) that authenticates, paginates, and posts to NXLog.

### Phase 3 — Generate DCR ARM template

Custom `_CL` table. Columns derived from the JSON document's structure — flatten one level deep for common paths, leave nested objects as `dynamic` columns.

### Phase 4 — Generate field mapping

For each JSON path, document the target column. Example for CrowdStrike Falcon:

| JSON path | _CL column | Type |
|---|---|---|
| `metadata.eventType` | `EventType` | string |
| `metadata.eventCreationTime` | `TimeGenerated` | datetime |
| `event.UserName` | `User` | string |
| `event.ComputerName` | `DeviceName` | string |
| `event.DetectName` | `DetectionName` | string |
| `event.Severity` | `Severity` | int |
| (entire event object) | `RawEvent` | dynamic |

### Phase 5 — Sample logs

Store representative events per `eventType` value.

### Phase 6 — KQL parser

Custom `_CL` parsers don't need filtering by vendor (the table is the filter). Apply `project-rename` and ASIM normalisation. For nested fields kept as `dynamic`, use `[] | parse_json()` pattern in the parser.

### Phase 7 — Validation queries

Standard three.

### Phase 8 — HTML guide

Standard template with extra notes on auth setup in Section 2 (device-side).

## Common pitfalls

1. **OAuth token refresh.** For pull integrations, NXLog can't natively refresh OAuth 2.0 access tokens. Use a sidecar that handles auth and forwards events, or use `im_pythonscript` with a custom auth wrapper.

2. **JSON document depth.** Sentinel's `dynamic` columns work but become awkward beyond 3-4 nesting levels. Flatten aggressively in the parser.

3. **Backpressure on push feeds.** `im_http` has a finite queue. If NXLog can't keep up with the vendor's push rate, requests start failing. Monitor NXLog's queue depth and scale up the collector tier (more NXLog hosts behind a load balancer) for high-volume feeds (>10K events/sec).

4. **mTLS vs API key auth.** CrowdStrike and a few others require mTLS even on the receiving side; most others use bearer tokens or HMAC signatures. Document explicitly which auth pattern this vendor uses.

5. **Schema drift.** SaaS APIs change schemas without warning. Add a column-completeness validation query that alerts when known columns drop below a threshold filled-rate.

6. **TimeGenerated source.** Always pull `TimeGenerated` from the event's own timestamp field (`eventCreationTime`, `published`, `eventTime`), not from arrival time. SaaS APIs frequently buffer events; arrival-time analysis breaks correlations with on-prem events.
