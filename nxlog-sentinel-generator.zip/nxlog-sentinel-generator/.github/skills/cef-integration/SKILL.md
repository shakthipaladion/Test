# CEF Integration Skill

## Purpose

Generate complete, production-ready Microsoft Sentinel integration bundles for any vendor that emits **Common Event Format (CEF)** logs over syslog (TCP/UDP, with or without TLS), forwarded by **NXLog Enterprise Edition** to a Data Collection Rule that lands in the `CommonSecurityLog` table.

Typical vendors covered by this skill:

- Palo Alto Networks (PAN-OS)
- Fortinet (FortiGate, FortiAnalyzer)
- Cisco ASA / Firepower / FTD
- Check Point (R80+)
- F5 BIG-IP
- CyberArk PAM
- Trend Micro Deep Security
- Imperva WAF
- Any other vendor with a `CEF:0|Vendor|Product|Version|...` header

## Trigger keywords

`Palo Alto`, `PAN-OS`, `Panorama`, `Fortinet`, `FortiGate`, `FortiAnalyzer`, `Cisco ASA`, `Cisco Firepower`, `FTD`, `Check Point`, `F5`, `BIG-IP`, `CyberArk`, `PAM`, `CEF`, `Common Event Format`, `CommonSecurityLog`

## Inputs required from user

Before generating anything, confirm you have all of these. Ask in a single message if any are missing.

| Input | Required | Example |
|---|---|---|
| Vendor name | ✅ | `Palo Alto Networks` |
| Product name | ✅ | `PA-5260 NGFW` |
| Product version | ⚠️ optional | `PAN-OS 11.1` |
| Log format confirmation | ✅ | `CEF` (must be RFC-compliant) |
| Transport | ✅ | `TCP/514` or `UDP/514` |
| TLS | ✅ | `Yes — mTLS with PSK` or `No` |
| Sample log | ⚠️ recommended | A real CEF line for header verification |
| Custom CEF extensions used | ⚠️ optional | Lists vendor-specific keys not in the standard mapping |

If the user provides a sample log, **inspect the header before proceeding**. The first segment must read `CEF:0|<Vendor>|<Product>|...`. If it doesn't, this is not a CEF integration — switch to `syslog-integration` and inform the user.

## Workflow — 8 phases

### Phase 1 — Confirm CEF compliance and target table

1. If the user provided a sample log, parse the header. Confirm:
   - Starts with `CEF:0|` (CEF version 0).
   - Has exactly 7 pipe-delimited header fields before the extension key-value pairs.
   - Extension section uses `key=value` pairs separated by spaces (with `\=` for literal equals inside values).
2. If the header doesn't match, stop and tell the user. Suggest the `syslog-integration` skill instead.
3. Confirm target table is `CommonSecurityLog`. Confirm DCR stream is `Microsoft-CommonSecurityLog`.
4. Read `reference/CEF_to_CommonSecurityLog_Mapping.md` — keep it open for Phase 5.

### Phase 2 — Generate NXLog EE configuration

1. Load `templates/nxlog/cef-input.conf`.
2. Substitute the input block based on transport:
   - **TCP without TLS** → `Module im_tcp` + `ListenAddr` + `Port`
   - **TCP with TLS** → `Module im_ssl` + cert paths + `RequireCert TRUE` for mTLS
   - **UDP** → `Module im_udp` (note: no TLS option for UDP)
3. Add the parser block:
   ```
   <Extension cef_parser>
       Module xm_cef
   </Extension>

   <Processor parse_cef_logs>
       Module pm_null
       Exec parse_cef();
   </Processor>
   ```
4. Add the output block:
   ```
   <Output azure_monitor>
       Module om_azuremonitor
       DcrEndpoint [dce-endpoint]
       DcrId [dcr-immutable-id]
       Stream Custom-CommonSecurityLog
       Table CommonSecurityLog
   </Output>
   ```
   Note: the stream name in `om_azuremonitor` must exactly match `streamDeclarations` in the DCR ARM template (Phase 3).
5. Add the route tying input → processor → output.
6. Validate the config syntax mentally (NXLog uses Apache-style block syntax). Common errors:
   - Missing module declaration above an `<Extension>` block.
   - Mismatched stream names between NXLog and DCR.
   - Wrong cert path format (forward vs back slashes).
7. Write to `outputs/<vendor>-<product>/nxlog.conf`.

### Phase 3 — Generate DCR ARM template

1. Load `templates/dcr/cef-dcr.json`.
2. Set `streamDeclarations`:
   ```json
   "streamDeclarations": {
     "Custom-CommonSecurityLog": {
       "columns": [ /* CommonSecurityLog schema columns */ ]
     }
   }
   ```
3. Set `dataFlows`:
   ```json
   "dataFlows": [{
     "streams": ["Custom-CommonSecurityLog"],
     "destinations": ["[workspace-resource-id]"],
     "transformKql": "source | where DeviceVendor == '<Vendor>' | project-rename TimeGenerated = ReceiptTime",
     "outputStream": "Microsoft-CommonSecurityLog"
   }]
   ```
4. Always include a `transformKql` even if minimal — at minimum, project `TimeGenerated` and filter by `DeviceVendor` to prevent cross-vendor noise from this DCR.
5. Set `destinations.logAnalytics[]` to reference the user's workspace resource ID via parameter substitution.
6. Use the standard parameter set: `dataCollectionEndpointId`, `dataCollectionRuleName`, `location`, `workspaceResourceId`.
7. Write to `outputs/<vendor>-<product>/dcr-arm-template.json`.

### Phase 4 — Generate Securonix → Sentinel field mapping

1. Open `reference/CEF_to_CommonSecurityLog_Mapping.md`. This is the master map of CEF keys to `CommonSecurityLog` columns.
2. Build a markdown table with three sections:
   - **Section A — Standard CEF header fields → CommonSecurityLog**: `DeviceVendor`, `DeviceProduct`, `DeviceVersion`, `DeviceEventClassID`, `Activity`, `LogSeverity` from the CEF header.
   - **Section B — Standard CEF extensions → CommonSecurityLog columns**: `src` → `SourceIP`, `dst` → `DestinationIP`, `suser` → `SourceUserName`, etc. (50+ rows from the reference file).
   - **Section C — Vendor-specific extensions → AdditionalExtensions**: anything the vendor sends that isn't in the standard mapping. Each goes into `AdditionalExtensions` as `key=value;key=value;...` and must be extracted in the parser function (Phase 6).
3. Add a fourth section showing **Securonix field → equivalent Sentinel column** for migration teams. Use the user's existing Securonix parser if they reference one.
4. Write to `outputs/<vendor>-<product>/field-mapping.md`.

### Phase 5 — Capture sample logs

1. If the user provided sample logs, store them under `outputs/<vendor>-<product>/sample-events/` (one file per major event type, named `<event-type>.log`).
2. If no samples were provided, write a placeholder note in `field-mapping.md` reminding the operator to capture samples during deployment for parser validation.

### Phase 6 — Generate KQL parser function

1. Search `library/cef/` for any existing parser for this vendor. If found, branch from it.
2. If not, load `templates/kql/cef-parser-template.kql`.
3. Build the parser as a stored function:
   ```kql
   .create-or-alter function with (folder='IntegrationParsers', view=true)
   <Vendor><Product>_CL() {
       CommonSecurityLog
       | where DeviceVendor == '<Vendor>'
       | where DeviceProduct == '<Product>'
       | extend
           // Extract vendor-specific fields from AdditionalExtensions
           CustomField1 = extract(@'CustomField1=([^;]+)', 1, AdditionalExtensions),
           CustomField2 = extract(@'CustomField2=([^;]+)', 1, AdditionalExtensions)
       | project-rename
           // Rename to consistent column names
           SrcIP = SourceIP,
           DstIP = DestinationIP,
           User = SourceUserName
   }
   ```
4. Add ASIM normalisation per `reference/ASIM_EventCategory_Reference.md`:
   - Set `EventVendor`, `EventProduct`, `EventCategory`, `EventSchema`, `EventSchemaVersion`.
   - Map `EventResult` to `Success` / `Failure` / `Partial` / `NA` based on the source's success/failure indicator.
5. **Validate via Sentinel Triage MCP**: call `RunAdvancedHuntingQuery` with the parser body (the inline form, since the user may not have the function deployed yet) plus `| take 10`. Confirm:
   - Query runs without errors.
   - Returns rows (if the vendor is already onboarded; if not, document this as expected).
   - Extracted custom fields are non-null in at least some rows.
6. Annotate the final file with `// VALIDATED <YYYY-MM-DD>` if validation succeeds.
7. Write to `outputs/<vendor>-<product>/parser.kql`.

### Phase 7 — Generate validation queries

Three queries, in order. All target `CommonSecurityLog` filtered for this vendor.

**1. Ingestion volume sanity** — confirm data is arriving and at expected volume:
```kql
CommonSecurityLog
| where TimeGenerated > ago(24h)
| where DeviceVendor == '<Vendor>' and DeviceProduct == '<Product>'
| summarize EventsPerHour = count() by bin(TimeGenerated, 1h)
| render timechart
```

**2. Parser coverage** — what % of vendor events parse successfully into known fields:
```kql
CommonSecurityLog
| where TimeGenerated > ago(1h)
| where DeviceVendor == '<Vendor>'
| extend HasParsedSrc = isnotempty(SourceIP), HasParsedAct = isnotempty(Activity)
| summarize 
    Total = count(),
    ParsedSrcIP = countif(HasParsedSrc),
    ParsedActivity = countif(HasParsedAct),
    Coverage_SrcIP_Pct = round(100.0 * countif(HasParsedSrc) / count(), 2),
    Coverage_Activity_Pct = round(100.0 * countif(HasParsedAct) / count(), 2)
```

**3. Field completeness** — for the top 10 most-used fields, what % of events have non-null values:
```kql
CommonSecurityLog
| where TimeGenerated > ago(1h)
| where DeviceVendor == '<Vendor>'
| summarize 
    Total = count(),
    FilledSrcIP = round(100.0 * countif(isnotempty(SourceIP)) / count(), 2),
    FilledDstIP = round(100.0 * countif(isnotempty(DestinationIP)) / count(), 2),
    FilledUser = round(100.0 * countif(isnotempty(SourceUserName)) / count(), 2),
    FilledAction = round(100.0 * countif(isnotempty(DeviceAction)) / count(), 2),
    FilledSeverity = round(100.0 * countif(isnotempty(LogSeverity)) / count(), 2)
```

Validate all three via Sentinel Triage MCP. Write to `outputs/<vendor>-<product>/validation-queries.kql` with section headers and validation timestamps.

### Phase 8 — Assemble HTML integration guide

1. Load `templates/html/starter.html`.
2. Populate the eight standard sections in order:
   1. **Overview** — vendor, product, version, log format, table, transport, DCR endpoint placeholder.
   2. **Device-side configuration** — vendor-specific steps (e.g., Palo Alto: System → Server Profiles → Syslog → CEF format → log forwarding profile → security policy).
   3. **NXLog EE config** — embed the full nxlog.conf with syntax highlighting (use the `.cm .kw .st .vr .fn .nm .tp` spans per `reference/Document_Design_Standards.md`).
   4. **DCR ARM template** — embed the full dcr-arm-template.json.
   5. **Field mapping** — embed the field-mapping.md table.
   6. **Sample logs** — embed sample CEF lines if available.
   7. **KQL parser function** — embed parser.kql.
   8. **Validation queries** — embed validation-queries.kql.
3. Apply the design system from `reference/Document_Design_Standards.md`:
   - IBM Plex font stack
   - Floating Edit / Save / Cancel toolbar (top right)
   - All sample values use `[placeholder]` convention
4. Write to `outputs/<vendor>-<product>/integration-guide.html`.

### Phase 9 (optional) — Generate .docx

Only if the user explicitly requests Word format.

1. Run `python scripts/html_to_docx.py outputs/<vendor>-<product>/integration-guide.html`.
2. Output: `outputs/<vendor>-<product>/integration-guide.docx`.

---

## Validation gates (must pass before declaring done)

- [ ] All six required files exist in `outputs/<vendor>-<product>/`.
- [ ] No real IPs, hostnames, or credentials anywhere.
- [ ] DCR ARM template is valid JSON.
- [ ] NXLog config has no module declaration errors (manual mental check; offer `nxlog -t -c ...` instructions to user).
- [ ] All three validation KQL queries run without errors via Sentinel Triage MCP.
- [ ] Parser function annotated with `// VALIDATED <date>`.
- [ ] HTML opens in a browser without broken styling.

---

## Common pitfalls (CEF-specific)

1. **Vendor uses "CEF-like" but isn't RFC-compliant.** Older Cisco ASA versions, some Trend Micro products, and certain network appliances label their output "CEF" but emit non-compliant headers (wrong field count, missing version prefix, escaped pipes in unexpected places). **Always inspect the sample log before generating.** If non-compliant, switch to `syslog-integration`.

2. **AdditionalExtensions overflow.** When a vendor sends >100 custom CEF extensions, the parser becomes brittle and slow. Symptoms: parser KQL takes >30 seconds on small datasets, regex extracts intermittently fail. **Solution:** identify the top 20 most-used custom fields and promote them to a custom `_CL` table via `transformKql` projection in the DCR. Document this in `field-mapping.md`.

3. **Wrong stream name in `om_azuremonitor` block.** The stream in NXLog (`Stream Custom-CommonSecurityLog`) must **exactly** match the key in DCR `streamDeclarations`. A common typo is `Custom-CommonsecurityLog` (lower-case 's'). NXLog will accept the config and send data; the DCR will silently drop it. **No error visible to operator.** Always grep both files for the same string.

4. **Missing `\=` escaping in CEF extensions.** When a value contains an equals sign (e.g., `request=https://example.com/path?q=1`), the vendor must escape it as `request=https://example.com/path?q\=1`. If they don't, NXLog's `parse_cef()` will misinterpret the field boundary. **Detection:** unusually high `AdditionalExtensions` length on subset of events. **Mitigation:** raise as ticket with vendor; in the meantime, add a `transformKql` filter to drop or truncate the malformed events.

5. **TimeGenerated vs ReceiptTime confusion.** `CommonSecurityLog.TimeGenerated` is when Sentinel ingested the event; `CommonSecurityLog.ReceiptTime` is when the agent received it. For most analytics, `TimeGenerated` is fine. For latency analysis, you need both. **Always set `transformKql` to `project-rename TimeGenerated = ReceiptTime`** if the vendor's CEF includes a meaningful `rt` (receipt time) field — otherwise you're querying ingestion time, not event time.

6. **TLS cert chain mismatch.** When `RequireCert TRUE` is set in NXLog, the device's cert must be signed by a CA NXLog trusts. Self-signed device certs require explicit `CAFile` referencing the device cert directly. **Document this clearly in the device-side configuration section.**

7. **DCR endpoint vs DCR rule confusion.** NXLog needs *both* a Data Collection Endpoint (DCE) URL *and* the immutable ID of the Data Collection Rule. They are two separate Azure resources. Operators frequently substitute one for the other. **In the HTML guide's device config section, screenshot exactly where to find both in the Azure portal.**

---

## Promotion to library

When this skill produces a parser that's worth reusing across multiple vendors, ask the user:

> "The parser function we just built includes useful patterns for handling AdditionalExtensions overflow and ASIM normalisation. Want me to copy it to `library/cef/<vendor>-parser.kql` so future integrations can branch from it?"

Always copy with the metadata header pattern:

```kql
// <Vendor> <Product> CEF Parser
// Tables: CommonSecurityLog
// Keywords: <vendor>, <product>, cef, ngfw, firewall
// MITRE: (n/a — this is a parser, not a detection)
// Validated: <YYYY-MM-DD>
// Source: outputs/<vendor>-<product>/parser.kql
```
