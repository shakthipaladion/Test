# Linux Syslog Integration Skill

## Purpose

Generate integration bundles for **Linux endpoints (RHEL/Ubuntu/Debian/CentOS)** collecting via NXLog EE's `im_file` (auth.log, secure, syslog) and `im_linuxaudit` (Linux Audit Framework).

Target tables:
- **`Syslog`** — for `/var/log/auth.log` and `/var/log/syslog` content (the Sentinel built-in table).
- **`LinuxAudit_CL`** — for auditd structured records (custom table).

## Trigger keywords

`Linux`, `RHEL`, `Ubuntu`, `Debian`, `CentOS`, `auth.log`, `secure`, `syslog`, `auditd`, `Linux Audit`, `Linux Audit Framework`, `journald`

## Inputs required

| Input | Required | Example |
|---|---|---|
| Distribution | ✅ | `RHEL 9`, `Ubuntu 22.04 LTS` |
| Audit framework in use | ✅ | `auditd`, `journald`, both |
| auditd rules in place | ⚠️ optional | Path to `/etc/audit/audit.rules` if available |
| Log paths | ✅ | `/var/log/auth.log`, `/var/log/secure`, `/var/log/audit/audit.log` |
| Transport | ✅ | NXLog on each host (preferred) or central syslog forwarding |

## Workflow — 8 phases

### Phase 1 — Determine target tables

| Source | Target table |
|---|---|
| `/var/log/auth.log` (Debian/Ubuntu) | `Syslog` |
| `/var/log/secure` (RHEL/CentOS) | `Syslog` |
| `/var/log/syslog` or `/var/log/messages` | `Syslog` |
| auditd `/var/log/audit/audit.log` | Custom `LinuxAudit_CL` |
| journald | Custom `LinuxJournald_CL` (if not piped to syslog) |

### Phase 2 — Generate NXLog config

Use Pattern 7 from `reference/NXLog_EE_Config_Patterns.md`:
- `im_file` for auth.log/secure/syslog with `SavePos TRUE`
- `im_linuxaudit` for auditd with `LoadConfig "/etc/audit/auditd.conf"`
- Two separate output blocks targeting different DCRs

Critical: `SavePos TRUE` prevents re-ingesting on restart. `ReadFromLast TRUE` skips historical content on first start.

### Phase 3 — Generate DCR ARM templates (two)

One DCR per target table:
- DCR for `Syslog` uses built-in `Microsoft-Syslog` stream.
- DCR for `LinuxAudit_CL` declares a custom stream with auditd's record-type schema.

### Phase 4 — Generate field mapping

For Syslog output:
- `auth.log` lines map to `Syslog.SyslogMessage`; the message body needs parsing via the parser function (sshd, sudo, su, login, PAM events).

For auditd output:
- Each `type=` record (USER_AUTH, USER_LOGIN, USER_ROLE_CHANGE, EXECVE, PATH, SYSCALL, etc.) becomes a row.
- Audit fields like `auid`, `uid`, `pid`, `exe`, `cmd`, `success` extracted via parser.

### Phase 5 — Recommend auditd rules

If user doesn't have an audit ruleset, recommend a baseline targeting:
- `-w /etc/passwd -p wa -k identity`
- `-w /etc/shadow -p wa -k identity`
- `-w /etc/sudoers -p wa -k privilege_escalation`
- `-w /var/log/auth.log -p wa -k log_tampering`
- `-a always,exit -F arch=b64 -S execve -k exec`
- `-a always,exit -F arch=b64 -S connect -F a2=10 -k network`

(Reference: Auditd Best Practice rules, e.g., from Neo23x0/auditd or CIS benchmarks. Always defer to org's existing CIS/STIG mapping.)

### Phase 6 — Generate parsers

Two parsers — one for Syslog (auth.log content), one for LinuxAudit_CL.

`LinuxSyslogAuth_CL()` — extracts SSH login attempts from `Syslog`:

```kql
Syslog
| where Computer matches regex '...'
| where SyslogMessage has_any ('sshd', 'sudo', 'su:', 'login:')
| extend
    AuthEvent = case(
        SyslogMessage has 'Accepted password', 'success_password',
        SyslogMessage has 'Accepted publickey', 'success_pubkey',
        SyslogMessage has 'Failed password', 'failure_password',
        SyslogMessage has 'session opened', 'session_opened',
        'other'
    ),
    User = extract(@'for (\S+)', 1, SyslogMessage),
    SrcIP = extract(@'from (\S+)', 1, SyslogMessage)
```

`LinuxAudit_CL()` — straight pass-through with project-rename and ASIM normalisation.

### Phase 7 — Validation queries

Three queries × two tables = six validation queries.

### Phase 8 — HTML guide

Standard template; sections 6 and 7 split into Syslog and Audit subsections.

## Common pitfalls

1. **Distribution-specific log paths.** Debian/Ubuntu uses `/var/log/auth.log`; RHEL/CentOS uses `/var/log/secure`. Don't assume.
2. **journald replacing rsyslog.** Modern distributions may not write `/var/log/auth.log` at all — content lives in journald. Either configure journald to forward to syslog or use NXLog's `im_systemd` module (EE).
3. **auditd dispatcher conflicts.** Only one audit-dispatcher process can read `/var/log/audit/audit.log` at a time. NXLog `im_linuxaudit` registers itself as the dispatcher. If `auditd` already has a dispatcher (e.g., audisp-remote), use file tail instead.
4. **Audit volume on busy systems.** `-a always,exit -S execve` produces hundreds of events per second on a busy host. Filter by user (`-F auid>=1000`) or by sensitive paths only.
5. **Permission requirements.** NXLog reads `/var/log/audit/audit.log` requires either running as root or membership in the `audit` group with appropriate file ACLs.
