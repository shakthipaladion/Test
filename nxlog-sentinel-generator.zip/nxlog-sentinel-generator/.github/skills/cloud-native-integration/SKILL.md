# Cloud-Native Integration Skill

## Purpose

Generate integration bundles for **cloud-native log sources** that **do NOT use NXLog** — Azure AD/Entra ID, Microsoft 365, AWS CloudTrail, GCP Cloud Audit, Office 365 Activity. These sources connect via Sentinel's native data connectors (Diagnostic Settings, Codeless Connector Platform, or built-in CCF connectors).

This skill exists to keep the integration documentation library complete even when NXLog isn't part of the path.

## Trigger keywords

`Azure AD`, `Entra ID`, `M365`, `Office 365`, `AWS CloudTrail`, `GuardDuty`, `GCP Cloud Audit`, `Google Workspace`, `Salesforce`, `cloud-native`, `data connector`

## Inputs required

| Input | Required | Example |
|---|---|---|
| Cloud platform | ✅ | `Azure AD`, `AWS`, `GCP` |
| Log type | ✅ | `SigninLogs`, `AuditLogs`, `CloudTrail`, etc. |
| Connector type | ✅ | `Diagnostic Settings`, `CCF`, `Codeless`, `Logic Apps` |
| Target table(s) | ✅ | `SigninLogs`, `AuditLogs`, `AWSCloudTrail`, `GCPAuditLogs`, etc. |
| Authentication scope | ✅ | App registration, Workload Identity Federation, IAM role |

## Workflow — modified phases (no NXLog)

### Phase 1 — Confirm connector path

| Source | Native connector | Fallback |
|---|---|---|
| Azure AD / Entra ID | Diagnostic Settings → Sentinel | n/a |
| Office 365 | Native O365 connector | M365 Defender connector for security data |
| AWS CloudTrail | AWS S3 connector (CCF) | Logic Apps + S3 reader |
| AWS GuardDuty | AWS S3 connector (CCF) | EventBridge → Lambda → Logic Apps |
| GCP Cloud Audit | GCP Pub/Sub connector | Logic Apps + Pub/Sub reader |
| Google Workspace | Workspace API connector | Logic Apps + Reports API |
| Salesforce | Codeless Connector Platform | Logic Apps + REST API |

### Phase 2 — No NXLog config

Document that NXLog is not used. Provide the equivalent: Diagnostic Settings JSON, CCF YAML, or Logic Apps deployment template depending on path.

### Phase 3 — DCR may not exist

Some native connectors don't expose a DCR (Azure AD diagnostic settings, AWS S3 connector). For those, document the connector configuration instead. For Codeless connectors, the YAML serves the same purpose as a DCR.

### Phase 4 — Field mapping

Map source fields to Sentinel column names. For Azure AD's `SigninLogs`, the schema is fully documented by Microsoft — link to the doc and copy the relevant subset into the field mapping.

### Phase 5 — Sample events

Capture via Azure portal Log Analytics or AWS Console.

### Phase 6 — KQL parser function

Often unnecessary for built-in tables (`SigninLogs`, `AuditLogs`) — they're already well-structured. Useful for `AWSCloudTrail` (which has nested `additionalEventData` JSON) and Logic-Apps-ingested data.

### Phase 7 — Validation queries

Adapted to the source — for Azure AD, validation is "did diagnostic settings actually fire on a recent login?".

### Phase 8 — HTML guide

Section 3 (NXLog config) is replaced with **Connector configuration** showing the relevant native setup steps.

## Common pitfalls

1. **Diagnostic Settings vs. data connector.** Azure AD has both — Diagnostic Settings sends logs to Log Analytics; the Sentinel connector wires up Sentinel features on top. Both must be configured.

2. **Multi-tenant Azure AD.** If the customer has multiple tenants (e.g., dev and prod tenants), each needs its own diagnostic setting. Don't assume one connector covers all.

3. **AWS S3 connector latency.** The S3 polling connector has 5-15 minute latency; near-real-time isn't possible without EventBridge + Logic Apps.

4. **GCP Pub/Sub permissions.** The GCP connector needs the correct IAM bindings (`roles/pubsub.subscriber` on the subscription and `roles/iam.workloadIdentityUser` on the federated identity). Easy to miss; results in silent failure.

5. **Codeless connector deployment.** CCF YAML must be deployed via the Sentinel content hub, not directly via ARM. Document the deployment path explicitly.

6. **Costs.** Cloud-native log sources can produce vast volumes (Azure AD non-interactive sign-ins are notorious). Cost estimation is part of the integration document — provide a query the user can run before turning the connector on to estimate volume.
