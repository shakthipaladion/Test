# Virtualisation Integration Skill

## Purpose

Generate integration bundles for **virtualisation platforms** — VMware vSphere (ESXi hosts and vCenter Server), Hyper-V, and Nutanix AHV. These platforms emit a mix of syslog (host events, VM lifecycle) and JSON/REST API logs (vCenter audit, configuration changes).

Target tables: typically custom `_CL` tables — `VMwareESXi_CL`, `VMwareVCenter_CL`, `HyperV_CL`.

## Trigger keywords

`VMware`, `vSphere`, `ESXi`, `vCenter`, `Hyper-V`, `Nutanix`, `AHV`, `hypervisor`, `virtualisation`

## Inputs required

| Input | Required | Example |
|---|---|---|
| Platform | ✅ | `VMware vSphere 8` |
| Components | ✅ | `ESXi hosts`, `vCenter Server`, both |
| Log format per component | ✅ | ESXi → syslog UDP/514; vCenter → REST API or syslog |
| Transport | ✅ | UDP/514 from ESXi; HTTPS pull for vCenter audit |
| vCenter version | ⚠️ for VMware | Affects API endpoint structure |
| Authentication | ⚠️ for API pull | Local user vs vCenter SSO vs SAML |

## Workflow — 8 phases

### Phase 1 — Determine architecture

VMware typically requires **two integrations side-by-side**:
1. **ESXi hosts → syslog** — host events, VM lifecycle, vmkernel events. Use `syslog-integration` skill pattern with custom `VMwareESXi_CL` table.
2. **vCenter audit → API or syslog** — privileged user actions, config changes, role assignments. Use `json-api-integration` skill pattern with custom `VMwareVCenter_CL` table.

Hyper-V is collected via Windows Event Log (`Microsoft-Windows-Hyper-V-*` channels), so use the `windows-eventlog-integration` skill instead.

### Phase 2 — Generate NXLog configs

ESXi side:
```
<Input esxi_syslog>
    Module     im_udp
    ListenAddr [collector-ip]
    Port       514
</Input>

<Processor parse_esxi>
    Module pm_null
    Exec parse_syslog();
</Processor>
```

vCenter side: depends on whether vCenter forwards via syslog (configured in vCenter UI under *Administration → System Configuration → Services → Syslog*) or via API pull.

### Phase 3 — DCR ARM templates

Two custom `_CL` tables — one per source.

### Phase 4 — Field mapping

For ESXi: vmkernel logs, hostd logs, VPXa logs, and DCUI events all interleave. The parser separates them by examining the message tag.

For vCenter: parse the audit event categories (sessions, VM operations, host operations, role/permission changes, advanced settings).

### Phase 5 — Sample events

Store one example per major event class:
- ESXi: VM power on/off, VM clone, vMotion start/end, datastore change, security event.
- vCenter: user login, role assignment, VM clone (audit-side), permission change, VM template deployment.

### Phase 6 — KQL parsers

Two parsers: `VMwareESXi_CL()` and `VMwareVCenter_CL()`. Both apply ASIM `AuditEvent` schema where appropriate (config changes) or `NetworkSession` (network-level events).

### Phase 7 — Validation queries

Six total — three per source.

### Phase 8 — HTML guide

Template extended to handle two parallel integrations under one document; explicitly section by component (3a/3b for NXLog, 4a/4b for DCR, etc.).

## Common pitfalls

1. **ESXi syslog volume.** Default ESXi syslog config is verbose. Configure `Syslog.global.logLevel` and per-component log levels to reduce noise (`vmkernel.logLevel = info` not `debug`).

2. **vCenter time skew.** Mixed environments where vCenter and ESXi hosts disagree on time produce events that look out-of-order. Always validate NTP across the cluster as part of onboarding.

3. **vCenter audit ≠ vCenter event log.** vCenter has both: the *event log* contains operational events (good for capacity planning); the *audit log* contains security-relevant actions (privileged user actions). For SOC use, you almost always want audit, not event.

4. **API throttling on vCenter.** vCenter REST API has rate limits (~30 requests/sec by default). Pull frequency must respect this.

5. **VM events dwarf host events.** A vSphere cluster produces 10x more VM-level events than host-level. If volume is a concern, scope down with `transformKql` to keep only key VM lifecycle events (power on, power off, clone, snapshot, migrate).

6. **Hyper-V via WMI vs Event Log.** Hyper-V offers two collection paths. Always prefer Event Log (via `windows-eventlog-integration`) — WMI-based collection is unreliable and lacks structured fields.
