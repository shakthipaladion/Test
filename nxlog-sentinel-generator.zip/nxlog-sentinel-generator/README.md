# NXLog → Microsoft Sentinel Integration Generator

A repeatable framework for onboarding security data sources into Microsoft Sentinel via **NXLog Enterprise Edition (EE)** and **Azure Monitor Data Collection Rules (DCR)**, powered by **GitHub Copilot in VS Code Agent Mode** and the **Microsoft Sentinel MCP servers**.

> **Scope:** integration mechanics only — getting data in correctly and parsed correctly. Threat detections, hunting queries, and analytic rules are out of scope and live in a separate detection-engineering project.

## What you get out of this repo

For every supported integration archetype, a single Copilot prompt produces a complete, deployable bundle:

| Artefact | Purpose |
|---|---|
| `nxlog.conf` | NXLog EE configuration — input, parser, output to DCR endpoint |
| `dcr-arm-template.json` | Deployable ARM template for the Data Collection Rule |
| `field-mapping.md` | Securonix field → Sentinel column mapping table |
| `parser.kql` | KQL parser function (saved or stored) for downstream queries |
| `validation-queries.kql` | Ingestion health, parser coverage, field completeness |
| `integration-guide.html` | Single-file HTML reference document with embedded styling |
| `integration-guide.docx` | Optional Word version for formal handover |

All artefacts are written directly to `outputs/<vendor>-<product>/` — no copy-paste from chat.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│              GitHub Copilot — VS Code Agent Mode                │
├─────────────────────────────────────────────────────────────────┤
│              .github/copilot-instructions.md                    │
│       (Skill detection, universal patterns, output rules)       │
├─────────────────────────────────────────────────────────────────┤
│                  .github/skills/*/SKILL.md                      │
│        (One per integration archetype — 7 total)                │
├─────────────────────────────────────────────────────────────────┤
│                  reference/  +  templates/                      │
│   (Knowledge base + reusable NXLog/DCR/KQL/HTML skeletons)      │
├─────────────────────────────────────────────────────────────────┤
│                          MCP Servers                            │
│  ┌──────────────────┐ ┌──────────────────┐ ┌─────────────────┐  │
│  │ Sentinel Triage  │ │ Sentinel Data    │ │ KQL Search MCP  │  │
│  │ (validate KQL)   │ │ Exploration      │ │ (table schema)  │  │
│  └──────────────────┘ └──────────────────┘ └─────────────────┘  │
│  ┌──────────────────┐ ┌──────────────────┐                      │
│  │ Microsoft Learn  │ │ Azure MCP        │                      │
│  │ (latest docs)    │ │ (deploy DCR)     │                      │
│  └──────────────────┘ └──────────────────┘                      │
└─────────────────────────────────────────────────────────────────┘
```

## Quick start

### Prerequisites

| Requirement | Notes |
|---|---|
| **VS Code 1.99+** | Agent mode + MCP support. Insiders recommended. |
| **GitHub Copilot** | Pro+, Business, or Enterprise — Agent mode enabled. |
| **Python 3.8+** | For the HTML→DOCX converter and DCR validator. |
| **Node.js 18+** | For KQL Search MCP (`npx`). |
| **Azure CLI** | For DCR deployment. `az login --tenant <tid>`. |
| **Sentinel workspace** | Workspace ID + tenant ID + subscription ID. |
| **Defender XDR / Sentinel** | Onboarded to the unified Defender portal — required for the Triage MCP. |
| **Security Reader role** | Both Entra (directory) and unified RBAC in `security.microsoft.com`. |

### 60-second setup

```bash
# 1. Clone
git clone <your-fork-url> nxlog-sentinel-generator
cd nxlog-sentinel-generator

# 2. Configure
cp .vscode/mcp.json.template .vscode/mcp.json
cp config.json.template config.json
# Edit config.json with your workspace ID, tenant ID, subscription ID

# 3. Open in VS Code
code .

# 4. In VS Code: Ctrl+Shift+I to open Copilot Chat → switch to Agent mode
# 5. First time only: sign in to Microsoft when prompted (Sentinel MCP auth)
```

### First integration — try Palo Alto NGFW

In Copilot Chat (Agent mode), paste:

```
Build the Palo Alto Networks PA-5260 NGFW integration following project standards.
Log format: CEF over TCP/514 (TLS optional).
Sample log: see docs/samples/palo-alto-cef-sample.log
Output: full bundle to outputs/palo-alto-ngfw/
```

Copilot will load `cef-integration/SKILL.md`, walk through the 8 phases, and write the bundle to disk. The KQL parser is auto-validated against your live workspace.

### Available skills

Each skill detects intent from natural-language keywords; you don't have to name the skill explicitly.

| Skill | Trigger keywords | Use for |
|---|---|---|
| **cef-integration** | "Palo Alto", "Fortinet", "Cisco ASA", "Check Point", "F5", "CyberArk", "CEF integration" | Any vendor with confirmed CEF support |
| **syslog-integration** | "Cisco switch", "router", "syslog device", "RFC 3164", "RFC 5424" | Network devices using plain RFC syslog |
| **windows-eventlog-integration** | "Windows", "Active Directory", "DC", "Event ID", "im_msvistalog" | Windows hosts via Event Log |
| **linux-syslog-integration** | "Linux", "RHEL", "Ubuntu", "auth.log", "auditd" | Linux endpoints |
| **json-api-integration** | "CrowdStrike", "Zscaler", "REST API", "JSON ingestion" | Vendors with JSON over HTTPS APIs |
| **virtualisation-integration** | "VMware", "vSphere", "ESXi", "vCenter", "Hyper-V" | Virtualisation platforms |
| **cloud-native-integration** | "Azure AD", "Entra", "M365", "AWS CloudTrail" | Cloud-native log sources (no NXLog) |

## Repository layout

```
nxlog-sentinel-generator/
├── .github/
│   ├── copilot-instructions.md      # Universal patterns, skill routing
│   └── skills/                      # 7 specialised integration workflows
├── .vscode/
│   └── mcp.json.template            # MCP server config (Sentinel + Azure + Learn)
├── config.json.template             # Per-tenant config (workspace ID, etc.)
├── reference/                       # Knowledge base — never modified per-integration
│   ├── ASIM_EventCategory_Reference.md
│   ├── CEF_to_CommonSecurityLog_Mapping.md
│   ├── NXLog_EE_Config_Patterns.md
│   ├── Document_Design_Standards.md
│   └── KQL_Parser_Standards.md
├── templates/                       # Reusable skeletons substituted by skills
│   ├── nxlog/                       # NXLog EE config blocks (CEF, syslog, JSON, TLS)
│   ├── dcr/                         # DCR ARM template skeletons
│   ├── kql/                         # Parser function templates
│   └── html/                        # Single-file HTML guide starter
├── library/                         # Verified KQL — searched before writing new
│   ├── cef/
│   ├── syslog/
│   ├── windows/
│   ├── linux/
│   ├── json-api/
│   ├── virtualisation/
│   └── cloud/
├── outputs/                         # Generated bundles, one folder per integration
├── scripts/                         # Python utilities
│   ├── html_to_docx.py              # Convert HTML guide to Word
│   ├── validate_dcr.py              # ARM schema check + best-practice lints
│   └── deploy_integration.ps1       # az deployment + NXLog config push
└── docs/
    └── samples/                     # Reference sample logs per vendor
```

## How skills work (mental model)

1. You ask Copilot a natural-language question — e.g., *"Build the Palo Alto NGFW integration following project standards"*.
2. Copilot reads `.github/copilot-instructions.md` and detects keywords → loads the appropriate `SKILL.md`.
3. The skill defines an explicit workflow — phases, file outputs, validation gates.
4. Copilot uses MCP servers to look up Sentinel table schemas, validate KQL, and (optionally) deploy the DCR.
5. Generated files land in `outputs/<vendor>-<product>/` under version control. You diff, review, and ship.

## Adding a new vendor under an existing archetype

You don't need to author a new skill if the vendor fits an existing archetype (CEF, syslog, JSON-API, etc.). Just provide:

- Vendor name
- Product name and version
- Confirmed log format
- Transport (TCP/UDP, port, TLS)
- Sample log

Copilot reuses the same skill and produces the bundle. Promotions happen only when a genuinely new pattern emerges (e.g., a vendor with a unique binary protocol).

## Promoting a one-off integration to a reusable skill

After you build something novel, ask Copilot:

> "Convert the integration we just built into a new SKILL.md following the pattern in `.github/skills/cef-integration/`. Include the verified KQL we ran, the schema pitfalls we hit, and a step-by-step workflow."

Copilot extracts the workflow, codifies it into `SKILL.md`, and registers the new trigger keywords in `copilot-instructions.md`.

## License

MIT. See `LICENSE`.

## Acknowledgements

Architecture inspired by [Chris Stelzer's security-investigator](https://github.com/SCStelz/security-investigator) — a Microsoft Senior Cybersecurity Specialist's open-source SOC investigation framework. The skills/MCP composition pattern is reused with permission of the author's licensing.
