# Palo Alto Networks PAN-OS — Field Mapping

**Source:** Palo Alto Networks PA-5260 NGFW running PAN-OS 11.x
**Target table:** `CommonSecurityLog`
**Parser function:** `PaloAltoPanOS_CL()`

---

## A. CEF header → CommonSecurityLog

| CEF header field | Example value | CommonSecurityLog column |
|---|---|---|
| `DeviceVendor` | `Palo Alto Networks` | `DeviceVendor` |
| `DeviceProduct` | `PAN-OS` | `DeviceProduct` |
| `DeviceVersion` | `11.1.0` | `DeviceVersion` |
| `DeviceEventClassID` | `TRAFFIC` / `THREAT` / `SYSTEM` / `CONFIG` | `DeviceEventClassID` |
| `Name` (event name) | `allow` / `deny` / `alert` / `block-url` / `wildfire-deliver` | `Activity` |
| `Severity` | `1`–`10` | `LogSeverity` |

---

## B. Standard CEF extensions → CommonSecurityLog (auto-mapped)

These are parsed natively by the Sentinel CEF connector — no parser intervention needed.

| CEF extension | CommonSecurityLog column | Notes |
|---|---|---|
| `rt` | (projected to `TimeGenerated` via DCR transform) | Receipt time at firewall |
| `src` | `SourceIP` | |
| `spt` | `SourcePort` | |
| `dst` | `DestinationIP` | |
| `dpt` | `DestinationPort` | |
| `suser` | `SourceUserName` | User-ID mapped username |
| `proto` | `Protocol` | |
| `app` | `ApplicationProtocol` | App-ID name |
| `act` | `DeviceAction` | allow / deny / drop / block-url / etc. |
| `in` | `ReceivedBytes` | |
| `out` | `SentBytes` | |
| `request` | `RequestURL` | URL filtering events |
| `requestMethod` | `RequestMethod` | |
| `requestClientApplication` | `RequestClientApplication` | User-Agent |
| `fname` | `FileName` | WildFire / file blocking |
| `filePath` | `FilePath` | |
| `fileHash` | `FileHash` | |
| `deviceFacility` | `DeviceFacility` | Zone (untrust / trust / dmz) |

---

## C. Palo Alto custom fields → DeviceCustomString slots

PAN-OS uses CEF custom-string slots for the most-queried metadata. The `Label` column is set by the device.

| CEF key | CommonSecurityLog column | Label column | Typical value |
|---|---|---|---|
| `cs1` | `DeviceCustomString1` | `DeviceCustomString1Label` = `Rule` | Security policy rule name |
| `cs2` | `DeviceCustomString2` | `DeviceCustomString2Label` = `URLCategory` | URL filtering category |
| `cs6` | `DeviceCustomString6` | `DeviceCustomString6Label` = `Threat` / `URL` / `Verdict` | Varies by event type |

---

## D. Palo Alto-specific extensions → AdditionalExtensions

These don't have native columns and must be extracted by the parser function from `AdditionalExtensions`.

| CEF key | Extracted to | Type | Purpose |
|---|---|---|---|
| `PanOSVsys` | `VirtualSystem` | string | Virtual system (vsys1, vsys2, shared) |
| `PanOSSessionID` | `SessionID` | long | PAN-OS session ID |
| `PanOSRuleName` | `PolicyName` | string | Policy rule that matched |
| `PanOSThreatID` | `ThreatID` | int | Numeric threat signature ID |
| `PanOSThreatCategory` | `ThreatCategory` | string | Vendor-defined threat category |
| `PanOSSeverity` | `ThreatSeverity` | string | informational / low / medium / high / critical |
| `PanOSSubtype` | `LogSubtype` | string | vulnerability / wildfire / url / etc. |
| `PanOSURLCategory` | `URLCategory` | string | PAN-DB URL category |
| `PanOSContentVer` | `ContentVersion` | string | Threat/AV/URL content database version |
| `PanOSPcapID` | `PcapID` | string | Packet capture reference |
| `PanOSReportID` | `WildFireReportID` | string | WildFire analysis report ID |
| `PanOSSourceLocation` | `SrcGeoLocation` | string | Source country / region |
| `PanOSDestinationLocation` | `DstGeoLocation` | string | Destination country / region |
| `PanOSReason` | `Reason` | string | Already in CommonSecurityLog as `Reason` |
| `PanOSPacketsTotal` | `TotalPackets` | int | |
| `PanOSEventID` | `PanOSInternalEventID` | string | System log event identifier |

---

## E. Securonix → Sentinel migration crosswalk

For SOC analysts migrating Securonix queries to Sentinel — Palo Alto-specific:

| Securonix field | Sentinel column / parser output |
|---|---|
| `sourceaddress` | `SrcIP` |
| `destinationaddress` | `DstIP` |
| `sourceport` | `SrcPort` |
| `destinationport` | `DstPort` |
| `accountname` | `User` |
| `eventaction` | `Action` |
| `customstring49` (Rule) | `PolicyName` |
| `customstring50` (Threat ID) | `ThreatID` |
| `customstring51` (URL Category) | `URLCategory` |
| `transactionstring1` (Vsys) | `VirtualSystem` |
| `bytesin` | `BytesIn` |
| `bytesout` | `BytesOut` |
| `requesturl` | `RequestURL` |
| `filename` | `FileName` |
| `filehash` | `FileHash` |
| `applicationprotocol` | `Application` |
| `eventseverity` | `LogSeverity` |

---

## F. Notes for operators

1. **`TimeGenerated` source.** The DCR `transformKql` projects `ReceiptTime` (the firewall's `rt` field) into `TimeGenerated`. This means SOC queries see the firewall's timestamp, not the Azure ingestion timestamp. If the firewall NTP is broken, this will break analytics — validate NTP on the device as part of onboarding.

2. **User-ID dependency.** `SourceUserName` only populates when User-ID is enabled and the relevant zones are mapped to user identities. Without User-ID, expect this column to be empty for ~100% of TRAFFIC events.

3. **PAN-OS version drift.** Custom CEF extensions added in newer PAN-OS versions (e.g., `PanOSDeviceGroupHierarchy`, `PanOSVMTunnelID`) will land in `AdditionalExtensions` until the parser is updated. Re-run validation Query 2 (parser coverage) after every PAN-OS upgrade.

4. **Severity scale.** PAN-OS sends numeric severity (1–10) in the CEF header, but its threat severity (`PanOSSeverity`) uses a text scale (informational/low/medium/high/critical). Don't confuse the two — the parser maps both.
