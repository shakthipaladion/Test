#!/usr/bin/env python3
"""
validate_dcr.py — Lightweight ARM template validator for Sentinel DCRs.

Usage:
    python scripts/validate_dcr.py outputs/<vendor>-<product>/dcr-arm-template.json

Checks:
  1. Valid JSON.
  2. Required ARM template root keys present.
  3. Resource type is Microsoft.Insights/dataCollectionRules.
  4. streamDeclarations / dataFlows / destinations are consistent.
  5. transformKql is non-empty (best practice).
  6. Stream names referenced in dataFlows actually exist in streamDeclarations.
  7. Destination references match.
"""

import json
import sys
from pathlib import Path


def fail(msg: str) -> None:
    print(f"\033[31m✗\033[0m {msg}")
    sys.exit(1)


def warn(msg: str) -> None:
    print(f"\033[33m⚠\033[0m {msg}")


def ok(msg: str) -> None:
    print(f"\033[32m✓\033[0m {msg}")


def main(path: str) -> None:
    p = Path(path)
    if not p.exists():
        fail(f"File not found: {path}")

    try:
        with p.open() as f:
            arm = json.load(f)
    except json.JSONDecodeError as e:
        fail(f"Invalid JSON: {e}")

    ok("File is valid JSON")

    # Root keys
    for key in ("$schema", "contentVersion", "resources"):
        if key not in arm:
            fail(f"Missing root key: {key}")
    ok("Root keys present")

    # Resources
    resources = arm.get("resources", [])
    if not resources:
        fail("No resources defined")

    dcr = next(
        (r for r in resources if r.get("type") == "Microsoft.Insights/dataCollectionRules"),
        None,
    )
    if not dcr:
        fail("No DCR resource found (type Microsoft.Insights/dataCollectionRules)")
    ok("DCR resource present")

    props = dcr.get("properties", {})

    # streamDeclarations
    streams = props.get("streamDeclarations", {})
    if not streams:
        warn("streamDeclarations is empty — only valid for built-in streams (Microsoft-*)")
    else:
        ok(f"{len(streams)} stream declaration(s)")

    # destinations
    destinations = props.get("destinations", {})
    if not destinations:
        fail("destinations missing")

    dest_names = set()
    for dest_type, dest_list in destinations.items():
        for d in dest_list:
            dest_names.add(d.get("name"))
    if not dest_names:
        fail("No destinations defined")
    ok(f"{len(dest_names)} destination(s) defined")

    # dataFlows
    flows = props.get("dataFlows", [])
    if not flows:
        fail("dataFlows missing")

    declared_streams = set(streams.keys())

    for i, flow in enumerate(flows):
        # Streams referenced must exist in declarations OR be Microsoft-built-in
        for s in flow.get("streams", []):
            if s.startswith("Microsoft-"):
                continue
            if s not in declared_streams:
                fail(
                    f"dataFlow #{i}: stream '{s}' referenced but not declared in streamDeclarations"
                )

        # Destinations referenced must exist
        for d in flow.get("destinations", []):
            # Destinations can be parameter expressions or literal names
            if d.startswith("[") and d.endswith("]"):
                continue
            if d not in dest_names:
                fail(f"dataFlow #{i}: destination '{d}' not defined in destinations block")

        # transformKql best practice
        if not flow.get("transformKql"):
            warn(f"dataFlow #{i}: no transformKql (consider adding one for filtering/projection)")

    ok(f"{len(flows)} dataFlow(s) consistent with declarations")

    print("\n\033[32mDCR is valid.\033[0m")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python validate_dcr.py <path-to-dcr-template.json>")
        sys.exit(2)
    main(sys.argv[1])
