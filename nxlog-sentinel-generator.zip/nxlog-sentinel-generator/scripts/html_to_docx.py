#!/usr/bin/env python3
"""
html_to_docx.py — Convert an integration guide HTML to a Word document.

Usage:
    python scripts/html_to_docx.py outputs/<vendor>-<product>/integration-guide.html

Requires:
    pip install python-docx beautifulsoup4 lxml

Notes:
  - Preserves headings (h1/h2/h3), paragraphs, tables, and code blocks (as monospace).
  - Syntax-highlight spans (.cm/.kw/.st/.vr/.fn/.nm/.tp) collapse to monospace text;
    Word doesn't easily preserve fine-grained per-token colour without complex run-level
    formatting. The HTML guide remains the canonical reference.
  - Floating toolbar and CSS-only embellishments are dropped.
"""

import sys
from pathlib import Path

try:
    from bs4 import BeautifulSoup
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except ImportError:
    print("Missing dependencies. Install with:")
    print("    pip install python-docx beautifulsoup4 lxml")
    sys.exit(2)


HEADING_LEVELS = {"h1": 0, "h2": 1, "h3": 2, "h4": 3}


def add_code_block(doc, code_text: str) -> None:
    """Render a code block as a monospaced paragraph with light grey shading."""
    para = doc.add_paragraph()
    para.paragraph_format.left_indent = Pt(12)
    run = para.add_run(code_text)
    run.font.name = "Consolas"
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x16, 0x16, 0x16)


def add_table(doc, table_el) -> None:
    """Render an HTML table as a Word table."""
    rows = table_el.find_all("tr")
    if not rows:
        return

    first_row_cells = rows[0].find_all(["th", "td"])
    n_cols = len(first_row_cells)
    if n_cols == 0:
        return

    word_table = doc.add_table(rows=len(rows), cols=n_cols)
    word_table.style = "Light Grid Accent 1"

    for r_idx, tr in enumerate(rows):
        cells = tr.find_all(["th", "td"])
        for c_idx, cell in enumerate(cells[:n_cols]):
            word_cell = word_table.rows[r_idx].cells[c_idx]
            word_cell.text = cell.get_text(strip=True)
            if cell.name == "th":
                for para in word_cell.paragraphs:
                    for run in para.runs:
                        run.bold = True


def add_callout(doc, callout_el) -> None:
    """Render a callout div as an indented italic paragraph."""
    para = doc.add_paragraph()
    para.paragraph_format.left_indent = Pt(18)
    run = para.add_run(callout_el.get_text(" ", strip=True))
    run.italic = True


def convert(html_path: Path) -> Path:
    html = html_path.read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "lxml")

    doc = Document()

    # Set default style
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    main = soup.find("main") or soup.body or soup

    for el in main.descendants:
        # We only want direct meaningful elements; descendants gives us recursion,
        # but we want to dispatch only on top-level meaningful tags.
        pass

    # Cleaner approach: iterate over direct children with a manual flat walk.
    def walk(parent):
        for child in parent.children:
            if not getattr(child, "name", None):
                # Text node — skip; surrounding tags handle text.
                continue

            tag = child.name.lower()

            if tag in HEADING_LEVELS:
                level = HEADING_LEVELS[tag]
                doc.add_heading(child.get_text(strip=True), level=level)

            elif tag == "p":
                text = child.get_text(" ", strip=True)
                if text:
                    doc.add_paragraph(text)

            elif tag == "pre":
                code = child.get_text("", strip=False).rstrip()
                add_code_block(doc, code)

            elif tag == "table":
                add_table(doc, child)

            elif tag in {"ul", "ol"}:
                style_name = "List Bullet" if tag == "ul" else "List Number"
                for li in child.find_all("li", recursive=False):
                    doc.add_paragraph(li.get_text(" ", strip=True), style=style_name)

            elif tag == "div" and "callout" in (child.get("class") or []):
                add_callout(doc, child)

            elif tag == "div" and "toolbar" in (child.get("class") or []):
                continue

            elif tag in {"div", "section", "article"}:
                # Recurse into structural containers
                walk(child)

            elif tag == "dl":
                # Metadata definition list — render as labelled paragraphs
                terms = child.find_all("dt")
                defs = child.find_all("dd")
                for dt, dd in zip(terms, defs):
                    para = doc.add_paragraph()
                    run = para.add_run(f"{dt.get_text(strip=True)}: ")
                    run.bold = True
                    para.add_run(dd.get_text(strip=True))

    walk(main)

    out_path = html_path.with_suffix(".docx")
    doc.save(out_path)
    return out_path


def main(args: list[str]) -> None:
    if len(args) != 1:
        print("Usage: python html_to_docx.py <path-to-integration-guide.html>")
        sys.exit(2)

    html_path = Path(args[0])
    if not html_path.exists():
        print(f"File not found: {html_path}")
        sys.exit(1)

    out = convert(html_path)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main(sys.argv[1:])
